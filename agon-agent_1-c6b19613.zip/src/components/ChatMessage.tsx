import { motion } from 'framer-motion';
import { Bot, User } from 'lucide-react';
import type { ChatMessage as ChatMessageType } from '../lib/fitnessAI';

interface Props {
  message: ChatMessageType;
  index: number;
}

function formatMarkdown(text: string): string {
  let html = text;
  html = html.replace(/^## (.+)$/gm, '<h2 class="text-lg font-bold mt-3 mb-2 gradient-text">$1</h2>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>');
  html = html.replace(/^- (.+)$/gm, '<li class="ml-4 text-white/70 list-disc list-inside">$1</li>');
  html = html.replace(/^(\d+)\. (.+)$/gm, '<li class="ml-4 text-white/70"><span class="text-emerald-glow font-medium mr-1">$1.</span>$2</li>');
  html = html.replace(/\n\n/g, '<br/><br/>');
  html = html.replace(/\n/g, '<br/>');
  return html;
}

export default function ChatMessage({ message, index }: Props) {
  const isBot = message.role === 'assistant';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      className={`flex gap-3 ${isBot ? 'justify-start' : 'justify-end'}`}
    >
      {isBot && (
        <div className="flex-shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center shadow-lg shadow-emerald-glow/10">
          <Bot className="w-5 h-5 text-dark-900" />
        </div>
      )}

      <div
        className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 ${
          isBot
            ? 'bg-dark-600 border border-white/5 text-white/80'
            : 'bg-gradient-to-r from-emerald-glow/20 to-cyan-glow/20 border border-emerald-glow/20 text-white'
        }`}
      >
        {isBot ? (
          <div
            className="text-sm leading-relaxed prose-sm"
            dangerouslySetInnerHTML={{ __html: formatMarkdown(message.content) }}
          />
        ) : (
          <p className="text-sm leading-relaxed">{message.content}</p>
        )}
        <p className="text-[10px] text-white/20 mt-2 text-right">
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>

      {!isBot && (
        <div className="flex-shrink-0 w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
          <User className="w-5 h-5 text-white/70" />
        </div>
      )}
    </motion.div>
  );
}
