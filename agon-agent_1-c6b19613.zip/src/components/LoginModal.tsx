import { X, Dumbbell, Shield, Sparkles, Loader2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/language';
import { useState } from 'react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LoginModal({ isOpen, onClose }: LoginModalProps) {
  const { login } = useAuth();
  const { t } = useLanguage();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loginProvider, setLoginProvider] = useState<'google' | 'facebook' | null>(null);

  const handleLogin = async (provider: 'google' | 'facebook') => {
    setIsLoading(true);
    setError(null);
    setLoginProvider(provider);
    try {
      await login(provider);
      onClose();
    } catch (err) {
      setError(t.loginFailed);
    } finally {
      setIsLoading(false);
      setLoginProvider(null);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[60]"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="fixed inset-0 z-[70] flex items-center justify-center p-4 pointer-events-none"
      >
        <div className="pointer-events-auto w-full max-w-md glass-card rounded-3xl border border-white/10 overflow-hidden">
          {/* Header */}
          <div className="relative p-8 pb-6 text-center">
            <button
              onClick={onClose}
              disabled={isLoading}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all disabled:opacity-50"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center mx-auto mb-4">
              <Dumbbell className="w-8 h-8 text-dark-900" />
            </div>

            <h2 className="font-display text-2xl font-bold mb-2">
              {t.welcomeToFitbot}
            </h2>
            <p className="text-white/50 text-sm">
              {t.loginDescription}
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-8 mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-2"
            >
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-red-400">{error}</p>
            </motion.div>
          )}

          {/* Login Buttons */}
          <div className="px-8 pb-4 space-y-3">
            <button
              onClick={() => handleLogin('google')}
              disabled={isLoading}
              className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-white hover:bg-white/95 text-dark-900 font-semibold transition-all hover:scale-[1.02] hover:shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {loginProvider === 'google' && isLoading ? (
                <Loader2 className="w-6 h-6 flex-shrink-0 animate-spin" />
              ) : (
                <svg className="w-6 h-6 flex-shrink-0" viewBox="0 0 24 24">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
              )}
              <span className="flex-1 text-left">
                {loginProvider === 'google' && isLoading ? t.loadingGoogle : t.continueWithGoogle}
              </span>
            </button>

            <button
              onClick={() => handleLogin('facebook')}
              disabled={isLoading}
              className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-[#1877F2] hover:bg-[#166FE5] text-white font-semibold transition-all hover:scale-[1.02] hover:shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {loginProvider === 'facebook' && isLoading ? (
                <Loader2 className="w-6 h-6 flex-shrink-0 animate-spin" />
              ) : (
                <svg className="w-6 h-6 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              )}
              <span className="flex-1 text-left">
                {loginProvider === 'facebook' && isLoading ? t.loadingFacebook : t.continueWithFacebook}
              </span>
            </button>
          </div>

          {/* Info Box */}
          <div className="px-8 pb-4">
            <div className="p-3 rounded-xl bg-blue-500/5 border border-blue-500/20">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-white/60 space-y-1">
                  <p>{t.googleInfo}</p>
                  <p>{t.facebookInfo}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Benefits */}
          <div className="px-8 pb-6 pt-2">
            <div className="border-t border-white/5 pt-4">
              <p className="text-xs text-white/30 mb-3 font-medium uppercase tracking-wider">{t.withLoginYouGet}</p>
              <div className="space-y-2">
                {[
                  { icon: Sparkles, text: t.unlimitedAccess },
                  { icon: Shield, text: t.savedConversations },
                  { icon: Dumbbell, text: t.exclusiveWorkouts },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-emerald-glow flex-shrink-0" />
                      <span className="text-sm text-white/60">{item.text}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <p className="text-center text-[10px] text-white/20 px-8 pb-6">
            {t.termsAgreement}
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
