import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Dumbbell, Menu, X, MessageCircle, Home, Sparkles, History, CreditCard, LogIn, LogOut, User, Crown, Shield, Activity } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/language';
import LoginModal from './LoginModal';
import LanguageSelector from './LanguageSelector';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const location = useLocation();
  const { isLoggedIn, user, logout } = useAuth();
  const { t } = useLanguage();

  const navLinks = [
    { path: '/', label: t.home, icon: Home },
    { path: '/chat', label: t.chat, icon: MessageCircle },
    { path: '/dashboard', label: 'Dashboard', icon: Activity },
    { path: '/history', label: t.history, icon: History },
    { path: '/pricing', label: t.premium, icon: CreditCard },
    { path: '/security', label: 'Security', icon: Shield },
  ];

  return (
    <>
      <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
      <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Logo + Creator Credit */}
            <div className="flex items-center gap-4">
              <Link to="/" className="flex items-center gap-2 group">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Dumbbell className="w-5 h-5 text-dark-900" />
                </div>
                <span className="font-display font-bold text-xl tracking-tight">
                  <span className="gradient-text">FitBot</span>
                  <span className="text-white/60 ml-1 text-sm font-medium">AI</span>
                </span>
              </Link>
              <div className="hidden sm:flex items-center gap-1.5 pl-3 border-l border-white/10">
                <span className="text-[11px] text-white/30">Created by</span>
                <span className="text-[11px] font-semibold gradient-text">Muhammad Geovanny Iskandar</span>
              </div>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.path;
                const Icon = link.icon;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? 'bg-white/10 text-emerald-glow'
                        : 'text-white/60 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {link.label}
                  </Link>
                );
              })}

              {/* Language Selector */}
              <div className="ml-2">
                <LanguageSelector />
              </div>

              {/* Auth Button */}
              {isLoggedIn ? (
                <div className="relative ml-2">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
                  >
                    <img
                      src={user?.avatar}
                      alt={user?.name}
                      className="w-7 h-7 rounded-lg object-cover"
                    />
                    <span className="text-sm font-medium text-white/70 max-w-[100px] truncate">{user?.name}</span>
                    {user?.isPremium && (
                      <Crown className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    )}
                  </button>

                  <AnimatePresence>
                    {showProfileMenu && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setShowProfileMenu(false)} />
                        <motion.div
                          initial={{ opacity: 0, y: -5, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: -5, scale: 0.95 }}
                          transition={{ duration: 0.15 }}
                          className="absolute right-0 top-full mt-2 w-64 glass-card rounded-2xl border border-white/10 overflow-hidden z-50 shadow-2xl"
                        >
                          <div className="p-4 border-b border-white/5">
                            <div className="flex items-center gap-3">
                              <img
                                src={user?.avatar}
                                alt={user?.name}
                                className="w-10 h-10 rounded-xl object-cover"
                              />
                              <div className="min-w-0">
                                <p className="font-semibold text-sm truncate">{user?.name}</p>
                                <p className="text-xs text-white/40 truncate">{user?.email}</p>
                              </div>
                            </div>
                            {user?.isPremium && (
                              <div className="mt-3 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-yellow-400/10 border border-yellow-400/20">
                                <Crown className="w-3.5 h-3.5 text-yellow-400" />
                                <span className="text-xs font-medium text-yellow-400">Premium Member</span>
                              </div>
                            )}
                          </div>
                          <div className="p-2">
                            <Link
                              to="/pricing"
                              onClick={() => setShowProfileMenu(false)}
                              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/60 hover:text-white hover:bg-white/5 transition-all"
                            >
                              <CreditCard className="w-4 h-4" />
                              {user?.isPremium ? 'Kelola Premium' : 'Upgrade Premium'}
                            </Link>
                            <Link
                              to="/history"
                              onClick={() => setShowProfileMenu(false)}
                              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-white/60 hover:text-white hover:bg-white/5 transition-all"
                            >
                              <History className="w-4 h-4" />
                              Riwayat Aktivitas
                            </Link>
                            <button
                              onClick={() => {
                                logout();
                                setShowProfileMenu(false);
                              }}
                              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-red-400/70 hover:text-red-400 hover:bg-red-400/5 transition-all"
                            >
                              <LogOut className="w-4 h-4" />
                              Logout
                            </button>
                          </div>
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <button
                  onClick={() => setShowLogin(true)}
                  className="ml-3 flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-semibold text-sm hover:shadow-lg hover:shadow-emerald-glow/20 hover:scale-105 transition-all duration-200"
                >
                  <LogIn className="w-4 h-4" />
                  Login
                </button>
              )}
            </div>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 rounded-xl text-white/60 hover:text-white hover:bg-white/5 transition-colors"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden glass-card border-t border-white/5"
            >
              <div className="px-4 py-3 space-y-1">
                {/* Creator credit on mobile */}
                <div className="flex items-center gap-1.5 px-4 py-2 mb-2">
                  <span className="text-[11px] text-white/30">Created by</span>
                  <span className="text-[11px] font-semibold gradient-text">Muhammad Geovanny Iskandar</span>
                </div>

                {/* Language Selector - Mobile */}
                <div className="px-4 py-2 mb-2">
                  <LanguageSelector />
                </div>

                {navLinks.map((link) => {
                  const isActive = location.pathname === link.path;
                  const Icon = link.icon;
                  return (
                    <Link
                      key={link.path}
                      to={link.path}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-white/10 text-emerald-glow'
                          : 'text-white/60 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {link.label}
                    </Link>
                  );
                })}

                {isLoggedIn ? (
                  <div className="border-t border-white/5 mt-2 pt-2">
                    <div className="flex items-center gap-3 px-4 py-3">
                      <img
                        src={user?.avatar}
                        alt={user?.name}
                        className="w-8 h-8 rounded-lg object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-sm truncate">{user?.name}</p>
                        <p className="text-xs text-white/40 truncate">{user?.email}</p>
                      </div>
                      {user?.isPremium && (
                        <Crown className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                      )}
                    </div>
                    <button
                      onClick={() => {
                        logout();
                        setIsOpen(false);
                      }}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-red-400/70 hover:text-red-400 hover:bg-red-400/5 transition-all"
                    >
                      <LogOut className="w-4 h-4" />
                      Logout
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setShowLogin(true);
                      setIsOpen(false);
                    }}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-semibold text-sm mt-2"
                  >
                    <LogIn className="w-4 h-4" />
                    Login
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
}
