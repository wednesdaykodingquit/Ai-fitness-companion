import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Globe, Search, Check, ChevronDown } from 'lucide-react';
import { useLanguage } from '../lib/language';

export default function LanguageSelector() {
  const { currentLanguage, setLanguage, availableLanguages, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSearchQuery('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && searchRef.current) {
      searchRef.current.focus();
    }
  }, [isOpen]);

  const filteredLanguages = availableLanguages.filter(lang =>
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelect = (code: string) => {
    setLanguage(code);
    setIsOpen(false);
    setSearchQuery('');
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all text-sm"
      >
        <Globe className="w-4 h-4 text-emerald-glow" />
        <span className="text-lg">{currentLanguage.flag}</span>
        <span className="hidden sm:inline text-xs text-white/70 max-w-[80px] truncate">
          {currentLanguage.nativeName}
        </span>
        <ChevronDown className={`w-3.5 h-3.5 text-white/40 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40"
              onClick={() => { setIsOpen(false); setSearchQuery(''); }}
            />
            <motion.div
              initial={{ opacity: 0, y: -5, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -5, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-full mt-2 w-80 glass-card rounded-2xl border border-white/10 overflow-hidden z-50 shadow-2xl"
            >
              {/* Header */}
              <div className="p-4 border-b border-white/5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-display font-bold text-sm">{t.selectLanguage}</h3>
                  <span className="text-[10px] text-white/30 bg-white/5 px-2 py-0.5 rounded-full">
                    {availableLanguages.length} {t.language.toLowerCase()}
                  </span>
                </div>
                
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <input
                    ref={searchRef}
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={`${t.search}...`}
                    className="w-full bg-dark-600 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50 focus:ring-1 focus:ring-emerald-glow/20 transition-all"
                  />
                </div>
              </div>

              {/* Language List */}
              <div className="max-h-[400px] overflow-y-auto p-2">
                {filteredLanguages.length === 0 ? (
                  <div className="text-center py-8">
                    <Globe className="w-8 h-8 text-white/10 mx-auto mb-2" />
                    <p className="text-xs text-white/30">No languages found</p>
                  </div>
                ) : (
                  <div className="space-y-0.5">
                    {filteredLanguages.map((lang) => {
                      const isActive = lang.code === currentLanguage.code;
                      return (
                        <button
                          key={lang.code}
                          onClick={() => handleSelect(lang.code)}
                          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${
                            isActive
                              ? 'bg-emerald-glow/10 border border-emerald-glow/20'
                              : 'hover:bg-white/5 border border-transparent'
                          }`}
                        >
                          <span className="text-xl flex-shrink-0">{lang.flag}</span>
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-medium truncate ${isActive ? 'text-emerald-glow' : 'text-white/80'}`}>
                              {lang.nativeName}
                            </p>
                            <p className="text-[10px] text-white/40 truncate">{lang.name}</p>
                          </div>
                          {isActive && (
                            <Check className="w-4 h-4 text-emerald-glow flex-shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-3 border-t border-white/5 bg-dark-800/50">
                <p className="text-[10px] text-white/20 text-center">
                  🌍 {availableLanguages.length} languages supported
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
