import { motion } from 'framer-motion';
import { Bot } from 'lucide-react';

export default function TypingIndicator() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="flex gap-3 justify-start"
    >
      <div className="flex-shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center shadow-lg shadow-emerald-glow/10">
        <Bot className="w-5 h-5 text-dark-900" />
      </div>
      <div className="bg-dark-600 border border-white/5 rounded-2xl px-5 py-4">
        <div className="flex gap-1.5">
          <div className="typing-dot w-2 h-2 rounded-full bg-emerald-glow" />
          <div className="typing-dot w-2 h-2 rounded-full bg-emerald-glow" />
          <div className="typing-dot w-2 h-2 rounded-full bg-emerald-glow" />
        </div>
      </div>
    </motion.div>
  );
}
