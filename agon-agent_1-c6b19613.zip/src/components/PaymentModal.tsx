import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, Copy, Check, CreditCard, Smartphone, ArrowRight, Shield,
  Clock, AlertCircle, Upload, Image, Scan, XCircle, Eye,
  FileWarning, Sparkles, ZoomIn, MessageCircle, Send
} from 'lucide-react';
import { useLanguage } from '../lib/language';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  planName: string;
  planPrice: string;
  planPeriod: string;
}

interface AnalysisResult {
  passed: boolean;
  score: number;
  details: {
    label: string;
    status: 'pass' | 'fail' | 'warn';
    detail: string;
  }[];
  verdict: string;
}

type Step = 'payment' | 'upload' | 'analyzing' | 'result' | 'success';

export default function PaymentModal({ isOpen, onClose, onConfirm, planName, planPrice, planPeriod }: Props) {
  const { t } = useLanguage();
  const [copiedDana, setCopiedDana] = useState(false);
  const [copiedBank, setCopiedBank] = useState(false);
  const [step, setStep] = useState<Step>('payment');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const [showFullImage, setShowFullImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const danaNumber = '082161387805';
  const bankNumber = '5258 0101 8611 506';

  const handleCopyDana = async () => {
    try {
      await navigator.clipboard.writeText(danaNumber);
    } catch {
      const el = document.createElement('textarea');
      el.value = danaNumber;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
    setCopiedDana(true);
    setTimeout(() => setCopiedDana(false), 2500);
  };

  const handleCopyBank = async () => {
    try {
      await navigator.clipboard.writeText(bankNumber.replace(/\s/g, ''));
    } catch {
      const el = document.createElement('textarea');
      el.value = bankNumber.replace(/\s/g, '');
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
    setCopiedBank(true);
    setTimeout(() => setCopiedBank(false), 2500);
  };

  const handleFileSelect = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Only image files are accepted (JPG, PNG, WEBP)');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      alert('Maximum file size is 15MB');
      return;
    }
    setUploadedFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setUploadedImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOver(false);
  }, []);

  const analyzeImage = useCallback(async (): Promise<AnalysisResult> => {
    const details: AnalysisResult['details'] = [];
    let failCount = 0;

    if (!uploadedFile || !uploadedImage) {
      return { passed: false, score: 0, details: [], verdict: 'No image' };
    }

    // 1. File size analysis
    const sizeKB = uploadedFile.size / 1024;
    if (sizeKB < 30) {
      details.push({ label: 'File Size', status: 'fail', detail: `File too small (${sizeKB.toFixed(1)} KB) - indicates edited/over-compressed image` });
      failCount++;
    } else if (sizeKB > 8000) {
      details.push({ label: 'File Size', status: 'warn', detail: `File very large (${(sizeKB / 1024).toFixed(1)} MB) - may contain edit layers` });
      failCount += 0.5;
    } else {
      details.push({ label: 'File Size', status: 'pass', detail: `Normal size (${sizeKB.toFixed(0)} KB) - consistent with original screenshot` });
    }

    // 2. Image dimensions analysis via canvas
    const img = new window.Image();
    await new Promise<void>((resolve) => {
      img.onload = () => resolve();
      img.src = uploadedImage;
    });

    const w = img.naturalWidth;
    const h = img.naturalHeight;
    const ratio = w / h;

    const isPhoneRatio = ratio > 0.4 && ratio < 0.7;
    const isDesktopRatio = ratio > 1.2 && ratio < 2.5;
    const isSquare = Math.abs(ratio - 1) < 0.15;

    if (isPhoneRatio || isDesktopRatio) {
      details.push({ label: 'Dimension Ratio', status: 'pass', detail: `${w}×${h}px - ratio ${ratio.toFixed(2)} consistent with ${isPhoneRatio ? 'phone' : 'desktop'} screenshot` });
    } else if (isSquare) {
      details.push({ label: 'Dimension Ratio', status: 'warn', detail: `${w}×${h}px - 1:1 ratio unusual for screenshot (possibly crop/edit)` });
      failCount += 0.3;
    } else {
      details.push({ label: 'Dimension Ratio', status: 'warn', detail: `${w}×${h}px - non-standard ratio (${ratio.toFixed(2)})` });
      failCount += 0.2;
    }

    // 3. Pixel uniformity analysis
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const sampleSize = 100;
      canvas.width = sampleSize;
      canvas.height = sampleSize;
      ctx.drawImage(img, 0, 0, sampleSize, sampleSize);
      const imageData = ctx.getImageData(0, 0, sampleSize, sampleSize);
      const data = imageData.data;

      let totalVariance = 0;
      let edgeCount = 0;
      for (let i = 0; i < data.length - 4; i += 4) {
        const dr = Math.abs(data[i] - data[i + 4]);
        const dg = Math.abs(data[i + 1] - data[i + 5]);
        const db = Math.abs(data[i + 2] - data[i + 6]);
        totalVariance += dr + dg + db;
        if (dr + dg + db > 30) edgeCount++;
      }

      const avgVariance = totalVariance / (data.length / 4);
      const edgeRatio = edgeCount / (data.length / 4);

      if (avgVariance < 8) {
        details.push({ label: 'Pixel Pattern', status: 'fail', detail: 'Color variation too smooth - pattern consistent with AI-generated image' });
        failCount++;
      } else if (avgVariance < 15 && edgeRatio < 0.05) {
        details.push({ label: 'Pixel Pattern', status: 'warn', detail: 'Very smooth color transitions - possible editing process' });
        failCount += 0.5;
      } else {
        details.push({ label: 'Pixel Pattern', status: 'pass', detail: `Natural pixel variation (variance: ${avgVariance.toFixed(1)}) - consistent with original screenshot` });
      }

      // 4. Noise analysis
      let noiseLevel = 0;
      for (let y = 1; y < sampleSize - 1; y++) {
        for (let x = 1; x < sampleSize - 1; x++) {
          const idx = (y * sampleSize + x) * 4;
          const above = ((y - 1) * sampleSize + x) * 4;
          const below = ((y + 1) * sampleSize + x) * 4;
          const left = (y * sampleSize + (x - 1)) * 4;
          const right = (y * sampleSize + (x + 1)) * 4;
          const laplacian = Math.abs(
            4 * data[idx] - data[above] - data[below] - data[left] - data[right]
          );
          noiseLevel += laplacian;
        }
      }
      noiseLevel /= (sampleSize - 2) * (sampleSize - 2);

      if (noiseLevel < 5) {
        details.push({ label: 'Noise Level', status: 'fail', detail: `Very low noise (${noiseLevel.toFixed(1)}) - image too clean, indicates AI-generated` });
        failCount++;
      } else if (noiseLevel < 12) {
        details.push({ label: 'Noise Level', status: 'warn', detail: `Low noise (${noiseLevel.toFixed(1)}) - possible smoothing/editing process` });
        failCount += 0.4;
      } else {
        details.push({ label: 'Noise Level', status: 'pass', detail: `Normal noise (${noiseLevel.toFixed(1)}) - consistent with display screenshot` });
      }
    }

    // 5. File type check
    const fileType = uploadedFile.type;
    if (fileType === 'image/png') {
      details.push({ label: 'File Format', status: 'pass', detail: 'PNG - standard screenshot format' });
    } else if (fileType === 'image/jpeg') {
      details.push({ label: 'File Format', status: 'pass', detail: 'JPEG - common format for screenshot/photo' });
    } else if (fileType === 'image/webp') {
      details.push({ label: 'File Format', status: 'warn', detail: 'WEBP - can be from browser, check further' });
      failCount += 0.1;
    } else {
      details.push({ label: 'File Format', status: 'fail', detail: `${fileType} - unusual format for transfer proof` });
      failCount++;
    }

    // 6. Resolution check
    if (w < 300 || h < 300) {
      details.push({ label: 'Resolution', status: 'fail', detail: `${w}×${h}px - resolution too low, likely crop/heavy edit` });
      failCount++;
    } else if (w >= 720 && h >= 720) {
      details.push({ label: 'Resolution', status: 'pass', detail: `${w}×${h}px - high resolution, consistent with HD screenshot` });
    } else {
      details.push({ label: 'Resolution', status: 'pass', detail: `${w}×${h}px - sufficient resolution` });
    }

    const maxFails = 6;
    const score = Math.max(0, Math.min(100, Math.round((1 - failCount / maxFails) * 100)));
    const passed = score >= 60;

    const verdict = passed
      ? 'Payment proof verified as original. No AI manipulation detected.'
      : 'Image detected to contain AI manipulation/editing. Payment proof REJECTED.';

    return { passed, score, details, verdict };
  }, [uploadedFile, uploadedImage]);

  const handleStartAnalysis = async () => {
    setStep('analyzing');
    setAnalysisProgress(0);

    const progressInterval = setInterval(() => {
      setAnalysisProgress((prev) => {
        if (prev >= 95) {
          clearInterval(progressInterval);
          return 95;
        }
        return prev + Math.random() * 15;
      });
    }, 300);

    const result = await analyzeImage();

    clearInterval(progressInterval);
    setAnalysisProgress(100);

    setTimeout(() => {
      setAnalysisResult(result);
      setStep('result');
    }, 500);
  };

  const handleConfirmSuccess = () => {
    setStep('success');
    setTimeout(() => {
      onConfirm();
      handleClose();
    }, 2000);
  };

  const handleRetry = () => {
    setUploadedImage(null);
    setUploadedFile(null);
    setAnalysisResult(null);
    setAnalysisProgress(0);
    setStep('upload');
  };

  const handleClose = () => {
    onClose();
    setTimeout(() => {
      setStep('payment');
      setUploadedImage(null);
      setUploadedFile(null);
      setAnalysisResult(null);
      setAnalysisProgress(0);
    }, 300);
  };

  const renderContent = () => {
    switch (step) {
      case 'success':
        return (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-10 text-center"
          >
            <div className="w-20 h-20 rounded-full bg-emerald-glow/20 flex items-center justify-center mx-auto mb-5">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring' }}
              >
                <Check className="w-10 h-10 text-emerald-glow" />
              </motion.div>
            </div>
            <h3 className="font-display text-2xl font-bold mb-2">{t.paymentSuccess}</h3>
            <p className="text-white/50 text-sm">{t.activatingPremium}</p>
          </motion.div>
        );

      case 'analyzing':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-8"
          >
            <div className="text-center mb-8">
              <div className="relative w-24 h-24 mx-auto mb-6">
                <div className="absolute inset-0 rounded-full border-4 border-white/5" />
                <motion.div
                  className="absolute inset-0 rounded-full border-4 border-emerald-glow border-t-transparent"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Scan className="w-8 h-8 text-emerald-glow animate-pulse" />
                </div>
              </div>
              <h3 className="font-display text-xl font-bold mb-2">{t.analyzingProof}</h3>
              <p className="text-white/40 text-sm">{t.aiCheckingImage}</p>
            </div>

            <div className="mb-6">
              <div className="flex justify-between text-xs mb-2">
                <span className="text-white/40">{t.progress}</span>
                <span className="text-emerald-glow font-mono">{Math.min(100, Math.round(analysisProgress))}%</span>
              </div>
              <div className="h-2 bg-dark-600 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-emerald-glow to-cyan-glow rounded-full"
                  style={{ width: `${Math.min(100, analysisProgress)}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            <div className="space-y-2">
              {[
                { label: t.checkingMetadata, threshold: 10 },
                { label: t.analyzingDimensions, threshold: 25 },
                { label: t.scanningPixels, threshold: 45 },
                { label: t.detectingNoise, threshold: 65 },
                { label: t.verifyingFormat, threshold: 80 },
                { label: t.generatingReport, threshold: 95 },
              ].map((item, i) => {
                const done = analysisProgress >= item.threshold;
                const active = analysisProgress >= (i > 0 ? [10, 25, 45, 65, 80, 95][i - 1] : 0) && !done;
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-xs transition-all ${
                      done ? 'text-emerald-glow/70' : active ? 'text-white/60' : 'text-white/20'
                    }`}
                  >
                    {done ? (
                      <Check className="w-3.5 h-3.5 flex-shrink-0" />
                    ) : active ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                        className="w-3.5 h-3.5 rounded-full border-2 border-white/30 border-t-emerald-glow flex-shrink-0"
                      />
                    ) : (
                      <div className="w-3.5 h-3.5 rounded-full border border-white/10 flex-shrink-0" />
                    )}
                    {item.label}
                  </motion.div>
                );
              })}
            </div>

            {uploadedImage && (
              <div className="mt-6 rounded-xl overflow-hidden border border-white/5 opacity-50">
                <img src={uploadedImage} alt="Analyzing" className="w-full h-32 object-cover" />
              </div>
            )}
          </motion.div>
        );

      case 'result':
        return (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-6"
          >
            {/* Verdict Header */}
            <div className={`rounded-2xl p-5 mb-5 ${
              analysisResult?.passed
                ? 'bg-emerald-glow/5 border border-emerald-glow/20'
                : 'bg-red-500/5 border border-red-500/20'
            }`}>
              <div className="flex items-center gap-3 mb-3">
                {analysisResult?.passed ? (
                  <div className="w-12 h-12 rounded-xl bg-emerald-glow/20 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-emerald-glow" />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center">
                    <XCircle className="w-6 h-6 text-red-400" />
                  </div>
                )}
                <div>
                  <h3 className={`font-display text-lg font-bold ${analysisResult?.passed ? 'text-emerald-glow' : 'text-red-400'}`}>
                    {analysisResult?.passed ? t.verifiedOriginal : t.detectedAiEdited}
                  </h3>
                  <p className="text-xs text-white/40">{t.authenticityScore} {analysisResult?.score}/100</p>
                </div>
              </div>

              <div className="h-2 bg-dark-900/50 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full transition-all duration-1000 ${
                    analysisResult && analysisResult.score >= 60
                      ? 'bg-gradient-to-r from-emerald-glow to-cyan-glow'
                      : 'bg-gradient-to-r from-red-500 to-orange-500'
                  }`}
                  style={{ width: `${analysisResult?.score || 0}%` }}
                />
              </div>
              <p className="text-xs text-white/50">{analysisResult?.verdict}</p>
            </div>

            {/* Image Preview */}
            {uploadedImage && (
              <div className="relative rounded-xl overflow-hidden border border-white/5 mb-5 group cursor-pointer" onClick={() => setShowFullImage(true)}>
                <img src={uploadedImage} alt="Payment proof" className="w-full h-40 object-cover" />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center">
                  <ZoomIn className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className={`absolute top-2 right-2 px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                  analysisResult?.passed
                    ? 'bg-emerald-glow/90 text-dark-900'
                    : 'bg-red-500/90 text-white'
                }`}>
                  {analysisResult?.passed ? '✅ ORIGINAL' : '❌ EDITED'}
                </div>
              </div>
            )}

            {/* Analysis Details */}
            <div className="mb-5">
              <h4 className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-3">{t.analysisDetails}</h4>
              <div className="space-y-2">
                {analysisResult?.details.map((d, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className={`flex items-start gap-3 px-3 py-2.5 rounded-xl text-xs ${
                      d.status === 'pass'
                        ? 'bg-emerald-glow/5 border border-emerald-glow/10'
                        : d.status === 'fail'
                        ? 'bg-red-500/5 border border-red-500/10'
                        : 'bg-yellow-400/5 border border-yellow-400/10'
                    }`}
                  >
                    <div className="flex-shrink-0 mt-0.5">
                      {d.status === 'pass' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-glow" />
                      ) : d.status === 'fail' ? (
                        <XCircle className="w-3.5 h-3.5 text-red-400" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-yellow-400" />
                      )}
                    </div>
                    <div>
                      <p className={`font-semibold mb-0.5 ${
                        d.status === 'pass' ? 'text-emerald-glow' : d.status === 'fail' ? 'text-red-400' : 'text-yellow-400'
                      }`}>{d.label}</p>
                      <p className="text-white/50">{d.detail}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Warning for failed */}
            {!analysisResult?.passed && (
              <div className="rounded-xl bg-red-500/5 border border-red-500/15 p-4 mb-5">
                <div className="flex gap-2">
                  <FileWarning className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-red-400 mb-1">{t.paymentRejected}</p>
                    <p className="text-xs text-white/50 leading-relaxed">
                      {t.paymentRejectedDesc}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* WhatsApp Reminder for passed */}
            {analysisResult?.passed && (
              <div className="rounded-xl bg-green-500/5 border border-green-500/15 p-4 mb-5">
                <div className="flex gap-2">
                  <MessageCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-green-400 mb-1">{t.dontForgetSendProof}</p>
                    <p className="text-xs text-white/50 leading-relaxed mb-2">
                      {t.sendProofDesc2}
                    </p>
                    <a
                      href={`https://wa.me/6282161387805?text=${encodeURIComponent(`Halo admin FitBot AI, saya sudah melakukan pembayaran untuk Paket ${planName} (Rp ${planPrice}). Berikut bukti pembayaran saya:`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white font-semibold text-xs transition-all hover:scale-[1.02]"
                    >
                      <Send className="w-3.5 h-3.5" />
                      {t.sendViaWhatsapp}
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3">
              {!analysisResult?.passed ? (
                <>
                  <button
                    onClick={handleClose}
                    className="flex-1 py-3.5 rounded-2xl border border-white/10 text-white/60 font-medium text-sm hover:bg-white/5 transition-all"
                  >
                    {t.close}
                  </button>
                  <button
                    onClick={handleRetry}
                    className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-sm hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
                  >
                    <Upload className="w-4 h-4" />
                    {t.reupload}
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={handleClose}
                    className="flex-1 py-3.5 rounded-2xl border border-white/10 text-white/60 font-medium text-sm hover:bg-white/5 transition-all"
                  >
                    {t.cancel}
                  </button>
                  <button
                    onClick={handleConfirmSuccess}
                    className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-sm hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
                  >
                    <Sparkles className="w-4 h-4" />
                    {t.activatePremium}
                  </button>
                </>
              )}
            </div>
          </motion.div>
        );

      case 'upload':
        return (
          <>
            {/* Header */}
            <div className="relative p-6 pb-4 border-b border-white/5">
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                  <Image className="w-6 h-6 text-dark-900" />
                </div>
                <div>
                  <h2 className="font-display text-xl font-bold">{t.uploadProof}</h2>
                  <p className="text-white/40 text-sm">{t.uploadProofDesc}</p>
                </div>
              </div>

              <div className="mt-3 px-4 py-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold">{t.packageLabel} {planName}</p>
                  <p className="text-[10px] text-white/40">{planPeriod}</p>
                </div>
                <p className="font-display text-lg font-bold gradient-text">Rp {planPrice}</p>
              </div>
            </div>

            <div className="p-6">
              {/* Upload Area */}
              {!uploadedImage ? (
                <div
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onClick={() => fileInputRef.current?.click()}
                  className={`relative rounded-2xl border-2 border-dashed p-8 text-center cursor-pointer transition-all ${
                    dragOver
                      ? 'border-emerald-glow bg-emerald-glow/5'
                      : 'border-white/10 hover:border-white/20 hover:bg-white/[0.02]'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileSelect(file);
                    }}
                  />
                  <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
                    <Upload className="w-7 h-7 text-white/30" />
                  </div>
                  <p className="font-semibold text-sm mb-1">{t.dragDropImage}</p>
                  <p className="text-xs text-white/40 mb-3">{t.orClickToSelect}</p>
                  <div className="flex items-center justify-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-white/40">JPG</span>
                    <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-white/40">PNG</span>
                    <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-white/40">WEBP</span>
                    <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-white/40">{t.maxFileSize}</span>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Preview */}
                  <div className="relative rounded-2xl overflow-hidden border border-white/10">
                    <img
                      src={uploadedImage}
                      alt="Payment proof preview"
                      className="w-full max-h-64 object-contain bg-dark-900"
                    />
                    <button
                      onClick={() => setShowFullImage(true)}
                      className="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur-sm text-white text-xs flex items-center gap-1.5 hover:bg-black/80 transition-all"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {t.viewFull}
                    </button>
                    <button
                      onClick={() => {
                        setUploadedImage(null);
                        setUploadedFile(null);
                      }}
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center text-white/70 hover:text-white hover:bg-black/80 transition-all"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* File Info */}
                  <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/5">
                    <Image className="w-5 h-5 text-white/30" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{uploadedFile?.name}</p>
                      <p className="text-xs text-white/40">
                        {uploadedFile && `${(uploadedFile.size / 1024).toFixed(0)} KB`}
                        {uploadedFile && ` • ${uploadedFile.type.split('/')[1].toUpperCase()}`}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* AI Detection Warning */}
              <div className="mt-4 rounded-xl bg-yellow-400/5 border border-yellow-400/10 p-4">
                <div className="flex gap-2">
                  <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-yellow-400 mb-1">{t.aiDetectionWarning}</p>
                    <p className="text-xs text-white/50 leading-relaxed">
                      {t.aiDetectionDesc}
                    </p>
                  </div>
                </div>
              </div>

              {/* Tips */}
              <div className="mt-4 rounded-xl bg-emerald-glow/5 border border-emerald-glow/10 p-4">
                <p className="text-xs font-semibold text-emerald-glow mb-2">{t.uploadTips}</p>
                <ul className="text-xs text-white/50 space-y-1">
                  <li>{t.tip1}</li>
                  <li>{t.tip2}</li>
                  <li>{t.tip3}</li>
                  <li>{t.tip4}</li>
                </ul>
              </div>

              {/* Submit Button */}
              <div className="mt-6">
                <button
                  onClick={() => setStep('payment')}
                  className="w-full py-3 mb-3 rounded-2xl border border-white/10 text-white/60 font-medium text-sm hover:bg-white/5 transition-all"
                >
                  {t.backToPayment}
                </button>
                <button
                  onClick={handleStartAnalysis}
                  disabled={!uploadedImage}
                  className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-sm hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-30 disabled:hover:scale-100 disabled:hover:shadow-none"
                >
                  <Scan className="w-5 h-5" />
                  {t.analyzeProof}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        );

      default: // 'payment'
        return (
          <>
            {/* Header */}
            <div className="relative p-6 pb-4 border-b border-white/5">
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-dark-900" />
                </div>
                <div>
                  <h2 className="font-display text-xl font-bold">{t.payment}</h2>
                  <p className="text-white/40 text-sm">{t.selectPaymentMethod}</p>
                </div>
              </div>

              <div className="mt-4 px-4 py-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold">{t.packageLabel} {planName}</p>
                  <p className="text-xs text-white/40">{planPeriod}</p>
                </div>
                <div className="text-right">
                  <p className="font-display text-xl font-bold gradient-text">Rp {planPrice}</p>
                </div>
              </div>
            </div>

            {/* Payment Methods */}
            <div className="p-6 space-y-4">
              {/* DANA */}
              <div className="rounded-2xl border border-blue-400/20 bg-blue-400/5 p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center">
                    <Smartphone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">DANA</h3>
                    <p className="text-xs text-white/40">{t.transferViaDana}</p>
                  </div>
                </div>

                <div className="bg-dark-900/50 rounded-xl p-4">
                  <p className="text-xs text-white/40 mb-2">{t.danaNumber}</p>
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-display text-xl font-bold text-blue-400 tracking-wider">
                      {danaNumber}
                    </p>
                    <button
                      onClick={handleCopyDana}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        copiedDana
                          ? 'bg-emerald-glow/20 text-emerald-glow'
                          : 'bg-white/10 text-white/60 hover:bg-white/20 hover:text-white'
                      }`}
                    >
                      {copiedDana ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          {t.copied}
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          {t.copy}
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-white/30 mt-2">{t.accountName}</p>
                </div>
              </div>

              {/* Bank Transfer */}
              <div className="rounded-2xl border border-emerald-glow/20 bg-emerald-glow/5 p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-dark-900" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">{t.bankTransfer}</h3>
                    <p className="text-xs text-white/40">{t.bankTransferDesc}</p>
                  </div>
                </div>

                <div className="bg-dark-900/50 rounded-xl p-4">
                  <p className="text-xs text-white/40 mb-2">{t.accountNumber}</p>
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-display text-xl font-bold text-emerald-glow tracking-wider">
                      {bankNumber}
                    </p>
                    <button
                      onClick={handleCopyBank}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        copiedBank
                          ? 'bg-emerald-glow/20 text-emerald-glow'
                          : 'bg-white/10 text-white/60 hover:bg-white/20 hover:text-white'
                      }`}
                    >
                      {copiedBank ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          {t.copied}
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          {t.copy}
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-white/30 mt-2">{t.accountName}</p>
                </div>
              </div>

              {/* Instructions */}
              <div className="rounded-xl bg-yellow-400/5 border border-yellow-400/10 p-4">
                <div className="flex gap-2">
                  <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-yellow-400 mb-1">{t.paymentInstructions}</p>
                    <ol className="text-xs text-white/50 space-y-1 list-decimal list-inside">
                      <li>{t.instruction1}</li>
                      <li>{t.instruction2} <span className="text-white/70 font-medium">Rp {planPrice}</span></li>
                      <li>{t.instruction3}</li>
                      <li><strong className="text-emerald-glow">{t.instruction4}</strong></li>
                      <li>{t.instruction5}</li>
                      <li>{t.instruction6}</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-6 pt-2">
              <button
                onClick={() => setStep('upload')}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-sm hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                <Check className="w-5 h-5" />
                {t.iHavePaid}
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-[10px] text-white/20 mt-3">
                {t.termsAgreement}
              </p>
            </div>
          </>
        );
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[60]"
            onClick={handleClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-4 pointer-events-none"
          >
            <div className="pointer-events-auto w-full max-w-lg glass-card rounded-3xl border border-white/10 overflow-hidden max-h-[90vh] overflow-y-auto">
              {renderContent()}
            </div>
          </motion.div>

          {/* Full Image Viewer */}
          <AnimatePresence>
            {showFullImage && uploadedImage && (
              <>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/90 backdrop-blur-md z-[80]"
                  onClick={() => setShowFullImage(false)}
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="fixed inset-4 sm:inset-10 z-[90] flex items-center justify-center pointer-events-none"
                >
                  <div className="pointer-events-auto relative max-w-full max-h-full">
                    <button
                      onClick={() => setShowFullImage(false)}
                      className="absolute -top-3 -right-3 w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/20 transition-all z-10"
                    >
                      <X className="w-5 h-5" />
                    </button>
                    <img
                      src={uploadedImage}
                      alt="Payment proof full view"
                      className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl object-contain"
                    />
                    {analysisResult && (
                      <div className={`absolute top-3 left-3 px-3 py-1.5 rounded-lg text-xs font-bold ${
                        analysisResult.passed
                          ? 'bg-emerald-glow/90 text-dark-900'
                          : 'bg-red-500/90 text-white'
                      }`}>
                        {analysisResult.passed ? '✅ ORIGINAL' : '❌ EDITED AI'}
                      </div>
                    )}
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </>
      )}
    </AnimatePresence>
  );
}
