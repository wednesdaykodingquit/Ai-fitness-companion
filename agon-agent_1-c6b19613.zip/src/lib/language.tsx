import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { languages, getTranslation, type Translations, type Language } from './translations';

interface LanguageContextType {
  currentLanguage: Language;
  t: Translations;
  setLanguage: (code: string) => void;
  availableLanguages: Language[];
}

const LanguageContext = createContext<LanguageContextType | null>(null);

const DEFAULT_LANGUAGE = 'id';

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('fitbot_language');
      if (saved) {
        const found = languages.find(l => l.code === saved);
        if (found) return found;
      }
    } catch {}
    
    // Detect browser language
    const browserLang = navigator.language.split('-')[0];
    const detected = languages.find(l => l.code === browserLang);
    return detected || languages.find(l => l.code === DEFAULT_LANGUAGE) || languages[0];
  });

  useEffect(() => {
    localStorage.setItem('fitbot_language', currentLanguage.code);
    document.documentElement.lang = currentLanguage.code;
    document.documentElement.dir = ['ar', 'he', 'fa', 'ur'].includes(currentLanguage.code) ? 'rtl' : 'ltr';
  }, [currentLanguage]);

  const setLanguage = (code: string) => {
    const lang = languages.find(l => l.code === code);
    if (lang) {
      setCurrentLanguage(lang);
    }
  };

  const t = getTranslation(currentLanguage.code);

  return (
    <LanguageContext.Provider value={{ currentLanguage, t, setLanguage, availableLanguages: languages }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
