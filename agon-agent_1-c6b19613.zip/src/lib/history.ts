export interface HistoryEntry {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  action: string;
  detail: string;
  category: 'workout' | 'nutrition' | 'supplement' | 'recovery' | 'chat' | 'premium';
  timestamp: string;
}

const mockHistory: HistoryEntry[] = [
  {
    id: 'h1',
    userId: 'u1',
    userName: 'Andi Pratama',
    userAvatar: 'https://ui-avatars.com/api/?name=Andi+P&background=00FF87&color=0a0a0a&bold=true',
    action: 'Meminta Workout Plan',
    detail: 'Chest Day Power — Bench Press, Incline DB Press, Cable Flyes',
    category: 'workout',
    timestamp: '2025-01-15T08:30:00Z',
  },
  {
    id: 'h2',
    userId: 'u2',
    userName: 'Siti Nurhaliza',
    userAvatar: 'https://ui-avatars.com/api/?name=Siti+N&background=60EFFF&color=0a0a0a&bold=true',
    action: 'Konsultasi Nutrisi',
    detail: 'Panduan protein harian — 1.6-2.2g per kg berat badan',
    category: 'nutrition',
    timestamp: '2025-01-15T09:15:00Z',
  },
  {
    id: 'h3',
    userId: 'u3',
    userName: 'Budi Santoso',
    userAvatar: 'https://ui-avatars.com/api/?name=Budi+S&background=a855f7&color=ffffff&bold=true',
    action: 'Upgrade ke Premium',
    detail: 'Paket Bulanan — Rp 100.000',
    category: 'premium',
    timestamp: '2025-01-15T10:00:00Z',
  },
  {
    id: 'h4',
    userId: 'u4',
    userName: 'Dewi Lestari',
    userAvatar: 'https://ui-avatars.com/api/?name=Dewi+L&background=f43f5e&color=ffffff&bold=true',
    action: 'Meminta Workout Plan',
    detail: 'Leg Day Destroyer — Squats, Romanian Deadlifts, Leg Press',
    category: 'workout',
    timestamp: '2025-01-15T11:20:00Z',
  },
  {
    id: 'h5',
    userId: 'u5',
    userName: 'Rizky Fauzan',
    userAvatar: 'https://ui-avatars.com/api/?name=Rizky+F&background=f59e0b&color=0a0a0a&bold=true',
    action: 'Konsultasi Supplement',
    detail: 'Panduan supplement tier 1 — Whey, Creatine, Vitamin D3',
    category: 'supplement',
    timestamp: '2025-01-15T12:45:00Z',
  },
  {
    id: 'h6',
    userId: 'u6',
    userName: 'Maya Anggraini',
    userAvatar: 'https://ui-avatars.com/api/?name=Maya+A&background=06b6d4&color=0a0a0a&bold=true',
    action: 'Chat tentang Recovery',
    detail: 'Tips tidur optimal & foam rolling routine',
    category: 'recovery',
    timestamp: '2025-01-15T13:30:00Z',
  },
  {
    id: 'h7',
    userId: 'u7',
    userName: 'Fajar Hidayat',
    userAvatar: 'https://ui-avatars.com/api/?name=Fajar+H&background=22c55e&color=0a0a0a&bold=true',
    action: 'Meminta Meal Plan',
    detail: 'Sample meal plan 2050 kalori — sarapan, snack, lunch, dinner',
    category: 'nutrition',
    timestamp: '2025-01-15T14:10:00Z',
  },
  {
    id: 'h8',
    userId: 'u8',
    userName: 'Putri Rahayu',
    userAvatar: 'https://ui-avatars.com/api/?name=Putri+R&background=ec4899&color=ffffff&bold=true',
    action: 'Upgrade ke Premium',
    detail: 'Paket Tahunan — Rp 500.000 (Best Value!)',
    category: 'premium',
    timestamp: '2025-01-15T15:00:00Z',
  },
  {
    id: 'h9',
    userId: 'u9',
    userName: 'Dimas Arya',
    userAvatar: 'https://ui-avatars.com/api/?name=Dimas+A&background=8b5cf6&color=ffffff&bold=true',
    action: 'Meminta Workout Plan',
    detail: 'HIIT Cardio Blast — 6 latihan, 4 ronde, 30-40 menit',
    category: 'workout',
    timestamp: '2025-01-15T16:20:00Z',
  },
  {
    id: 'h10',
    userId: 'u10',
    userName: 'Lina Marlina',
    userAvatar: 'https://ui-avatars.com/api/?name=Lina+M&background=14b8a6&color=0a0a0a&bold=true',
    action: 'Chat tentang Weight Loss',
    detail: 'Strategi fat loss — defisit 300-500 kalori, macro split 40/30/30',
    category: 'nutrition',
    timestamp: '2025-01-15T17:00:00Z',
  },
  {
    id: 'h11',
    userId: 'u11',
    userName: 'Hendra Wijaya',
    userAvatar: 'https://ui-avatars.com/api/?name=Hendra+W&background=f97316&color=0a0a0a&bold=true',
    action: 'Meminta Workout Plan',
    detail: 'Arm Annihilator — Barbell Curls, Tricep Dips, Hammer Curls',
    category: 'workout',
    timestamp: '2025-01-14T08:00:00Z',
  },
  {
    id: 'h12',
    userId: 'u12',
    userName: 'Nadia Safitri',
    userAvatar: 'https://ui-avatars.com/api/?name=Nadia+S&background=0ea5e9&color=0a0a0a&bold=true',
    action: 'Chat tentang Beginner Guide',
    detail: 'Panduan pemula — 3x seminggu full body, mulai dari foundation',
    category: 'chat',
    timestamp: '2025-01-14T09:30:00Z',
  },
  {
    id: 'h13',
    userId: 'u13',
    userName: 'Agus Setiawan',
    userAvatar: 'https://ui-avatars.com/api/?name=Agus+S&background=84cc16&color=0a0a0a&bold=true',
    action: 'Upgrade ke Premium',
    detail: 'Paket Harian — Rp 10.000',
    category: 'premium',
    timestamp: '2025-01-14T10:15:00Z',
  },
  {
    id: 'h14',
    userId: 'u14',
    userName: 'Rina Wulandari',
    userAvatar: 'https://ui-avatars.com/api/?name=Rina+W&background=e11d48&color=ffffff&bold=true',
    action: 'Meminta Workout Plan',
    detail: 'Shoulder Sculptor — Overhead Press, Lateral Raises, Face Pulls',
    category: 'workout',
    timestamp: '2025-01-14T11:45:00Z',
  },
  {
    id: 'h15',
    userId: 'u15',
    userName: 'Yoga Pratama',
    userAvatar: 'https://ui-avatars.com/api/?name=Yoga+P&background=7c3aed&color=ffffff&bold=true',
    action: 'Konsultasi Bulking',
    detail: 'Clean bulking guide — surplus 300-500 kalori, protein 2g/kg',
    category: 'nutrition',
    timestamp: '2025-01-14T13:00:00Z',
  },
  {
    id: 'h16',
    userId: 'u16',
    userName: 'Anisa Fitri',
    userAvatar: 'https://ui-avatars.com/api/?name=Anisa+F&background=d946ef&color=ffffff&bold=true',
    action: 'Chat tentang Core Workout',
    detail: 'Core Crusher — Plank, Russian Twists, Hanging Leg Raises',
    category: 'workout',
    timestamp: '2025-01-14T14:30:00Z',
  },
  {
    id: 'h17',
    userId: 'u17',
    userName: 'Bayu Aji',
    userAvatar: 'https://ui-avatars.com/api/?name=Bayu+A&background=0d9488&color=ffffff&bold=true',
    action: 'Meminta Warm-up Routine',
    detail: 'Dynamic warm-up & mobility — 7 gerakan, 5-10 menit',
    category: 'recovery',
    timestamp: '2025-01-14T15:20:00Z',
  },
  {
    id: 'h18',
    userId: 'u18',
    userName: 'Citra Dewi',
    userAvatar: 'https://ui-avatars.com/api/?name=Citra+D&background=fb923c&color=0a0a0a&bold=true',
    action: 'Konsultasi BMI',
    detail: 'Hitung BMI & body composition — waist circumference tracking',
    category: 'chat',
    timestamp: '2025-01-14T16:00:00Z',
  },
  {
    id: 'h19',
    userId: 'u19',
    userName: 'Eko Prasetyo',
    userAvatar: 'https://ui-avatars.com/api/?name=Eko+P&background=65a30d&color=0a0a0a&bold=true',
    action: 'Upgrade ke Premium',
    detail: 'Paket Bulanan — Rp 100.000',
    category: 'premium',
    timestamp: '2025-01-13T08:30:00Z',
  },
  {
    id: 'h20',
    userId: 'u20',
    userName: 'Fitri Handayani',
    userAvatar: 'https://ui-avatars.com/api/?name=Fitri+H&background=0891b2&color=ffffff&bold=true',
    action: 'Meminta Full Body Workout',
    detail: 'Full Body Blitz — Squats, Bench, Rows, OHP, Deadlifts, Plank',
    category: 'workout',
    timestamp: '2025-01-13T10:00:00Z',
  },
];

export function getHistory(): HistoryEntry[] {
  return mockHistory;
}

export function addToHistory(entry: Omit<HistoryEntry, 'id' | 'timestamp'>): void {
  const newEntry: HistoryEntry = {
    ...entry,
    id: 'h-' + Date.now(),
    timestamp: new Date().toISOString(),
  };
  mockHistory.unshift(newEntry);
}

export const categoryLabels: Record<string, string> = {
  workout: '🏋️ Workout',
  nutrition: '🥗 Nutrisi',
  supplement: '💊 Supplement',
  recovery: '🧘 Recovery',
  chat: '💬 Chat',
  premium: '⭐ Premium',
};

export const categoryColors: Record<string, string> = {
  workout: 'bg-emerald-glow/10 text-emerald-glow border-emerald-glow/20',
  nutrition: 'bg-cyan-glow/10 text-cyan-glow border-cyan-glow/20',
  supplement: 'bg-purple-400/10 text-purple-400 border-purple-400/20',
  recovery: 'bg-orange-400/10 text-orange-400 border-orange-400/20',
  chat: 'bg-blue-400/10 text-blue-400 border-blue-400/20',
  premium: 'bg-yellow-400/10 text-yellow-400 border-yellow-400/20',
};
