// 80+ Languages Translation System
export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

export const languages: Language[] = [
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', flag: '🇮🇩' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', flag: '🇰🇷' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', flag: '🇧🇩' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', flag: '🇵🇰' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی', flag: '🇮🇷' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย', flag: '🇹🇭' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', flag: '🇻🇳' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu', flag: '🇲🇾' },
  { code: 'tl', name: 'Filipino', nativeName: 'Filipino', flag: '🇵🇭' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', flag: '🇳🇱' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski', flag: '🇵🇱' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', flag: '🇺🇦' },
  { code: 'ro', name: 'Romanian', nativeName: 'Română', flag: '🇷🇴' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', flag: '🇬🇷' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština', flag: '🇨🇿' },
  { code: 'hu', name: 'Hungarian', nativeName: 'Magyar', flag: '🇭🇺' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska', flag: '🇸🇪' },
  { code: 'da', name: 'Danish', nativeName: 'Dansk', flag: '🇩🇰' },
  { code: 'no', name: 'Norwegian', nativeName: 'Norsk', flag: '🇳🇴' },
  { code: 'fi', name: 'Finnish', nativeName: 'Suomi', flag: '🇫🇮' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', flag: '🇮🇱' },
  { code: 'bg', name: 'Bulgarian', nativeName: 'Български', flag: '🇧🇬' },
  { code: 'hr', name: 'Croatian', nativeName: 'Hrvatski', flag: '🇭🇷' },
  { code: 'sk', name: 'Slovak', nativeName: 'Slovenčina', flag: '🇸🇰' },
  { code: 'sl', name: 'Slovenian', nativeName: 'Slovenščina', flag: '🇸🇮' },
  { code: 'sr', name: 'Serbian', nativeName: 'Српски', flag: '🇷🇸' },
  { code: 'lt', name: 'Lithuanian', nativeName: 'Lietuvių', flag: '🇱🇹' },
  { code: 'lv', name: 'Latvian', nativeName: 'Latviešu', flag: '🇱🇻' },
  { code: 'et', name: 'Estonian', nativeName: 'Eesti', flag: '🇪🇪' },
  { code: 'mt', name: 'Maltese', nativeName: 'Malti', flag: '🇲🇹' },
  { code: 'ga', name: 'Irish', nativeName: 'Gaeilge', flag: '🇮🇪' },
  { code: 'cy', name: 'Welsh', nativeName: 'Cymraeg', flag: '🏴󠁧󠁢󠁷󠁬󠁳󠁿' },
  { code: 'eu', name: 'Basque', nativeName: 'Euskara', flag: '🇪🇸' },
  { code: 'ca', name: 'Catalan', nativeName: 'Català', flag: '🇪🇸' },
  { code: 'gl', name: 'Galician', nativeName: 'Galego', flag: '🇪🇸' },
  { code: 'is', name: 'Icelandic', nativeName: 'Íslenska', flag: '🇮🇸' },
  { code: 'sq', name: 'Albanian', nativeName: 'Shqip', flag: '🇦🇱' },
  { code: 'mk', name: 'Macedonian', nativeName: 'Македонски', flag: '🇲🇰' },
  { code: 'bs', name: 'Bosnian', nativeName: 'Bosanski', flag: '🇧🇦' },
  { code: 'ka', name: 'Georgian', nativeName: 'ქართული', flag: '🇬🇪' },
  { code: 'hy', name: 'Armenian', nativeName: 'Հայերեն', flag: '🇦🇲' },
  { code: 'az', name: 'Azerbaijani', nativeName: 'Azərbaycan', flag: '🇦🇿' },
  { code: 'kk', name: 'Kazakh', nativeName: 'Қазақ', flag: '🇰🇿' },
  { code: 'uz', name: 'Uzbek', nativeName: 'Oʻzbek', flag: '🇺🇿' },
  { code: 'mn', name: 'Mongolian', nativeName: 'Монгол', flag: '🇲🇳' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली', flag: '🇳🇵' },
  { code: 'si', name: 'Sinhala', nativeName: 'සිංහල', flag: '🇱🇰' },
  { code: 'km', name: 'Khmer', nativeName: 'ខ្មែរ', flag: '🇰🇭' },
  { code: 'lo', name: 'Lao', nativeName: 'ລາວ', flag: '🇱🇦' },
  { code: 'my', name: 'Burmese', nativeName: 'မြန်မာ', flag: '🇲🇲' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', flag: '🇰🇪' },
  { code: 'am', name: 'Amharic', nativeName: 'አማርኛ', flag: '🇪🇹' },
  { code: 'ha', name: 'Hausa', nativeName: 'Hausa', flag: '🇳🇬' },
  { code: 'yo', name: 'Yoruba', nativeName: 'Yorùbá', flag: '🇳🇬' },
  { code: 'ig', name: 'Igbo', nativeName: 'Igbo', flag: '🇳🇬' },
  { code: 'zu', name: 'Zulu', nativeName: 'isiZulu', flag: '🇿🇦' },
  { code: 'xh', name: 'Xhosa', nativeName: 'isiXhosa', flag: '🇿🇦' },
  { code: 'af', name: 'Afrikaans', nativeName: 'Afrikaans', flag: '🇿🇦' },
  { code: 'mg', name: 'Malagasy', nativeName: 'Malagasy', flag: '🇲🇬' },
  { code: 'so', name: 'Somali', nativeName: 'Soomaali', flag: '🇸🇴' },
  { code: 'rw', name: 'Kinyarwanda', nativeName: 'Kinyarwanda', flag: '🇷🇼' },
  { code: 'sm', name: 'Samoan', nativeName: 'Gagana Sāmoa', flag: '🇼🇸' },
  { code: 'to', name: 'Tongan', nativeName: 'Lea Faka-Tonga', flag: '🇹🇴' },
  { code: 'fj', name: 'Fijian', nativeName: 'Vosa Vakaviti', flag: '🇫🇯' },
  { code: 'mi', name: 'Maori', nativeName: 'Te Reo Māori', flag: '🇳🇿' },
  { code: 'haw', name: 'Hawaiian', nativeName: 'ʻŌlelo Hawaiʻi', flag: '🇺🇸' },
];

export interface Translations {
  // Navbar
  home: string;
  chat: string;
  history: string;
  premium: string;
  login: string;
  logout: string;
  createdBy: string;
  dashboard: string;
  security: string;
  
  // Landing
  welcomeTo: string;
  yourPersonal: string;
  fitnessAI: string;
  coach: string;
  heroDescription: string;
  startChatting: string;
  learnMore: string;
  features: string;
  testimonials: string;
  pricing: string;
  everythingYouNeed: string;
  everythingYouNeedDesc: string;
  getFit: string;
  trainSmart: string;
  eatSmart: string;
  lovedBy: string;
  readyToTransform: string;
  readyToTransformDesc: string;
  startJourney: string;
  
  // Features
  customWorkouts: string;
  customWorkoutsDesc: string;
  nutritionGuidance: string;
  nutritionGuidanceDesc: string;
  aiPowered: string;
  aiPoweredDesc: string;
  recoveryTips: string;
  recoveryTipsDesc: string;
  instantAnswers: string;
  instantAnswersDesc: string;
  allLevels: string;
  allLevelsDesc: string;
  workoutPlans: string;
  aiAvailability: string;
  happyUsers: string;
  userRating: string;
  
  // Chat
  askAbout: string;
  chatPlaceholder: string;
  newChat: string;
  quickActions: string;
  
  // Pricing
  choosePlan: string;
  premiumPlans: string;
  daily: string;
  monthly: string;
  yearly: string;
  perDay: string;
  perMonth: string;
  perYear: string;
  subscribe: string;
  mostPopular: string;
  save: string;
  tryWithoutCommitment: string;
  bestForResults: string;
  bestInvestment: string;
  unlimitedChat: string;
  allWorkoutPlans: string;
  completeNutrition: string;
  chatHistory: string;
  customMealPlan: string;
  exclusiveVideos: string;
  oneOnOneConsult: string;
  freePlan: string;
  activeNow: string;
  chatsPerDay: string;
  basicWorkouts: string;
  generalNutrition: string;
  paymentMethods: string;
  sendProof: string;
  sendProofDesc: string;
  sendViaWhatsapp: string;
  includeProof: string;
  guarantee: string;
  faq: string;
  
  // History
  activityHistory: string;
  userActivity: string;
  totalUsers: string;
  totalActivity: string;
  premiumUpgrades: string;
  workoutRequests: string;
  loginToViewHistory: string;
  historyDescription: string;
  searchActivity: string;
  allCategories: string;
  workout: string;
  nutrition: string;
  supplement: string;
  recovery: string;
  chatCategory: string;
  premiumCategory: string;
  justNow: string;
  hoursAgo: string;
  daysAgo: string;
  showingActivities: string;
  
  // Dashboard
  welcomeBack: string;
  trackProgress: string;
  overview: string;
  workoutTab: string;
  body: string;
  water: string;
  challenges: string;
  workouts: string;
  streak: string;
  waterToday: string;
  badges: string;
  yourBadges: string;
  recentWorkouts: string;
  todaysChallenges: string;
  noWorkoutsYet: string;
  noChallengesToday: string;
  exercises: string;
  min: string;
  level: string;
  xpToNextLevel: string;
  logWorkout: string;
  workoutType: string;
  duration: string;
  saveWorkout: string;
  addMeasurement: string;
  weight: string;
  bodyFat: string;
  saveMeasurement: string;
  noMeasurementsYet: string;
  quickAdd: string;
  dailyChallenges: string;
  noChallengesForToday: string;
  checkBackTomorrow: string;
  reward: string;
  completed: string;
  
  // Login Modal
  welcomeToFitbot: string;
  loginDescription: string;
  continueWithGoogle: string;
  continueWithFacebook: string;
  loadingGoogle: string;
  loadingFacebook: string;
  googleInfo: string;
  facebookInfo: string;
  withLoginYouGet: string;
  unlimitedAccess: string;
  savedConversations: string;
  exclusiveWorkouts: string;
  termsAgreement: string;
  loginFailed: string;
  
  // Security
  securityDashboard: string;
  monitorActivity: string;
  totalEvents: string;
  low: string;
  medium: string;
  high: string;
  critical: string;
  currentDevice: string;
  browser: string;
  platform: string;
  screenResolution: string;
  timezone: string;
  ipAddress: string;
  location: string;
  isp: string;
  deviceId: string;
  clearAllEvents: string;
  exportJson: string;
  sendManualAlert: string;
  writeAlertMessage: string;
  send: string;
  filterByLevel: string;
  noSecurityEvents: string;
  deviceInfo: string;
  networkInfo: string;
  page: string;
  notified: string;
  yes: string;
  no: string;
  additionalData: string;
  
  // Payment Modal
  paymentSuccess: string;
  activatingPremium: string;
  analyzingProof: string;
  aiCheckingImage: string;
  progress: string;
  checkingMetadata: string;
  analyzingDimensions: string;
  scanningPixels: string;
  detectingNoise: string;
  verifyingFormat: string;
  generatingReport: string;
  verifiedOriginal: string;
  detectedAiEdited: string;
  authenticityScore: string;
  analysisDetails: string;
  paymentRejected: string;
  paymentRejectedDesc: string;
  dontForgetSendProof: string;
  sendProofDesc2: string;
  reupload: string;
  activatePremium: string;
  uploadProof: string;
  uploadProofDesc: string;
  packageLabel: string;
  dragDropImage: string;
  orClickToSelect: string;
  maxFileSize: string;
  viewFull: string;
  aiDetectionWarning: string;
  aiDetectionDesc: string;
  uploadTips: string;
  tip1: string;
  tip2: string;
  tip3: string;
  tip4: string;
  backToPayment: string;
  analyzeProof: string;
  payment: string;
  selectPaymentMethod: string;
  transferViaDana: string;
  danaNumber: string;
  copied: string;
  copy: string;
  accountName: string;
  bankTransfer: string;
  bankTransferDesc: string;
  accountNumber: string;
  paymentInstructions: string;
  instruction1: string;
  instruction2: string;
  instruction3: string;
  instruction4: string;
  instruction5: string;
  instruction6: string;
  iHavePaid: string;
  
  // Common
  loading: string;
  error: string;
  success: string;
  cancel: string;
  confirm: string;
  close: string;
  back: string;
  next: string;
  previous: string;
  search: string;
  filter: string;
  all: string;
  language: string;
  selectLanguage: string;
  days: string;
}

export const translations: Record<string, Translations> = {
  id: {
    home: 'Beranda', chat: 'Chat', history: 'Riwayat', premium: 'Premium', login: 'Masuk', logout: 'Keluar', createdBy: 'Dibuat oleh', dashboard: 'Dashboard', security: 'Keamanan',
    welcomeTo: 'Selamat Datang di', yourPersonal: 'Asisten Kebugaran', fitnessAI: 'AI', coach: 'Pribadi Anda', heroDescription: 'Dapatkan rencana latihan instan, saran nutrisi, dan panduan kebugaran ahli yang didukung AI.', startChatting: 'Mulai Chatting Gratis', learnMore: 'Pelajari Lebih Lanjut', features: 'Fitur', testimonials: 'Testimoni', pricing: 'Harga',
    everythingYouNeed: 'Semua yang Anda Butuhkan untuk', everythingYouNeedDesc: 'Didukung AI, dirancang untuk hasil nyata', getFit: 'Bugar', trainSmart: 'Latihan Cerdas,', eatSmart: 'Makan Cerdas', lovedBy: 'Disukai oleh', readyToTransform: 'Siap Mengubah', readyToTransformDesc: 'Bergabunglah dengan ribuan orang yang mencapai tujuan kebugaran mereka', startJourney: 'Mulai Perjalanan Anda',
    customWorkouts: 'Latihan Kustom', customWorkoutsDesc: 'Rencana latihan personal untuk kelompok otot manapun', nutritionGuidance: 'Panduan Nutrisi', nutritionGuidanceDesc: 'Saran ahli tentang protein, perencanaan makan', aiPowered: 'Didukung AI', aiPoweredDesc: 'Respons cerdas disesuaikan dengan level Anda', recoveryTips: 'Tips Pemulihan', recoveryTipsDesc: 'Strategi istirahat optimal dan rutinitas peregangan', instantAnswers: 'Jawaban Instan', instantAnswersDesc: 'Saran kebugaran berbasis sains 24/7', allLevels: 'Semua Level', allLevelsDesc: 'FitBot beradaptasi dengan level Anda',
    workoutPlans: 'Rencana Latihan', aiAvailability: 'Ketersediaan AI', happyUsers: 'Pengguna Puas', userRating: 'Rating Pengguna',
    askAbout: 'Tanya tentang', chatPlaceholder: 'Tanya tentang latihan, nutrisi, suplemen...', newChat: 'Chat Baru', quickActions: 'Aksi Cepat',
    choosePlan: 'Pilih Paket', premiumPlans: 'Paket Premium', daily: 'Harian', monthly: 'Bulanan', yearly: 'Tahunan', perDay: 'per hari', perMonth: 'per bulan', perYear: 'per tahun', subscribe: 'Berlangganan', mostPopular: 'Paling Populer', save: 'Hemat', tryWithoutCommitment: 'Coba premium tanpa komitmen panjang', bestForResults: 'Pilihan terbaik untuk hasil maksimal', bestInvestment: 'Investasi terbaik untuk transformasi total', unlimitedChat: 'Unlimited AI Chat', allWorkoutPlans: 'Semua Workout Plans', completeNutrition: 'Panduan Nutrisi Lengkap', chatHistory: 'Riwayat Chat Tersimpan', customMealPlan: 'Custom Meal Plan', exclusiveVideos: 'Video Tutorial Eksklusif', oneOnOneConsult: 'Konsultasi 1-on-1', freePlan: 'Paket Gratis', activeNow: 'Aktif Sekarang', chatsPerDay: '5 chat AI per hari', basicWorkouts: 'Workout plan dasar', generalNutrition: 'Tips nutrisi umum', paymentMethods: 'Metode Pembayaran', sendProof: 'Kirim Bukti Pembayaran', sendProofDesc: 'Wajib kirim screenshot bukti transfer ke admin', sendViaWhatsapp: 'Kirim Bukti via WhatsApp', includeProof: 'Sertakan nama paket yang dipilih', guarantee: 'Garansi uang kembali 7 hari', faq: 'Pertanyaan Umum',
    activityHistory: 'Riwayat Aktivitas', userActivity: 'Aktivitas Pengguna', totalUsers: 'Total Pengguna', totalActivity: 'Total Aktivitas', premiumUpgrades: 'Upgrade Premium', workoutRequests: 'Permintaan Latihan', loginToViewHistory: 'Login untuk Melihat Riwayat', historyDescription: 'Laporan aktivitas pengguna', searchActivity: 'Cari pengguna atau aktivitas...', allCategories: 'Semua', workout: 'Workout', nutrition: 'Nutrisi', supplement: 'Supplement', recovery: 'Recovery', chatCategory: 'Chat', premiumCategory: 'Premium', justNow: 'Baru saja', hoursAgo: 'jam lalu', daysAgo: 'hari lalu', showingActivities: 'Menampilkan',
    welcomeBack: 'Selamat datang kembali', trackProgress: 'Pantau kemajuan dan capai target kebugaran Anda', overview: 'Ringkasan', workoutTab: 'Latihan', body: 'Tubuh', water: 'Air', challenges: 'Tantangan', workouts: 'Latihan', streak: 'Streak', waterToday: 'Air Hari Ini', badges: 'Badge', yourBadges: 'Badge Anda', recentWorkouts: 'Latihan Terbaru', todaysChallenges: 'Tantangan Hari Ini', noWorkoutsYet: 'Belum ada latihan', noChallengesToday: 'Tidak ada tantangan', exercises: 'latihan', min: 'mnt', level: 'Level', xpToNextLevel: 'XP ke level berikutnya', logWorkout: 'Catat Latihan', workoutType: 'Jenis Latihan', duration: 'Durasi', saveWorkout: 'Simpan Latihan', addMeasurement: 'Tambah Pengukuran', weight: 'Berat', bodyFat: 'Lemak Tubuh', saveMeasurement: 'Simpan Pengukuran', noMeasurementsYet: 'Belum ada pengukuran', quickAdd: 'Tambah Cepat', dailyChallenges: 'Tantangan Harian', noChallengesForToday: 'Tidak ada tantangan untuk hari ini', checkBackTomorrow: 'Periksa kembali besok!', reward: 'Hadiah', completed: 'Selesai',
    welcomeToFitbot: 'Selamat Datang di FitBot AI', loginDescription: 'Masuk untuk mengakses semua fitur premium', continueWithGoogle: 'Lanjutkan dengan Google', continueWithFacebook: 'Lanjutkan dengan Facebook', loadingGoogle: 'Memuat akun Google...', loadingFacebook: 'Mengarahkan ke Facebook...', googleInfo: 'Google: Akan menampilkan akun Google yang sudah login', facebookInfo: 'Facebook: Akan mengarahkan ke halaman login Facebook', withLoginYouGet: 'Dengan login kamu dapat:', unlimitedAccess: 'Akses unlimited chat AI fitness', savedConversations: 'Riwayat percakapan tersimpan', exclusiveWorkouts: 'Workout plan premium eksklusif', termsAgreement: 'Dengan login, kamu menyetujui Syarat & Ketentuan', loginFailed: 'Login gagal. Silakan coba lagi.',
    securityDashboard: 'Dashboard Keamanan', monitorActivity: 'Pantau aktivitas mencurigakan', totalEvents: 'Total Event', low: 'Rendah', medium: 'Sedang', high: 'Tinggi', critical: 'Kritis', currentDevice: 'Informasi Perangkat Saat Ini', browser: 'Browser', platform: 'Platform', screenResolution: 'Resolusi Layar', timezone: 'Timezone', ipAddress: 'IP Address', location: 'Lokasi', isp: 'ISP', deviceId: 'Device ID', clearAllEvents: 'Hapus Semua Event', exportJson: 'Export JSON', sendManualAlert: 'Kirim Alert Manual', writeAlertMessage: 'Tulis pesan alert...', send: 'Kirim', filterByLevel: 'Filter', noSecurityEvents: 'Tidak ada event keamanan', deviceInfo: 'Informasi Perangkat', networkInfo: 'Informasi Jaringan', page: 'Halaman', notified: 'Notified', yes: 'Ya', no: 'Tidak', additionalData: 'Data Tambahan',
    loading: 'Memuat', error: 'Error', success: 'Berhasil', cancel: 'Batal', confirm: 'Konfirmasi', close: 'Tutup', back: 'Kembali', next: 'Selanjutnya', previous: 'Sebelumnya', search: 'Cari', filter: 'Filter', all: 'Semua', language: 'Bahasa', selectLanguage: 'Pilih Bahasa', days: 'hari',
    paymentSuccess: 'Pembayaran Berhasil!', activatingPremium: 'Mengaktifkan premium Anda...', analyzingProof: 'Menganalisis Bukti Pembayaran', aiCheckingImage: 'AI sedang memeriksa gambar...', progress: 'Proses', checkingMetadata: 'Memeriksa metadata...', analyzingDimensions: 'Menganalisis dimensi...', scanningPixels: 'Memindai piksel...', detectingNoise: 'Mendeteksi noise...', verifyingFormat: 'Memverifikasi format...', generatingReport: 'Membuat laporan...', verifiedOriginal: 'Terverifikasi Asli', detectedAiEdited: 'Terdeteksi AI/Edit', authenticityScore: 'Skor Keaslian', analysisDetails: 'Detail Analisis', paymentRejected: 'Pembayaran Ditolak', paymentRejectedDesc: 'Bukti pembayaran yang Anda unggah terdeteksi telah dimanipulasi menggunakan AI atau software editing. Silakan unggah screenshot asli dari aplikasi DANA atau mobile banking Anda.', dontForgetSendProof: 'Jangan Lupa Kirim Bukti!', sendProofDesc2: 'Kirim juga screenshot bukti pembayaran ke WhatsApp admin di nomor', reupload: 'Unggah Ulang', activatePremium: 'Aktifkan Premium', uploadProof: 'Unggah Bukti Pembayaran', uploadProofDesc: 'Unggah screenshot bukti transfer Anda', packageLabel: 'Paket', dragDropImage: 'Drag & drop gambar di sini', orClickToSelect: 'atau klik untuk memilih file', maxFileSize: 'Maks 15MB', viewFull: 'Lihat Penuh', aiDetectionWarning: '⚠️ Peringatan Deteksi AI', aiDetectionDesc: 'Sistem kami akan menganalisis keaslian gambar menggunakan AI scanner. Jika terdeteksi bahwa gambar telah diedit menggunakan AI, bukti pembayaran akan ditolak.', uploadTips: '💡 Tips Unggah:', tip1: 'Screenshot langsung dari aplikasi DANA / mobile banking', tip2: 'Jangan edit, crop, atau filter gambar', tip3: 'Pastikan terlihat: nama penerima, jumlah, dan tanggal transfer', tip4: 'Unggah gambar original tanpa kompresi', backToPayment: '← Kembali ke Pembayaran', analyzeProof: 'Analisis Bukti Pembayaran', payment: 'Pembayaran', selectPaymentMethod: 'Pilih metode pembayaran', transferViaDana: 'Transfer via DANA e-wallet', danaNumber: 'Nomor DANA:', copied: 'Tersalin!', copy: 'Salin', accountName: 'a.n. Muhammad Geovanny Iskandar', bankTransfer: 'Transfer Bank / Virtual Account', bankTransferDesc: 'Transfer via bank atau virtual account', accountNumber: 'Nomor Rekening:', paymentInstructions: 'Cara Pembayaran:', instruction1: 'Pilih salah satu metode pembayaran di atas', instruction2: 'Transfer sesuai paket yang dipilih', instruction3: 'Klik "Saya Sudah Bayar" lalu unggah screenshot bukti transfer', instruction4: 'Kirim bukti pembayaran ke nomor 082161387805 (WhatsApp)', instruction5: 'Sistem akan memverifikasi keaslian bukti pembayaran', instruction6: 'Premium aktif setelah bukti terverifikasi asli ✅', iHavePaid: 'Saya Sudah Bayar',
  },
  en: {
    home: 'Home', chat: 'Chat', history: 'History', premium: 'Premium', login: 'Login', logout: 'Logout', createdBy: 'Created by', dashboard: 'Dashboard', security: 'Security',
    welcomeTo: 'Welcome to', yourPersonal: 'Your Personal', fitnessAI: 'Fitness AI', coach: 'Coach', heroDescription: 'Get instant workout plans, nutrition advice, and expert fitness guidance powered by AI.', startChatting: 'Start Chatting Free', learnMore: 'Learn More', features: 'Features', testimonials: 'Testimonials', pricing: 'Pricing',
    everythingYouNeed: 'Everything You Need to', everythingYouNeedDesc: 'Powered by AI, designed for real results', getFit: 'Get Fit', trainSmart: 'Train Smart,', eatSmart: 'Eat Smart', lovedBy: 'Loved by', readyToTransform: 'Ready to Transform', readyToTransformDesc: 'Join thousands who are achieving their fitness goals', startJourney: 'Start Your Journey',
    customWorkouts: 'Custom Workouts', customWorkoutsDesc: 'Personalized workout plans for any muscle group', nutritionGuidance: 'Nutrition Guidance', nutritionGuidanceDesc: 'Expert advice on protein intake, meal planning', aiPowered: 'AI-Powered', aiPoweredDesc: 'Smart responses tailored to your fitness level', recoveryTips: 'Recovery Tips', recoveryTipsDesc: 'Optimal rest strategies and stretching routines', instantAnswers: 'Instant Answers', instantAnswersDesc: 'Science-backed fitness advice 24/7', allLevels: 'All Levels', allLevelsDesc: 'FitBot adapts to your level',
    workoutPlans: 'Workout Plans', aiAvailability: 'AI Availability', happyUsers: 'Happy Users', userRating: 'User Rating',
    askAbout: 'Ask about', chatPlaceholder: 'Ask about workouts, nutrition, supplements...', newChat: 'New Chat', quickActions: 'Quick Actions',
    choosePlan: 'Choose Plan', premiumPlans: 'Premium Plans', daily: 'Daily', monthly: 'Monthly', yearly: 'Yearly', perDay: 'per day', perMonth: 'per month', perYear: 'per year', subscribe: 'Subscribe', mostPopular: 'Most Popular', save: 'Save', tryWithoutCommitment: 'Try premium without long-term commitment', bestForResults: 'Best choice for maximum results', bestInvestment: 'Best investment for total transformation', unlimitedChat: 'Unlimited AI Chat', allWorkoutPlans: 'All Workout Plans', completeNutrition: 'Complete Nutrition Guide', chatHistory: 'Saved Chat History', customMealPlan: 'Custom Meal Plan', exclusiveVideos: 'Exclusive Video Tutorials', oneOnOneConsult: '1-on-1 Consultation', freePlan: 'Free Plan', activeNow: 'Active Now', chatsPerDay: '5 AI chats per day', basicWorkouts: 'Basic workout plans', generalNutrition: 'General nutrition tips', paymentMethods: 'Payment Methods', sendProof: 'Send Payment Proof', sendProofDesc: 'Required to send transfer proof screenshot to admin', sendViaWhatsapp: 'Send Proof via WhatsApp', includeProof: 'Include selected package name', guarantee: '7-day money-back guarantee', faq: 'Frequently Asked Questions',
    activityHistory: 'Activity History', userActivity: 'User Activity', totalUsers: 'Total Users', totalActivity: 'Total Activity', premiumUpgrades: 'Premium Upgrades', workoutRequests: 'Workout Requests', loginToViewHistory: 'Login to View History', historyDescription: 'User activity reports', searchActivity: 'Search users or activities...', allCategories: 'All', workout: 'Workout', nutrition: 'Nutrition', supplement: 'Supplement', recovery: 'Recovery', chatCategory: 'Chat', premiumCategory: 'Premium', justNow: 'Just now', hoursAgo: 'hours ago', daysAgo: 'days ago', showingActivities: 'Showing',
    welcomeBack: 'Welcome back', trackProgress: 'Track your progress and achieve your fitness goals', overview: 'Overview', workoutTab: 'Workout', body: 'Body', water: 'Water', challenges: 'Challenges', workouts: 'Workouts', streak: 'Streak', waterToday: 'Water Today', badges: 'Badges', yourBadges: 'Your Badges', recentWorkouts: 'Recent Workouts', todaysChallenges: "Today's Challenges", noWorkoutsYet: 'No workouts yet', noChallengesToday: 'No challenges today', exercises: 'exercises', min: 'min', level: 'Level', xpToNextLevel: 'XP to next level', logWorkout: 'Log Workout', workoutType: 'Workout Type', duration: 'Duration', saveWorkout: 'Save Workout', addMeasurement: 'Add Measurement', weight: 'Weight', bodyFat: 'Body Fat', saveMeasurement: 'Save Measurement', noMeasurementsYet: 'No measurements yet', quickAdd: 'Quick Add', dailyChallenges: 'Daily Challenges', noChallengesForToday: 'No challenges for today', checkBackTomorrow: 'Check back tomorrow!', reward: 'Reward', completed: 'Completed',
    welcomeToFitbot: 'Welcome to FitBot AI', loginDescription: 'Login to access all premium features', continueWithGoogle: 'Continue with Google', continueWithFacebook: 'Continue with Facebook', loadingGoogle: 'Loading Google account...', loadingFacebook: 'Redirecting to Facebook...', googleInfo: 'Google: Will show Google accounts already logged in', facebookInfo: 'Facebook: Will redirect to Facebook login page', withLoginYouGet: 'With login you get:', unlimitedAccess: 'Unlimited AI fitness chat access', savedConversations: 'Saved conversation history', exclusiveWorkouts: 'Exclusive premium workout plans', termsAgreement: 'By logging in, you agree to Terms & Conditions', loginFailed: 'Login failed. Please try again.',
    securityDashboard: 'Security Dashboard', monitorActivity: 'Monitor suspicious activity', totalEvents: 'Total Events', low: 'Low', medium: 'Medium', high: 'High', critical: 'Critical', currentDevice: 'Current Device Information', browser: 'Browser', platform: 'Platform', screenResolution: 'Screen Resolution', timezone: 'Timezone', ipAddress: 'IP Address', location: 'Location', isp: 'ISP', deviceId: 'Device ID', clearAllEvents: 'Clear All Events', exportJson: 'Export JSON', sendManualAlert: 'Send Manual Alert', writeAlertMessage: 'Write alert message...', send: 'Send', filterByLevel: 'Filter', noSecurityEvents: 'No security events', deviceInfo: 'Device Information', networkInfo: 'Network Information', page: 'Page', notified: 'Notified', yes: 'Yes', no: 'No', additionalData: 'Additional Data',
    loading: 'Loading', error: 'Error', success: 'Success', cancel: 'Cancel', confirm: 'Confirm', close: 'Close', back: 'Back', next: 'Next', previous: 'Previous', search: 'Search', filter: 'Filter', all: 'All', language: 'Language', selectLanguage: 'Select Language', days: 'days',
    paymentSuccess: 'Payment Successful!', activatingPremium: 'Activating your premium...', analyzingProof: 'Analyzing Payment Proof', aiCheckingImage: 'AI is checking the image...', progress: 'Progress', checkingMetadata: 'Checking metadata...', analyzingDimensions: 'Analyzing dimensions...', scanningPixels: 'Scanning pixels...', detectingNoise: 'Detecting noise...', verifyingFormat: 'Verifying format...', generatingReport: 'Generating report...', verifiedOriginal: 'Verified Original', detectedAiEdited: 'Detected AI/Edited', authenticityScore: 'Authenticity Score', analysisDetails: 'Analysis Details', paymentRejected: 'Payment Rejected', paymentRejectedDesc: 'The payment proof you uploaded has been detected as manipulated using AI or editing software. Please upload an original screenshot from your DANA app or mobile banking.', dontForgetSendProof: "Don't Forget to Send Proof!", sendProofDesc2: 'Also send the payment proof screenshot to admin WhatsApp at number', reupload: 'Re-upload', activatePremium: 'Activate Premium', uploadProof: 'Upload Payment Proof', uploadProofDesc: 'Upload your transfer proof screenshot', packageLabel: 'Package', dragDropImage: 'Drag & drop image here', orClickToSelect: 'or click to select file', maxFileSize: 'Max 15MB', viewFull: 'View Full', aiDetectionWarning: '⚠️ AI Detection Warning', aiDetectionDesc: 'Our system will analyze the authenticity of the image using AI scanner. If the image is detected as edited using AI, the payment proof will be rejected.', uploadTips: '💡 Upload Tips:', tip1: 'Screenshot directly from DANA app / mobile banking', tip2: "Don't edit, crop, or filter the image", tip3: 'Make sure visible: recipient name, amount, and transfer date', tip4: 'Upload original image without compression', backToPayment: '← Back to Payment', analyzeProof: 'Analyze Payment Proof', payment: 'Payment', selectPaymentMethod: 'Select payment method', transferViaDana: 'Transfer via DANA e-wallet', danaNumber: 'DANA Number:', copied: 'Copied!', copy: 'Copy', accountName: 'a.n. Muhammad Geovanny Iskandar', bankTransfer: 'Bank Transfer / Virtual Account', bankTransferDesc: 'Transfer via bank or virtual account', accountNumber: 'Account Number:', paymentInstructions: 'Payment Instructions:', instruction1: 'Choose one of the payment methods above', instruction2: 'Transfer according to the selected package', instruction3: 'Click "I Have Paid" then upload transfer proof screenshot', instruction4: 'Send payment proof to number 082161387805 (WhatsApp)', instruction5: 'System will verify the authenticity of payment proof', instruction6: 'Premium activates after proof is verified as original ✅', iHavePaid: 'I Have Paid',
  },
  es: {
    home: 'Inicio', chat: 'Chat', history: 'Historial', premium: 'Premium', login: 'Iniciar Sesión', logout: 'Cerrar Sesión', createdBy: 'Creado por', dashboard: 'Panel', security: 'Seguridad',
    welcomeTo: 'Bienvenido a', yourPersonal: 'Tu Asistente de', fitnessAI: 'Fitness AI', coach: 'Personal', heroDescription: 'Obtén planes de entrenamiento instantáneos y consejos nutricionales impulsados por IA.', startChatting: 'Comenzar a Chatear Gratis', learnMore: 'Más Información', features: 'Características', testimonials: 'Testimonios', pricing: 'Precios',
    everythingYouNeed: 'Todo lo que Necesitas para', everythingYouNeedDesc: 'Impulsado por IA, diseñado para resultados reales', getFit: 'Ponerte en Forma', trainSmart: 'Entrena Inteligente,', eatSmart: 'Come Inteligente', lovedBy: 'Amado por', readyToTransform: 'Listo para Transformar', readyToTransformDesc: 'Únete a miles que están logrando sus objetivos de fitness', startJourney: 'Comienza Tu Viaje',
    customWorkouts: 'Entrenamientos Personalizados', customWorkoutsDesc: 'Planes personalizados para cualquier grupo muscular', nutritionGuidance: 'Guía Nutricional', nutritionGuidanceDesc: 'Consejos expertos sobre proteínas y comidas', aiPowered: 'Impulsado por IA', aiPoweredDesc: 'Respuestas inteligentes adaptadas a tu nivel', recoveryTips: 'Consejos de Recuperación', recoveryTipsDesc: 'Estrategias óptimas de descanso', instantAnswers: 'Respuestas Instantáneas', instantAnswersDesc: 'Consejos de fitness 24/7', allLevels: 'Todos los Niveles', allLevelsDesc: 'FitBot se adapta a tu nivel',
    workoutPlans: 'Planes de Entrenamiento', aiAvailability: 'Disponibilidad IA', happyUsers: 'Usuarios Felices', userRating: 'Calificación',
    askAbout: 'Pregunta sobre', chatPlaceholder: 'Pregunta sobre entrenamientos, nutrición...', newChat: 'Nuevo Chat', quickActions: 'Acciones Rápidas',
    choosePlan: 'Elegir Plan', premiumPlans: 'Planes Premium', daily: 'Diario', monthly: 'Mensual', yearly: 'Anual', perDay: 'por día', perMonth: 'por mes', perYear: 'por año', subscribe: 'Suscribirse', mostPopular: 'Más Popular', save: 'Ahorra', tryWithoutCommitment: 'Prueba premium sin compromiso', bestForResults: 'Mejor opción para resultados máximos', bestInvestment: 'Mejor inversión para transformación total', unlimitedChat: 'Chat IA Ilimitado', allWorkoutPlans: 'Todos los Planes', completeNutrition: 'Guía Nutricional Completa', chatHistory: 'Historial Guardado', customMealPlan: 'Plan de Comidas', exclusiveVideos: 'Videos Exclusivos', oneOnOneConsult: 'Consulta 1 a 1', freePlan: 'Plan Gratuito', activeNow: 'Activo Ahora', chatsPerDay: '5 chats IA por día', basicWorkouts: 'Planes básicos', generalNutrition: 'Consejos generales', paymentMethods: 'Métodos de Pago', sendProof: 'Enviar Comprobante', sendProofDesc: 'Enviar captura al admin', sendViaWhatsapp: 'Enviar vía WhatsApp', includeProof: 'Incluir nombre del paquete', guarantee: 'Garantía de 7 días', faq: 'Preguntas Frecuentes',
    activityHistory: 'Historial de Actividad', userActivity: 'Actividad del Usuario', totalUsers: 'Total Usuarios', totalActivity: 'Actividad Total', premiumUpgrades: 'Mejoras Premium', workoutRequests: 'Solicitudes', loginToViewHistory: 'Inicia Sesión para Ver Historial', historyDescription: 'Informes de actividad', searchActivity: 'Buscar usuarios...', allCategories: 'Todas', workout: 'Entrenamiento', nutrition: 'Nutrición', supplement: 'Suplemento', recovery: 'Recuperación', chatCategory: 'Chat', premiumCategory: 'Premium', justNow: 'Ahora', hoursAgo: 'horas atrás', daysAgo: 'días atrás', showingActivities: 'Mostrando',
    welcomeBack: 'Bienvenido de nuevo', trackProgress: 'Rastrea tu progreso', overview: 'Resumen', workoutTab: 'Entrenamiento', body: 'Cuerpo', water: 'Agua', challenges: 'Desafíos', workouts: 'Entrenamientos', streak: 'Racha', waterToday: 'Agua Hoy', badges: 'Insignias', yourBadges: 'Tus Insignias', recentWorkouts: 'Recientes', todaysChallenges: 'Desafíos de Hoy', noWorkoutsYet: 'Sin entrenamientos', noChallengesToday: 'Sin desafíos', exercises: 'ejercicios', min: 'min', level: 'Nivel', xpToNextLevel: 'XP siguiente nivel', logWorkout: 'Registrar', workoutType: 'Tipo', duration: 'Duración', saveWorkout: 'Guardar', addMeasurement: 'Agregar Medición', weight: 'Peso', bodyFat: 'Grasa', saveMeasurement: 'Guardar', noMeasurementsYet: 'Sin mediciones', quickAdd: 'Agregar Rápido', dailyChallenges: 'Desafíos Diarios', noChallengesForToday: 'Sin desafíos hoy', checkBackTomorrow: '¡Vuelve mañana!', reward: 'Recompensa', completed: 'Completado',
    welcomeToFitbot: 'Bienvenido a FitBot AI', loginDescription: 'Inicia sesión para acceder a funciones premium', continueWithGoogle: 'Continuar con Google', continueWithFacebook: 'Continuar con Facebook', loadingGoogle: 'Cargando Google...', loadingFacebook: 'Redirigiendo a Facebook...', googleInfo: 'Google: Mostrará cuentas de Google', facebookInfo: 'Facebook: Redirigirá a Facebook', withLoginYouGet: 'Con inicio de sesión obtienes:', unlimitedAccess: 'Acceso ilimitado', savedConversations: 'Historial guardado', exclusiveWorkouts: 'Planes exclusivos', termsAgreement: 'Al iniciar sesión, aceptas los Términos', loginFailed: 'Error de inicio de sesión.',
    securityDashboard: 'Panel de Seguridad', monitorActivity: 'Monitorea actividad sospechosa', totalEvents: 'Eventos Totales', low: 'Bajo', medium: 'Medio', high: 'Alto', critical: 'Crítico', currentDevice: 'Dispositivo Actual', browser: 'Navegador', platform: 'Plataforma', screenResolution: 'Resolución', timezone: 'Zona Horaria', ipAddress: 'Dirección IP', location: 'Ubicación', isp: 'ISP', deviceId: 'ID Dispositivo', clearAllEvents: 'Borrar Eventos', exportJson: 'Exportar JSON', sendManualAlert: 'Enviar Alerta', writeAlertMessage: 'Escribe mensaje...', send: 'Enviar', filterByLevel: 'Filtrar', noSecurityEvents: 'Sin eventos', deviceInfo: 'Dispositivo', networkInfo: 'Red', page: 'Página', notified: 'Notificado', yes: 'Sí', no: 'No', additionalData: 'Datos Adicionales',
    loading: 'Cargando', error: 'Error', success: 'Éxito', cancel: 'Cancelar', confirm: 'Confirmar', close: 'Cerrar', back: 'Atrás', next: 'Siguiente', previous: 'Anterior', search: 'Buscar', filter: 'Filtrar', all: 'Todos', language: 'Idioma', selectLanguage: 'Seleccionar Idioma', days: 'días',
    paymentSuccess: '¡Pago Exitoso!', activatingPremium: 'Activando tu premium...', analyzingProof: 'Analizando Comprobante de Pago', aiCheckingImage: 'AI está verificando la imagen...', progress: 'Progreso', checkingMetadata: 'Verificando metadatos...', analyzingDimensions: 'Analizando dimensiones...', scanningPixels: 'Escaneando píxeles...', detectingNoise: 'Detectando ruido...', verifyingFormat: 'Verificando formato...', generatingReport: 'Generando informe...', verifiedOriginal: 'Verificado Original', detectedAiEdited: 'Detectado AI/Editado', authenticityScore: 'Puntuación de Autenticidad', analysisDetails: 'Detalles del Análisis', paymentRejected: 'Pago Rechazado', paymentRejectedDesc: 'El comprobante de pago que subiste ha sido detectado como manipulado usando AI o software de edición. Por favor sube una captura original de tu app DANA o banca móvil.', dontForgetSendProof: '¡No Olvides Enviar el Comprobante!', sendProofDesc2: 'También envía la captura del comprobante al WhatsApp del admin al número', reupload: 'Volver a Subir', activatePremium: 'Activar Premium', uploadProof: 'Subir Comprobante de Pago', uploadProofDesc: 'Sube tu captura del comprobante de transferencia', packageLabel: 'Paquete', dragDropImage: 'Arrastra y suelta la imagen aquí', orClickToSelect: 'o haz clic para seleccionar archivo', maxFileSize: 'Máx 15MB', viewFull: 'Ver Completo', aiDetectionWarning: '⚠️ Advertencia de Detección AI', aiDetectionDesc: 'Nuestro sistema analizará la autenticidad de la imagen usando escáner AI. Si se detecta que la imagen fue editada con AI, el comprobante será rechazado.', uploadTips: '💡 Consejos para Subir:', tip1: 'Captura directa de la app DANA / banca móvil', tip2: 'No edites, recortes ni filtres la imagen', tip3: 'Asegúrate que sea visible: nombre del destinatario, monto y fecha', tip4: 'Sube la imagen original sin compresión', backToPayment: '← Volver al Pago', analyzeProof: 'Analizar Comprobante', payment: 'Pago', selectPaymentMethod: 'Selecciona método de pago', transferViaDana: 'Transferir vía DANA e-wallet', danaNumber: 'Número DANA:', copied: '¡Copiado!', copy: 'Copiar', accountName: 'a.n. Muhammad Geovanny Iskandar', bankTransfer: 'Transferencia Bancaria / Cuenta Virtual', bankTransferDesc: 'Transferir vía banco o cuenta virtual', accountNumber: 'Número de Cuenta:', paymentInstructions: 'Instrucciones de Pago:', instruction1: 'Elige uno de los métodos de pago anteriores', instruction2: 'Transfiere según el paquete seleccionado', instruction3: 'Haz clic en "Ya Pagué" y sube la captura del comprobante', instruction4: 'Envía el comprobante al número 082161387805 (WhatsApp)', instruction5: 'El sistema verificará la autenticidad del comprobante', instruction6: 'Premium se activa después de verificar el comprobante como original ✅', iHavePaid: 'Ya Pagué',
  },
};

// Helper function to add more languages with fallback to English
export function getTranslation(code: string): Translations {
  return translations[code] || translations.en;
}
