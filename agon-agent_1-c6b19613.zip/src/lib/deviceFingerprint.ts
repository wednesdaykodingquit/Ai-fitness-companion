/**
 * Device Fingerprinting Utility
 * Mengumpulkan informasi unik tentang perangkat visitor
 */

export interface DeviceInfo {
  // Basic Info
  userAgent: string;
  platform: string;
  language: string;
  languages: string[];
  
  // Browser Info
  browser: string;
  browserVersion: string;
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
  
  // Screen Info
  screenWidth: number;
  screenHeight: number;
  screenColorDepth: number;
  pixelRatio: number;
  orientation: string;
  
  // System Info
  timezone: string;
  timezoneOffset: number;
  cpuCores: number;
  deviceMemory: number | null;
  connectionType: string;
  
  // Capabilities
  cookiesEnabled: boolean;
  localStorage: boolean;
  sessionStorage: boolean;
  webGL: boolean;
  canvas: boolean;
  touchSupport: boolean;
  maxTouchPoints: number;
  
  // Network
  ip?: string;
  isp?: string;
  country?: string;
  city?: string;
  
  // Unique Identifiers
  canvasFingerprint: string;
  webGLFingerprint: string;
  audioFingerprint: string;
  
  // Timestamps
  firstSeen: number;
  lastSeen: number;
  sessionDuration: number;
}

/**
 * Detect browser name and version
 */
function detectBrowser(): { name: string; version: string } {
  const ua = navigator.userAgent;
  let name = 'Unknown';
  let version = 'Unknown';
  
  if (ua.includes('Firefox')) {
    name = 'Firefox';
    version = ua.match(/Firefox\/([0-9.]+)/)?.[1] || 'Unknown';
  } else if (ua.includes('Chrome') && !ua.includes('Edg')) {
    name = 'Chrome';
    version = ua.match(/Chrome\/([0-9.]+)/)?.[1] || 'Unknown';
  } else if (ua.includes('Safari') && !ua.includes('Chrome')) {
    name = 'Safari';
    version = ua.match(/Version\/([0-9.]+)/)?.[1] || 'Unknown';
  } else if (ua.includes('Edg')) {
    name = 'Edge';
    version = ua.match(/Edg\/([0-9.]+)/)?.[1] || 'Unknown';
  } else if (ua.includes('Opera') || ua.includes('OPR')) {
    name = 'Opera';
    version = ua.match(/(Opera|OPR)\/([0-9.]+)/)?.[2] || 'Unknown';
  }
  
  return { name, version };
}

/**
 * Detect device type
 */
function detectDeviceType(): { isMobile: boolean; isTablet: boolean; isDesktop: boolean } {
  const ua = navigator.userAgent;
  const isMobile = /Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);
  const isTablet = /iPad|Android(?!.*Mobile)/i.test(ua) || (window.screen.width >= 768 && window.screen.width <= 1024);
  const isDesktop = !isMobile && !isTablet;
  
  return { isMobile, isTablet, isDesktop };
}

/**
 * Generate canvas fingerprint
 */
function generateCanvasFingerprint(): string {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return 'unsupported';
    
    canvas.width = 200;
    canvas.height = 50;
    
    // Draw text with different styles
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillStyle = '#f60';
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = '#069';
    ctx.fillText('FitBot AI Security', 2, 15);
    ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
    ctx.fillText('FitBot AI Security', 4, 17);
    
    return canvas.toDataURL().slice(-50);
  } catch {
    return 'unsupported';
  }
}

/**
 * Generate WebGL fingerprint
 */
function generateWebGLFingerprint(): string {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (!gl) return 'unsupported';
    
    const glAny = gl as WebGLRenderingContext;
    const debugInfo = glAny.getExtension('WEBGL_debug_renderer_info');
    if (!debugInfo) return 'no-debug-info';
    
    const vendor = glAny.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
    const renderer = glAny.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
    
    return `${vendor}|${renderer}`.slice(0, 100);
  } catch {
    return 'unsupported';
  }
}

/**
 * Generate audio fingerprint
 */
async function generateAudioFingerprint(): Promise<string> {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return 'unsupported';
    
    const context = new AudioContext();
    const oscillator = context.createOscillator();
    const analyser = context.createAnalyser();
    const gain = context.createGain();
    const scriptProcessor = context.createScriptProcessor(4096, 1, 1);
    
    oscillator.type = 'triangle';
    oscillator.frequency.value = 10000;
    gain.gain.value = 0;
    
    oscillator.connect(analyser);
    analyser.connect(scriptProcessor);
    scriptProcessor.connect(gain);
    gain.connect(context.destination);
    
    return new Promise((resolve) => {
      scriptProcessor.onaudioprocess = (event) => {
        const output = event.outputBuffer.getChannelData(0);
        const sum = output.reduce((a, b) => a + Math.abs(b), 0);
        resolve(sum.toFixed(6));
        context.close();
      };
      
      oscillator.start(0);
      setTimeout(() => {
        resolve('timeout');
        context.close();
      }, 100);
    });
  } catch {
    return 'unsupported';
  }
}

/**
 * Get network information
 */
function getNetworkInfo(): { connectionType: string } {
  const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
  return {
    connectionType: connection?.effectiveType || 'unknown'
  };
}

/**
 * Fetch IP and geolocation info
 */
async function fetchIPInfo(): Promise<{ ip?: string; isp?: string; country?: string; city?: string }> {
  try {
    const response = await fetch('https://ipapi.co/json/', { 
      signal: AbortSignal.timeout(3000) 
    });
    const data = await response.json();
    return {
      ip: data.ip,
      isp: data.org,
      country: data.country_name,
      city: data.city
    };
  } catch {
    return {};
  }
}

/**
 * Collect complete device fingerprint
 */
export async function collectDeviceFingerprint(): Promise<DeviceInfo> {
  const browser = detectBrowser();
  const deviceType = detectDeviceType();
  const network = getNetworkInfo();
  const ipInfo = await fetchIPInfo();
  const audioFingerprint = await generateAudioFingerprint();
  
  const now = Date.now();
  
  return {
    // Basic Info
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    languages: navigator.languages ? Array.from(navigator.languages) : [navigator.language],
    
    // Browser Info
    browser: browser.name,
    browserVersion: browser.version,
    ...deviceType,
    
    // Screen Info
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    screenColorDepth: window.screen.colorDepth,
    pixelRatio: window.devicePixelRatio || 1,
    orientation: window.screen.orientation?.type || 'unknown',
    
    // System Info
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    timezoneOffset: new Date().getTimezoneOffset(),
    cpuCores: navigator.hardwareConcurrency || 0,
    deviceMemory: (navigator as any).deviceMemory || null,
    connectionType: network.connectionType,
    
    // Capabilities
    cookiesEnabled: navigator.cookieEnabled,
    localStorage: !!window.localStorage,
    sessionStorage: !!window.sessionStorage,
    webGL: !!document.createElement('canvas').getContext('webgl'),
    canvas: !!document.createElement('canvas').getContext('2d'),
    touchSupport: 'ontouchstart' in window || navigator.maxTouchPoints > 0,
    maxTouchPoints: navigator.maxTouchPoints || 0,
    
    // Network
    ...ipInfo,
    
    // Unique Identifiers
    canvasFingerprint: generateCanvasFingerprint(),
    webGLFingerprint: generateWebGLFingerprint(),
    audioFingerprint,
    
    // Timestamps
    firstSeen: now,
    lastSeen: now,
    sessionDuration: 0
  };
}

/**
 * Generate a unique device ID from fingerprint
 */
export function generateDeviceId(fingerprint: DeviceInfo): string {
  const data = [
    fingerprint.userAgent,
    fingerprint.platform,
    fingerprint.screenWidth,
    fingerprint.screenHeight,
    fingerprint.canvasFingerprint,
    fingerprint.webGLFingerprint,
    fingerprint.audioFingerprint,
    fingerprint.timezone,
    fingerprint.language
  ].join('|');
  
  // Simple hash function
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  
  return Math.abs(hash).toString(36) + Date.now().toString(36);
}
