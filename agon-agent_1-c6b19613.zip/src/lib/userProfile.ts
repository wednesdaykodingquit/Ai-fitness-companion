/**
 * User Profile & Progress Tracking System
 */

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  
  // Physical Stats
  age?: number;
  gender?: 'male' | 'female' | 'other';
  height?: number; // cm
  currentWeight?: number; // kg
  targetWeight?: number; // kg
  
  // Fitness Goals
  fitnessGoal?: 'lose_weight' | 'gain_muscle' | 'maintain' | 'improve_endurance' | 'general_fitness';
  experienceLevel?: 'beginner' | 'intermediate' | 'advanced';
  workoutFrequency?: number; // days per week
  
  // Preferences
  dietaryRestrictions?: string[];
  allergies?: string[];
  preferredWorkoutTypes?: string[];
  
  // Gamification
  xp: number;
  level: number;
  badges: Badge[];
  streak: number;
  lastActiveDate?: string;
  
  // Timestamps
  joinedAt: string;
  updatedAt: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedAt: string;
}

export interface WorkoutLog {
  id: string;
  date: string;
  workoutType: string;
  exercises: ExerciseLog[];
  duration: number; // minutes
  caloriesBurned?: number;
  notes?: string;
  completed: boolean;
}

export interface ExerciseLog {
  name: string;
  sets: number;
  reps: number[];
  weights: number[]; // kg
  restTime?: number; // seconds
}

export interface BodyMeasurement {
  id: string;
  date: string;
  weight?: number; // kg
  bodyFat?: number; // %
  chest?: number; // cm
  waist?: number; // cm
  hips?: number; // cm
  arms?: number; // cm
  thighs?: number; // cm
  notes?: string;
}

export interface WaterIntake {
  date: string;
  amount: number; // ml
  goal: number; // ml
}

export interface DailyChallenge {
  id: string;
  date: string;
  title: string;
  description: string;
  type: 'workout' | 'nutrition' | 'hydration' | 'recovery';
  target: number;
  current: number;
  unit: string;
  xpReward: number;
  completed: boolean;
}

export interface WeeklyReport {
  weekStart: string;
  weekEnd: string;
  workoutsCompleted: number;
  totalWorkoutDuration: number;
  caloriesBurned: number;
  averageWaterIntake: number;
  weightChange?: number;
  xpEarned: number;
  badgesEarned: Badge[];
  streakDays: number;
  aiInsights: string[];
}

// Helper functions
export function calculateLevel(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

export function calculateXPForNextLevel(currentLevel: number): number {
  return currentLevel * 100;
}

export function calculateBMI(weight: number, height: number): number {
  const heightInMeters = height / 100;
  return weight / (heightInMeters * heightInMeters);
}

export function getBMICategory(bmi: number): string {
  if (bmi < 18.5) return 'Underweight';
  if (bmi < 25) return 'Normal';
  if (bmi < 30) return 'Overweight';
  return 'Obese';
}

export function calculateDailyCalorieNeeds(
  weight: number,
  height: number,
  age: number,
  gender: 'male' | 'female',
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active'
): number {
  // Mifflin-St Jeor Equation
  let bmr: number;
  if (gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }
  
  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9
  };
  
  return Math.round(bmr * activityMultipliers[activityLevel]);
}

// Badge definitions
export const AVAILABLE_BADGES: Omit<Badge, 'earnedAt'>[] = [
  { id: 'first_workout', name: 'First Step', description: 'Complete your first workout', icon: '🎯' },
  { id: 'week_streak', name: 'Week Warrior', description: '7 day workout streak', icon: '🔥' },
  { id: 'month_streak', name: 'Monthly Master', description: '30 day workout streak', icon: '💪' },
  { id: 'hydration_hero', name: 'Hydration Hero', description: 'Meet water goal 7 days in a row', icon: '💧' },
  { id: 'weight_goal', name: 'Goal Crusher', description: 'Reach your target weight', icon: '🏆' },
  { id: 'strength_gains', name: 'Getting Stronger', description: 'Increase weight by 10% on any exercise', icon: '💪' },
  { id: 'consistency_king', name: 'Consistency King', description: 'Complete 50 workouts', icon: '👑' },
  { id: 'early_bird', name: 'Early Bird', description: 'Complete 10 workouts before 8 AM', icon: '🌅' },
  { id: 'night_owl', name: 'Night Owl', description: 'Complete 10 workouts after 8 PM', icon: '🦉' },
  { id: 'variety_master', name: 'Variety Master', description: 'Try 10 different workout types', icon: '🎨' },
];

// Local storage helpers
const PROFILE_KEY = 'fitbot_profile';
const WORKOUTS_KEY = 'fitbot_workouts';
const MEASUREMENTS_KEY = 'fitbot_measurements';
const WATER_KEY = 'fitbot_water';
const CHALLENGES_KEY = 'fitbot_challenges';

export function loadProfile(): UserProfile | null {
  try {
    const saved = localStorage.getItem(PROFILE_KEY);
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
}

export function saveProfile(profile: UserProfile): void {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}

export function loadWorkouts(): WorkoutLog[] {
  try {
    const saved = localStorage.getItem(WORKOUTS_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveWorkouts(workouts: WorkoutLog[]): void {
  localStorage.setItem(WORKOUTS_KEY, JSON.stringify(workouts));
}

export function loadMeasurements(): BodyMeasurement[] {
  try {
    const saved = localStorage.getItem(MEASUREMENTS_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveMeasurements(measurements: BodyMeasurement[]): void {
  localStorage.setItem(MEASUREMENTS_KEY, JSON.stringify(measurements));
}

export function loadWaterIntake(): WaterIntake[] {
  try {
    const saved = localStorage.getItem(WATER_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveWaterIntake(water: WaterIntake[]): void {
  localStorage.setItem(WATER_KEY, JSON.stringify(water));
}

export function loadChallenges(): DailyChallenge[] {
  try {
    const saved = localStorage.getItem(CHALLENGES_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveChallenges(challenges: DailyChallenge[]): void {
  localStorage.setItem(CHALLENGES_KEY, JSON.stringify(challenges));
}
