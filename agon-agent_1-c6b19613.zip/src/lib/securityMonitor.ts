/**
 * Security Monitor - Deteksi aktivitas mencurigakan dan serangan
 */

import { collectDeviceFingerprint, generateDeviceId, type DeviceInfo } from './deviceFingerprint';

export type ThreatLevel = 'low' | 'medium' | 'high' | 'critical';
export type ThreatType = 
  | 'brute_force_login'
  | 'devtools_access'
  | 'rapid_navigation'
  | 'suspicious_user_agent'
  | 'unusual_resolution'
  | 'bot_behavior'
  | 'console_access'
  | 'clipboard_abuse'
  | 'iframe_injection'
  | 'session_hijack'
  | 'rate_limit_exceeded'
  | 'suspicious_pattern'
  | 'automation_detected'
  | 'vpn_detected'
  | 'tor_detected';

export interface SecurityEvent {
  id: string;
  timestamp: number;
  threatType: ThreatType;
  threatLevel: ThreatLevel;
  description: string;
  deviceInfo: DeviceInfo;
  deviceId: string;
  pageUrl: string;
  additionalData?: Record<string, any>;
  blocked: boolean;
  notified: boolean;
}

interface SecurityConfig {
  maxLoginAttempts: number;
  loginAttemptsWindow: number; // ms
  rapidNavigationThreshold: number;
  rapidNavigationWindow: number; // ms
  suspiciousUserAgents: string[];
  allowedResolutions: Array<{ width: number; height: number }>;
  whatsappNumber: string;
  enableNotifications: boolean;
}

const DEFAULT_CONFIG: SecurityConfig = {
  maxLoginAttempts: 5,
  loginAttemptsWindow: 60000, // 1 minute
  rapidNavigationThreshold: 10,
  rapidNavigationWindow: 5000, // 5 seconds
  suspiciousUserAgents: [
    'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget', 'python', 'node',
    'phantomjs', 'selenium', 'puppeteer', 'headless', 'automation'
  ],
  allowedResolutions: [], // Empty = allow all
  whatsappNumber: '6282161387805',
  enableNotifications: true
};

class SecurityMonitor {
  private config: SecurityConfig;
  private events: SecurityEvent[] = [];
  private loginAttempts: Map<string, number[]> = new Map();
  private navigationHistory: number[] = [];
  private deviceInfo: DeviceInfo | null = null;
  private deviceId: string = '';
  private isMonitoring: boolean = false;
  private devToolsOpen: boolean = false;

  constructor(config: Partial<SecurityConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Initialize security monitoring
   */
  async start(): Promise<void> {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    this.deviceInfo = await collectDeviceFingerprint();
    this.deviceId = generateDeviceId(this.deviceInfo);
    
    // Store device info in localStorage
    localStorage.setItem('fitbot_device_id', this.deviceId);
    localStorage.setItem('fitbot_device_info', JSON.stringify(this.deviceInfo));
    
    // Start monitoring
    this.monitorDevTools();
    this.monitorConsole();
    this.monitorClipboard();
    this.monitorIframe();
    this.checkSuspiciousUserAgent();
    this.checkUnusualResolution();
    this.checkAutomation();
    this.checkVPN();
    
    // Load previous events
    this.loadEvents();
    
    console.log('%c🔒 Security Monitor Active', 'color: #00ff87; font-size: 16px; font-weight: bold;');
    console.log('%cAll activities are being monitored', 'color: #60efff; font-size: 12px;');
  }

  /**
   * Stop monitoring
   */
  stop(): void {
    this.isMonitoring = false;
  }

  /**
   * Record login attempt
   */
  recordLoginAttempt(success: boolean): void {
    if (!this.deviceInfo) return;
    
    const now = Date.now();
    const attempts = this.loginAttempts.get(this.deviceId) || [];
    attempts.push(now);
    
    // Remove old attempts
    const recentAttempts = attempts.filter(
      time => now - time < this.config.loginAttemptsWindow
    );
    this.loginAttempts.set(this.deviceId, recentAttempts);
    
    if (!success && recentAttempts.length >= this.config.maxLoginAttempts) {
      this.logEvent({
        threatType: 'brute_force_login',
        threatLevel: 'high',
        description: `Terdeteksi ${recentAttempts.length} percobaan login gagal dalam ${this.config.loginAttemptsWindow / 1000} detik`,
        additionalData: { attempts: recentAttempts.length }
      });
    }
  }

  /**
   * Record page navigation
   */
  recordNavigation(): void {
    const now = Date.now();
    this.navigationHistory.push(now);
    
    // Remove old navigations
    const recentNavs = this.navigationHistory.filter(
      time => now - time < this.config.rapidNavigationWindow
    );
    this.navigationHistory = recentNavs;
    
    if (recentNavs.length >= this.config.rapidNavigationThreshold) {
      this.logEvent({
        threatType: 'rapid_navigation',
        threatLevel: 'medium',
        description: `Terdeteksi ${recentNavs.length} navigasi halaman dalam ${this.config.rapidNavigationWindow / 1000} detik`,
        additionalData: { navigations: recentNavs.length }
      });
    }
  }

  /**
   * Monitor DevTools access
   */
  private monitorDevTools(): void {
    const threshold = 160;
    const check = () => {
      const widthThreshold = window.outerWidth - window.innerWidth > threshold;
      const heightThreshold = window.outerHeight - window.innerHeight > threshold;
      
      if (widthThreshold || heightThreshold) {
        if (!this.devToolsOpen) {
          this.devToolsOpen = true;
          this.logEvent({
            threatType: 'devtools_access',
            threatLevel: 'low',
            description: 'DevTools terdeteksi dibuka oleh pengguna'
          });
        }
      } else {
        this.devToolsOpen = false;
      }
    };
    
    setInterval(check, 1000);
  }

  /**
   * Monitor console access
   */
  private monitorConsole(): void {
    const originalLog = console.log;
    const originalWarn = console.warn;
    const originalError = console.error;
    
    let consoleAccessCount = 0;
    
    const detectConsoleAccess = () => {
      consoleAccessCount++;
      if (consoleAccessCount >= 5) {
        this.logEvent({
          threatType: 'console_access',
          threatLevel: 'low',
          description: 'Pengguna mengakses console browser secara berulang'
        });
      }
    };
    
    console.log = function(...args) {
      detectConsoleAccess();
      originalLog.apply(console, args);
    };
    
    console.warn = function(...args) {
      detectConsoleAccess();
      originalWarn.apply(console, args);
    };
    
    console.error = function(...args) {
      detectConsoleAccess();
      originalError.apply(console, args);
    };
  }

  /**
   * Monitor clipboard operations
   */
  private monitorClipboard(): void {
    let clipboardCount = 0;
    
    document.addEventListener('copy', () => {
      clipboardCount++;
      if (clipboardCount >= 10) {
        this.logEvent({
          threatType: 'clipboard_abuse',
          threatLevel: 'medium',
          description: `Terdeteksi ${clipboardCount} operasi copy dalam sesi ini`
        });
      }
    });
    
    document.addEventListener('cut', () => {
      clipboardCount++;
    });
  }

  /**
   * Monitor iframe injection
   */
  private monitorIframe(): void {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeName === 'IFRAME') {
            this.logEvent({
              threatType: 'iframe_injection',
              threatLevel: 'high',
              description: 'Terdeteksi iframe yang disisipkan ke halaman',
              additionalData: { 
                iframeSrc: (node as HTMLIFrameElement).src 
              }
            });
          }
        });
      });
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
  }

  /**
   * Check for suspicious user agents
   */
  private checkSuspiciousUserAgent(): void {
    const ua = navigator.userAgent.toLowerCase();
    const suspicious = this.config.suspiciousUserAgents.some(agent => 
      ua.includes(agent)
    );
    
    if (suspicious) {
      this.logEvent({
        threatType: 'suspicious_user_agent',
        threatLevel: 'high',
        description: `User Agent mencurigakan terdeteksi: ${navigator.userAgent}`
      });
    }
  }

  /**
   * Check for unusual screen resolutions
   */
  private checkUnusualResolution(): void {
    const { width, height } = window.screen;
    
    // Common bot/automation resolutions
    const suspiciousResolutions = [
      { width: 800, height: 600 },
      { width: 1024, height: 768 },
      { width: 1, height: 1 },
      { width: 0, height: 0 }
    ];
    
    const isSuspicious = suspiciousResolutions.some(
      res => res.width === width && res.height === height
    );
    
    if (isSuspicious) {
      this.logEvent({
        threatType: 'unusual_resolution',
        threatLevel: 'medium',
        description: `Resolusi layar mencurigakan: ${width}x${height}`
      });
    }
  }

  /**
   * Check for automation tools
   */
  private checkAutomation(): void {
    const indicators = [
      (window as any).__nightmare,
      (window as any).__phantomas,
      (window as any)._phantom,
      (window as any).callPhantom,
      (window as any).__selenium_unwrapped,
      (window as any).__webdriver_evaluate,
      (window as any).__driver_evaluate,
      (window as any).__selenium_evaluate,
      (window as any).__fxdriver_evaluate,
      (window as any)._Selenium_IDE_Recorder,
      (window as any).webdriver,
      (document as any).__webdriver_script_fn,
      (document as any).$cdc_asdjflasutupfhvcZLmcfl_,
      (document as any).$chrome_asyncScriptInfo
    ];
    
    if (indicators.some(indicator => indicator !== undefined)) {
      this.logEvent({
        threatType: 'automation_detected',
        threatLevel: 'critical',
        description: 'Automation tool terdeteksi (Selenium, Puppeteer, PhantomJS, dll)'
      });
    }
  }

  /**
   * Check for VPN/Proxy usage
   */
  private checkVPN(): void {
    if (!this.deviceInfo?.timezone || !this.deviceInfo?.country) return;
    
    // Simple timezone vs country mismatch detection
    const timezoneCountryMap: Record<string, string[]> = {
      'Asia/Jakarta': ['Indonesia'],
      'Asia/Singapore': ['Singapore'],
      'America/New_York': ['United States'],
      'Europe/London': ['United Kingdom'],
      'Asia/Tokyo': ['Japan']
    };
    
    const expectedCountries = timezoneCountryMap[this.deviceInfo.timezone];
    if (expectedCountries && !expectedCountries.includes(this.deviceInfo.country)) {
      this.logEvent({
        threatType: 'vpn_detected',
        threatLevel: 'medium',
        description: `Kemungkinan VPN/Proxy: Timezone ${this.deviceInfo.timezone} tidak cocok dengan negara ${this.deviceInfo.country}`
      });
    }
  }

  /**
   * Log security event
   */
  private async logEvent(event: Omit<SecurityEvent, 'id' | 'timestamp' | 'deviceInfo' | 'deviceId' | 'pageUrl' | 'blocked' | 'notified'>): Promise<void> {
    if (!this.deviceInfo || !this.isMonitoring) return;
    
    const securityEvent: SecurityEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      deviceInfo: this.deviceInfo,
      deviceId: this.deviceId,
      pageUrl: window.location.href,
      blocked: event.threatLevel === 'critical',
      notified: false,
      ...event
    };
    
    this.events.push(securityEvent);
    this.saveEvents();
    
    // Send WhatsApp notification for high/critical threats
    if (this.config.enableNotifications && (event.threatLevel === 'high' || event.threatLevel === 'critical')) {
      await this.sendWhatsAppAlert(securityEvent);
      securityEvent.notified = true;
    }
    
    // Log to console
    const colors: Record<ThreatLevel, string> = {
      low: '#ffff00',
      medium: '#ff9900',
      high: '#ff3300',
      critical: '#ff0000'
    };
    
    console.log(
      `%c🚨 SECURITY ALERT [${event.threatLevel.toUpperCase()}]`,
      `color: ${colors[event.threatLevel]}; font-size: 14px; font-weight: bold;`
    );
    console.log(`%c${event.description}`, 'color: #ffffff; font-size: 12px;');
    console.log('%cDevice ID:', 'color: #60efff;', this.deviceId);
  }

  /**
   * Send WhatsApp alert
   */
  private async sendWhatsAppAlert(event: SecurityEvent): Promise<void> {
    const message = this.formatWhatsAppMessage(event);
    const whatsappUrl = `https://wa.me/${this.config.whatsappNumber}?text=${encodeURIComponent(message)}`;
    
    // Open WhatsApp in new tab for admin to send
    window.open(whatsappUrl, '_blank');
  }

  /**
   * Format WhatsApp message
   */
  private formatWhatsAppMessage(event: SecurityEvent): string {
    const device = event.deviceInfo;
    const time = new Date(event.timestamp).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta'
    });
    
    return `
🚨 *ALERT KEAMANAN FITBOT AI* 🚨

*Level Ancaman:* ${event.threatLevel.toUpperCase()}
*Jenis Ancaman:* ${event.threatType}
*Waktu:* ${time}

*Deskripsi:*
${event.description}

*Informasi Perangkat:*
• Device ID: ${event.deviceId}
• Browser: ${device.browser} ${device.browserVersion}
• Platform: ${device.platform}
• User Agent: ${device.userAgent}

*Layar:*
• Resolusi: ${device.screenWidth}x${device.screenHeight}
• Color Depth: ${device.screenColorDepth}
• Pixel Ratio: ${device.pixelRatio}

*Sistem:*
• Timezone: ${device.timezone}
• Bahasa: ${device.language}
• CPU Cores: ${device.cpuCores}
• Memory: ${device.deviceMemory || 'N/A'} GB

*Jaringan:*
• IP: ${device.ip || 'Unknown'}
• ISP: ${device.isp || 'Unknown'}
• Negara: ${device.country || 'Unknown'}
• Kota: ${device.city || 'Unknown'}
• Connection: ${device.connectionType}

*Halaman:*
${event.pageUrl}

*Fingerprints:*
• Canvas: ${device.canvasFingerprint}
• WebGL: ${device.webGLFingerprint}
• Audio: ${device.audioFingerprint}

${event.additionalData ? `*Data Tambahan:*\n${JSON.stringify(event.additionalData, null, 2)}` : ''}

---
_Dikirim otomatis oleh FitBot AI Security System_
    `.trim();
  }

  /**
   * Get all security events
   */
  getEvents(): SecurityEvent[] {
    return this.events;
  }

  /**
   * Get events by threat level
   */
  getEventsByLevel(level: ThreatLevel): SecurityEvent[] {
    return this.events.filter(e => e.threatLevel === level);
  }

  /**
   * Get events by threat type
   */
  getEventsByType(type: ThreatType): SecurityEvent[] {
    return this.events.filter(e => e.threatType === type);
  }

  /**
   * Clear all events
   */
  clearEvents(): void {
    this.events = [];
    localStorage.removeItem('fitbot_security_events');
  }

  /**
   * Save events to localStorage
   */
  private saveEvents(): void {
    try {
      // Keep only last 100 events
      const recentEvents = this.events.slice(-100);
      localStorage.setItem('fitbot_security_events', JSON.stringify(recentEvents));
    } catch (error) {
      console.error('Failed to save security events:', error);
    }
  }

  /**
   * Load events from localStorage
   */
  private loadEvents(): void {
    try {
      const saved = localStorage.getItem('fitbot_security_events');
      if (saved) {
        this.events = JSON.parse(saved);
      }
    } catch (error) {
      console.error('Failed to load security events:', error);
    }
  }

  /**
   * Get current device info
   */
  getDeviceInfo(): DeviceInfo | null {
    return this.deviceInfo;
  }

  /**
   * Get device ID
   */
  getDeviceId(): string {
    return this.deviceId;
  }

  /**
   * Manually trigger WhatsApp alert
   */
  async sendManualAlert(message: string): Promise<void> {
    if (!this.deviceInfo) return;
    
    const event: SecurityEvent = {
      id: `manual_${Date.now()}`,
      timestamp: Date.now(),
      threatType: 'suspicious_pattern',
      threatLevel: 'high',
      description: message,
      deviceInfo: this.deviceInfo,
      deviceId: this.deviceId,
      pageUrl: window.location.href,
      blocked: false,
      notified: true
    };
    
    await this.sendWhatsAppAlert(event);
  }
}

// Export singleton instance
export const securityMonitor = new SecurityMonitor();
