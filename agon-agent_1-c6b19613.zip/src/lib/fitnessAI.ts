export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface WorkoutPlan {
  name: string;
  exercises: string[];
  duration: string;
  difficulty: string;
}

const workoutPlans: Record<string, WorkoutPlan> = {
  chest: {
    name: "Chest Day Power",
    exercises: [
      "🏋️ Bench Press — 4 sets × 8-10 reps",
      "🏋️ Incline Dumbbell Press — 3 sets × 10-12 reps",
      "🏋️ Cable Flyes — 3 sets × 12-15 reps",
      "🏋️ Push-ups (failure) — 3 sets",
      "🏋️ Dips — 3 sets × 10-12 reps"
    ],
    duration: "45-60 minutes",
    difficulty: "Intermediate"
  },
  back: {
    name: "Back Builder",
    exercises: [
      "🏋️ Deadlifts — 4 sets × 6-8 reps",
      "🏋️ Pull-ups — 4 sets × 8-10 reps",
      "🏋️ Barbell Rows — 3 sets × 10-12 reps",
      "🏋️ Lat Pulldown — 3 sets × 12 reps",
      "🏋️ Seated Cable Row — 3 sets × 12 reps"
    ],
    duration: "50-65 minutes",
    difficulty: "Intermediate"
  },
  legs: {
    name: "Leg Day Destroyer",
    exercises: [
      "🏋️ Barbell Squats — 4 sets × 8-10 reps",
      "🏋️ Romanian Deadlifts — 3 sets × 10 reps",
      "🏋️ Leg Press — 3 sets × 12 reps",
      "🏋️ Walking Lunges — 3 sets × 12 each leg",
      "🏋️ Calf Raises — 4 sets × 15-20 reps"
    ],
    duration: "55-70 minutes",
    difficulty: "Intermediate-Advanced"
  },
  shoulders: {
    name: "Shoulder Sculptor",
    exercises: [
      "🏋️ Overhead Press — 4 sets × 8-10 reps",
      "🏋️ Lateral Raises — 4 sets × 12-15 reps",
      "🏋️ Front Raises — 3 sets × 12 reps",
      "🏋️ Face Pulls — 3 sets × 15 reps",
      "🏋️ Shrugs — 3 sets × 12 reps"
    ],
    duration: "40-55 minutes",
    difficulty: "Intermediate"
  },
  arms: {
    name: "Arm Annihilator",
    exercises: [
      "💪 Barbell Curls — 4 sets × 10 reps",
      "💪 Tricep Dips — 3 sets × 12 reps",
      "💪 Hammer Curls — 3 sets × 12 reps",
      "💪 Skull Crushers — 3 sets × 10 reps",
      "💪 Concentration Curls — 3 sets × 12 each arm",
      "💪 Overhead Tricep Extension — 3 sets × 12 reps"
    ],
    duration: "40-50 minutes",
    difficulty: "Beginner-Intermediate"
  },
  fullbody: {
    name: "Full Body Blitz",
    exercises: [
      "🏋️ Squats — 3 sets × 10 reps",
      "🏋️ Bench Press — 3 sets × 10 reps",
      "🏋️ Barbell Rows — 3 sets × 10 reps",
      "🏋️ Overhead Press — 3 sets × 10 reps",
      "🏋️ Deadlifts — 3 sets × 8 reps",
      "🏋️ Plank — 3 × 60 seconds"
    ],
    duration: "60-75 minutes",
    difficulty: "Intermediate"
  },
  cardio: {
    name: "HIIT Cardio Blast",
    exercises: [
      "🔥 Jumping Jacks — 45 sec",
      "🔥 Burpees — 30 sec",
      "🔥 Mountain Climbers — 45 sec",
      "🔥 High Knees — 45 sec",
      "🔥 Box Jumps — 30 sec",
      "🔥 Rest — 60 sec (repeat 4 rounds)"
    ],
    duration: "30-40 minutes",
    difficulty: "Intermediate-Advanced"
  },
  core: {
    name: "Core Crusher",
    exercises: [
      "🎯 Plank — 3 × 60 seconds",
      "🎯 Russian Twists — 3 × 20 reps",
      "🎯 Hanging Leg Raises — 3 × 12 reps",
      "🎯 Bicycle Crunches — 3 × 20 each side",
      "🎯 Dead Bug — 3 × 10 each side",
      "🎯 Ab Wheel Rollouts — 3 × 10 reps"
    ],
    duration: "25-35 minutes",
    difficulty: "Intermediate"
  }
};

const nutritionAdvice: Record<string, string> = {
  protein: `## 💪 Protein Guide

Here's your protein optimization guide:

**Daily Target:** 1.6-2.2g per kg of bodyweight

**Best Protein Sources:**
- 🥩 Chicken breast (31g per 100g)
- 🐟 Salmon (25g per 100g)
- 🥚 Eggs (6g per egg)
- 🫘 Greek yogurt (17g per cup)
- 🥛 Whey protein (25g per scoop)
- 🫘 Lentils (18g per cup cooked)

**Timing Tips:**
- Spread intake across 4-5 meals
- Consume within 2 hours post-workout
- Casein protein before bed for overnight recovery

**Pro Tip:** Combine plant proteins (rice + beans) for complete amino acid profiles! 🌱`,

  weightloss: `## 🔥 Fat Loss Nutrition Plan

**Calorie Strategy:**
- Calculate TDEE, then subtract 300-500 calories
- Never go below 1200 cal (women) / 1500 cal (men)

**Macro Split:**
- Protein: 40% (preserve muscle)
- Carbs: 30% (fuel workouts)
- Fats: 30% (hormone health)

**Foods to Embrace:**
- 🥬 Leafy greens (volume eating)
- 🍗 Lean proteins (satiety)
- 🫐 Berries (antioxidants)
- 🥑 Healthy fats (avocado, nuts)

**Foods to Limit:**
- ❌ Processed sugars
- ❌ Refined carbs
- ❌ Liquid calories (soda, juice)
- ❌ Fried foods

**Pro Tip:** Drink 500ml water before each meal — studies show it boosts weight loss by 44%! 💧`,

  bulking: `## 📈 Clean Bulking Guide

**Calorie Strategy:**
- Calculate TDEE, add 300-500 calories surplus
- Aim for 0.25-0.5 kg gain per week

**Macro Split:**
- Protein: 2g per kg bodyweight
- Carbs: 4-6g per kg bodyweight
- Fats: 0.8-1g per kg bodyweight

**Best Bulking Foods:**
- 🍚 Rice & oats (complex carbs)
- 🥜 Nuts & nut butter (calorie dense)
- 🍌 Bananas (quick energy)
- 🥩 Red meat (creatine + iron)
- 🥛 Whole milk (easy calories)

**Meal Timing:**
- Eat every 3-4 hours
- Pre-workout: carbs + protein 90 min before
- Post-workout: fast carbs + protein within 30 min

**Pro Tip:** Make calorie-dense smoothies — oats, banana, peanut butter, whey, milk = 800+ cal! 🥤`,

  supplements: `## 💊 Supplement Guide

**Tier 1 — Essential:**
- 🥛 Whey Protein — 25-50g daily
- 🧬 Creatine Monohydrate — 5g daily
- ☀️ Vitamin D3 — 2000-4000 IU daily
- 🐟 Omega-3 Fish Oil — 2-3g daily

**Tier 2 — Performance:**
- ⚡ Caffeine — 200-400mg pre-workout
- 🍉 Citrulline Malate — 6-8g pre-workout
- 🔋 Beta-Alanine — 3-5g daily
- 🧂 Electrolytes — during intense training

**Tier 3 — Optional:**
- 😴 ZMA (Zinc + Magnesium) — before bed
- 🦴 Collagen — 10-15g daily for joints
- 🍵 Green Tea Extract — for metabolism

**⚠️ Important:** Supplements complement a good diet, they don't replace it! Focus on whole foods first.`
};

const motivationalQuotes = [
  "💪 The only bad workout is the one that didn't happen!",
  "🔥 Your body can stand almost anything. It's your mind you have to convince.",
  "⚡ Don't limit your challenges. Challenge your limits.",
  "🏆 Success isn't always about greatness. It's about consistency.",
  "💥 The pain you feel today will be the strength you feel tomorrow.",
  "🎯 Focus on progress, not perfection.",
  "🌟 Every champion was once a contender who refused to give up.",
  "🔥 The only person you are destined to become is the person you decide to be."
];

function getRandomQuote(): string {
  return motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
}

function detectTopic(input: string): string {
  const lower = input.toLowerCase();

  if (/\b(chest|pec|bench press|push.?up)\b/.test(lower)) return 'chest';
  if (/\b(back|lat|pull.?up|row|deadlift)\b/.test(lower)) return 'back';
  if (/\b(leg|squat|quad|hamstring|glute|calf|lunges)\b/.test(lower)) return 'legs';
  if (/\b(shoulder|delt|overhead|lateral)\b/.test(lower)) return 'shoulders';
  if (/\b(arm|bicep|tricep|curl|forearm)\b/.test(lower)) return 'arms';
  if (/\b(full.?body|total|all.?body|complete)\b/.test(lower)) return 'fullbody';
  if (/\b(cardio|hiit|running|jog|sprint|aerob|fat.?burn)\b/.test(lower)) return 'cardio';
  if (/\b(core|abs|abdominal|plank|crunch|six.?pack)\b/.test(lower)) return 'core';
  if (/\b(protein|amino|whey|chicken|meat|eggs)\b/.test(lower)) return 'protein';
  if (/\b(weight.?loss|lose.?weight|fat.?loss|cut|slim|lean|diet)\b/.test(lower)) return 'weightloss';
  if (/\b(bulk|gain|mass|muscle.?gain|grow|size|big)\b/.test(lower)) return 'bulking';
  if (/\b(supplement|creatine|vitamin|pre.?workout|bcaa|caffeine)\b/.test(lower)) return 'supplements';
  if (/\b(motivat|inspire|encourage|give.?up|tired|lazy|unmotivat)\b/.test(lower)) return 'motivation';
  if (/\b(hello|hi|hey|greet|good\s*(morning|afternoon|evening))\b/.test(lower)) return 'greeting';
  if (/\b(warm.?up|stretch|flexib|mobility|foam)\b/.test(lower)) return 'warmup';
  if (/\b(rest|recovery|sleep|rest.?day|over.?train|sore)\b/.test(lower)) return 'recovery';
  if (/\b(beginner|start|new|first.?time|novice)\b/.test(lower)) return 'beginner';
  if (/\b(meal|eat|food|recipe|breakfast|lunch|dinner|snack)\b/.test(lower)) return 'mealplan';
  if (/\b(bmi|body.?mass|weight|height|calculate)\b/.test(lower)) return 'bmi';
  if (/\b(thank|thanks|appreciate|helpful)\b/.test(lower)) return 'thanks';

  return 'general';
}

function formatWorkoutPlan(plan: WorkoutPlan): string {
  return `## 🏋️ ${plan.name}

**Duration:** ${plan.duration}
**Difficulty:** ${plan.difficulty}

**Exercises:**
${plan.exercises.map(e => `- ${e}`).join('\n')}

**Tips:**
- Rest 60-90 seconds between sets
- Focus on form over weight
- Progressive overload: increase weight when you can complete all sets comfortably
- Stay hydrated throughout! 💧

Want me to adjust this for your fitness level or suggest alternatives?`;
}

function getResponse(input: string): string {
  const topic = detectTopic(input);

  switch (topic) {
    case 'chest':
    case 'back':
    case 'legs':
    case 'shoulders':
    case 'arms':
    case 'fullbody':
    case 'cardio':
    case 'core':
      return formatWorkoutPlan(workoutPlans[topic]);

    case 'protein':
    case 'weightloss':
    case 'bulking':
    case 'supplements':
      return nutritionAdvice[topic];

    case 'motivation':
      return `${getRandomQuote()}\n\nRemember, every step counts! Here are some tips to stay motivated:\n\n1. 📝 **Set specific goals** — "I want to bench press 100kg" beats "I want to get stronger"\n2. 📸 **Take progress photos** — the mirror lies, photos don't\n3. 🎵 **Create a killer playlist** — music can boost performance by 15%\n4. 👥 **Find a workout buddy** — accountability changes everything\n5. 📊 **Track your workouts** — seeing progress is addictive\n\nWhat specific area are you struggling with? I'm here to help! 💪`;

    case 'greeting':
      return `Hey there! 👋 Welcome to **FitBot AI** — your personal fitness companion!\n\nI can help you with:\n\n- 🏋️ **Workout Plans** — chest, back, legs, shoulders, arms, core, cardio\n- 🥗 **Nutrition Advice** — protein, weight loss, bulking, meal planning\n- 💊 **Supplement Guide** — what works and what doesn't\n- 💪 **Motivation** — when you need that extra push\n- 🧘 **Recovery Tips** — rest, stretching, and mobility\n\nJust ask me anything fitness-related! What would you like to work on today?`;

    case 'warmup':
      return `## 🧘 Warm-up & Mobility Routine

**Dynamic Warm-up (5-10 minutes):**
1. 🔄 Arm circles — 20 each direction
2. 🔄 Leg swings — 15 each leg (front & side)
3. 🔄 Hip circles — 10 each direction
4. 🔄 Cat-cow stretches — 10 reps
5. 🔄 World's greatest stretch — 5 each side
6. 🔄 Inchworms — 8 reps
7. 🔄 Jumping jacks — 30 seconds

**Mobility Work:**
- 🦵 90/90 hip switches — 10 each side
- 🦵 Thoracic spine rotations — 8 each side
- 🦵 Ankle circles — 10 each foot
- 🦵 Shoulder pass-throughs — 15 reps

**⚠️ Never skip warm-ups!** They increase blood flow, improve performance, and reduce injury risk by up to 50%!

Need a warm-up tailored to your specific workout?`;

    case 'recovery':
      return `## 😴 Recovery & Rest Guide

**Sleep Optimization:**
- 🛏️ Aim for 7-9 hours of quality sleep
- 📱 No screens 1 hour before bed
- 🌡️ Keep room cool (18-20°C)
- ☕ No caffeine after 2 PM

**Active Recovery Days:**
- 🚶 Light walking (20-30 min)
- 🧘 Yoga or gentle stretching
- 🏊 Swimming (low impact)
- 🎾 Light recreational sports

**Muscle Recovery Tips:**
- 💧 Hydrate: 3-4 liters of water daily
- 🧊 Cold showers for inflammation
- 🔥 Sauna/heat for blood flow
- 🧴 Foam rolling (10-15 min daily)
- 🥩 Eat enough protein (even on rest days!)

**Signs of Overtraining:**
- ⚠️ Persistent fatigue
- ⚠️ Decreased performance
- ⚠️ Mood changes
- ⚠️ Frequent illness
- ⚠️ Insomnia

**Rule of thumb:** Take 1-2 rest days per week. Your muscles grow during rest, not during training! 💪`;

    case 'beginner':
      return `## 🌟 Beginner's Fitness Guide

Welcome to your fitness journey! Here's your starter plan:

**Week 1-4: Foundation Phase**
- 📅 Train 3 days/week (Mon, Wed, Fri)
- 🏋️ Full body workouts each session
- ⏱️ 30-45 minutes per session

**Your Starter Workout:**
1. 🏋️ Goblet Squats — 3 × 10
2. 🏋️ Push-ups (knees OK!) — 3 × 8-12
3. 🏋️ Dumbbell Rows — 3 × 10 each arm
4. 🏋️ Plank — 3 × 30 seconds
5. 🏋️ Glute Bridges — 3 × 12

**Key Principles:**
- ✅ **Form first** — watch tutorial videos
- ✅ **Start light** — master the movement
- ✅ **Be consistent** — 3x/week beats 6x/week sporadically
- ✅ **Progress slowly** — add 2.5kg when comfortable
- ✅ **Rest between sets** — 60-90 seconds

**Nutrition Basics:**
- 🍽️ Eat protein at every meal
- 💧 Drink 2-3 liters of water
- 🥦 Fill half your plate with vegetables
- 🚫 Cut back on processed food

Remember: everyone starts somewhere. The most important thing is showing up! Ready to begin? 💪`;

    case 'mealplan':
      return `## 🍽️ Sample Meal Plan

**Breakfast (7:00 AM) — ~400 cal**
- 🥣 Oatmeal with banana, berries & honey
- 🥚 3 scrambled eggs
- ☕ Black coffee or green tea

**Mid-Morning Snack (10:00 AM) — ~200 cal**
- 🥜 Greek yogurt with almonds
- 🍎 Apple

**Lunch (12:30 PM) — ~550 cal**
- 🍗 Grilled chicken breast (200g)
- 🍚 Brown rice (1 cup)
- 🥦 Steamed broccoli & mixed veggies
- 🫒 Olive oil dressing

**Pre-Workout (4:00 PM) — ~250 cal**
- 🍌 Banana with peanut butter
- 🥤 Protein shake (optional)

**Dinner (7:00 PM) — ~500 cal**
- 🐟 Baked salmon or lean beef
- 🍠 Sweet potato
- 🥗 Large mixed salad
- 🥑 Half an avocado

**Evening Snack (9:00 PM) — ~150 cal**
- 🧀 Cottage cheese with berries
- 🫖 Chamomile tea

**Total: ~2,050 calories** (adjust based on your goals!)

Want me to adjust this for bulking, cutting, or specific dietary needs?`;

    case 'bmi':
      return `## 📊 BMI & Body Composition

**BMI Formula:** Weight (kg) ÷ Height² (m²)

**BMI Categories:**
- Underweight: < 18.5
- Normal: 18.5 - 24.9
- Overweight: 25 - 29.9
- Obese: 30+

**⚠️ BMI Limitations:**
BMI doesn't account for muscle mass! A muscular person might be "overweight" by BMI but very healthy.

**Better Metrics to Track:**
- 📏 **Waist circumference** (men <94cm, women <80cm)
- 📐 **Waist-to-hip ratio** (men <0.9, women <0.85)
- 🪞 **Progress photos** (weekly, same conditions)
- 📊 **Body fat %** (calipers or DEXA scan)
- 💪 **Strength progress** (are you getting stronger?)
- 👕 **How clothes fit** (the real test!)

**Tell me your height and weight and I can calculate your BMI!** Or better yet, let's focus on body composition and performance goals. 🎯`;

    case 'thanks':
      return `You're welcome! 😊 I'm always here to help you on your fitness journey!\n\n${getRandomQuote()}\n\nFeel free to ask me anything else — whether it's about workouts, nutrition, supplements, or recovery. Let's crush those goals together! 💪🔥`;

    default:
      return `Great question! Let me help you with that. 🤔

Here's what I can assist you with:

**🏋️ Workout Plans:**
- Type "chest", "back", "legs", "shoulders", "arms", "core", "cardio", or "full body"

**🥗 Nutrition:**
- Ask about "protein", "weight loss", "bulking", or "meal plans"

**💊 Supplements:**
- Ask about "supplements", "creatine", "pre-workout"

**🧘 Other:**
- "warm up" — stretching & mobility routines
- "recovery" — rest & recovery tips
- "beginner" — getting started guide
- "motivation" — when you need a boost

**Try asking something like:**
- "Give me a chest workout"
- "How do I lose weight?"
- "What supplements should I take?"
- "I'm a beginner, where do I start?"

What would you like to explore? 💪`;
  }
}

export function generateResponse(input: string, language: string = 'id'): Promise<string> {
  return new Promise((resolve) => {
    const delay = 800 + Math.random() * 1200;
    setTimeout(() => {
      let response = getResponse(input);
      
      // Add language context to response
      if (language !== 'en' && language !== 'id') {
        response = `[Response in ${language.toUpperCase()}]\n\n${response}`;
      }
      
      resolve(response);
    }, delay);
  });
}

export const quickActions = [
  { label: "🏋️ Chest Day", query: "Give me a chest workout" },
  { label: "🦵 Leg Day", query: "I need a leg workout" },
  { label: "🔥 HIIT Cardio", query: "Give me a cardio workout" },
  { label: "🥗 Meal Plan", query: "Show me a meal plan" },
  { label: "💪 Beginner", query: "I'm a beginner, help me start" },
  { label: "💊 Supplements", query: "What supplements should I take?" },
  { label: "📈 Bulk Up", query: "How do I bulk up and gain muscle?" },
  { label: "🔥 Lose Weight", query: "Help me lose weight" },
];
