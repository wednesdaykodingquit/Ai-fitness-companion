import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { securityMonitor } from './securityMonitor';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  provider: 'google' | 'facebook';
  isPremium: boolean;
  premiumExpiry?: string;
  joinedAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  login: (provider: 'google' | 'facebook') => Promise<void>;
  logout: () => void;
  upgradePremium: (plan: string) => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

// OAuth Client IDs - Replace with your own
const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';
const FACEBOOK_APP_ID = 'YOUR_FACEBOOK_APP_ID';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('fitbot_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (user) {
      localStorage.setItem('fitbot_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('fitbot_user');
    }
  }, [user]);

  const login = async (provider: 'google' | 'facebook') => {
    setIsLoading(true);
    try {
      if (provider === 'google') {
        await loginWithGoogle();
      } else {
        await loginWithFacebook();
      }
      // Record successful login
      securityMonitor.recordLoginAttempt(true);
    } catch (error) {
      // Record failed login attempt
      securityMonitor.recordLoginAttempt(false);
      console.error('Login failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (!window.google?.accounts?.id) {
        reject(new Error('Google Identity Services not loaded'));
        return;
      }

      window.google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: (response: any) => {
          try {
            // Decode JWT token to get user info
            const payload = JSON.parse(atob(response.credential.split('.')[1]));
            const newUser: User = {
              id: payload.sub,
              name: payload.name,
              email: payload.email,
              avatar: payload.picture || `https://ui-avatars.com/api/?name=${encodeURIComponent(payload.name)}&background=00FF87&color=0a0a0a&bold=true`,
              provider: 'google',
              isPremium: false,
              joinedAt: new Date().toISOString(),
            };
            setUser(newUser);
            resolve();
          } catch (error) {
            reject(error);
          }
        },
        auto_select: false,
        cancel_on_tap_outside: true,
      });

      // Show the Google account picker
      window.google.accounts.id.prompt((notification: any) => {
        if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
          // Fallback to button mode if One Tap is not available
          const container = document.createElement('div');
          container.style.position = 'fixed';
          container.style.top = '50%';
          container.style.left = '50%';
          container.style.transform = 'translate(-50%, -50%)';
          container.style.zIndex = '9999';
          document.body.appendChild(container);

          if (window.google?.accounts?.id) {
            window.google.accounts.id.renderButton(container, {
              theme: 'filled_black',
              size: 'large',
              type: 'standard',
              text: 'signin_with',
              shape: 'rectangular',
              logo_alignment: 'left',
            });
          }

          // Auto-click the button
          setTimeout(() => {
            const button = container.querySelector('button');
            if (button) button.click();
          }, 100);
        }
      });
    });
  };

  const loginWithFacebook = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      // Load Facebook SDK if not already loaded
      if (!window.FB) {
        loadFacebookSDK().then(() => {
          performFacebookLogin(resolve, reject);
        }).catch(reject);
      } else {
        performFacebookLogin(resolve, reject);
      }
    });
  };

  const loadFacebookSDK = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (window.FB) {
        resolve();
        return;
      }

      window.fbAsyncInit = () => {
        if (window.FB) {
          window.FB.init({
            appId: FACEBOOK_APP_ID,
            cookie: true,
            xfbml: true,
            version: 'v18.0',
          });
        }
        resolve();
      };

      const script = document.createElement('script');
      script.src = 'https://connect.facebook.net/en_US/sdk.js';
      script.async = true;
      script.defer = true;
      script.crossOrigin = 'anonymous';
      script.onerror = () => reject(new Error('Failed to load Facebook SDK'));
      document.body.appendChild(script);
    });
  };

  const performFacebookLogin = (resolve: () => void, reject: (error: any) => void) => {
    if (!window.FB) {
      reject(new Error('Facebook SDK not loaded'));
      return;
    }

    window.FB.login((response: any) => {
      if (response.authResponse) {
        // Get user info
        window.FB!.api('/me', { fields: 'id,name,email,picture' }, (userInfo: any) => {
          const newUser: User = {
            id: userInfo.id,
            name: userInfo.name,
            email: userInfo.email || `${userInfo.id}@facebook.com`,
            avatar: userInfo.picture?.data?.url || `https://ui-avatars.com/api/?name=${encodeURIComponent(userInfo.name)}&background=60EFFF&color=0a0a0a&bold=true`,
            provider: 'facebook',
            isPremium: false,
            joinedAt: new Date().toISOString(),
          };
          setUser(newUser);
          resolve();
        });
      } else {
        reject(new Error('Facebook login cancelled'));
      }
    }, { scope: 'public_profile,email' });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('fitbot_user');

    // Sign out from Google
    if (window.google?.accounts?.id) {
      window.google.accounts.id.disableAutoSelect();
    }

    // Logout from Facebook
    if (window.FB) {
      window.FB.logout();
    }
  };

  const upgradePremium = (plan: string) => {
    if (!user) return;
    const now = new Date();
    let expiry: Date;
    switch (plan) {
      case 'daily':
        expiry = new Date(now.getTime() + 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        expiry = new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());
        break;
      case 'yearly':
        expiry = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
        break;
      default:
        expiry = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    }
    setUser({
      ...user,
      isPremium: true,
      premiumExpiry: expiry.toISOString(),
    });
  };

  return (
    <AuthContext.Provider value={{ user, isLoggedIn: !!user, login, logout, upgradePremium, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Type definitions for external SDKs
declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: any) => void;
          prompt: (callback: (notification: any) => void) => void;
          renderButton: (container: HTMLElement, options: any) => void;
          disableAutoSelect: () => void;
        };
      };
    };
    FB?: {
      init: (config: any) => void;
      login: (callback: (response: any) => void, options: any) => void;
      api: (path: string, params: any, callback: (response: any) => void) => void;
      logout: () => void;
    };
    fbAsyncInit?: () => void;
  }
}
