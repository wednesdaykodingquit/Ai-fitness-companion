import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Shield, AlertTriangle, Activity, Monitor, Globe, 
  Cpu, Wifi, Fingerprint, Clock, Trash2, Send,
  ChevronDown, ChevronUp, Filter, Download
} from 'lucide-react';
import { securityMonitor, type SecurityEvent, type ThreatLevel, type ThreatType } from '../lib/securityMonitor';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/language';
import LoginModal from '../components/LoginModal';

const threatLevelColors: Record<ThreatLevel, string> = {
  low: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  medium: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  high: 'bg-red-500/10 text-red-400 border-red-500/20',
  critical: 'bg-red-500/20 text-red-300 border-red-500/30'
};

export default function SecurityDashboard() {
  const { isLoggedIn } = useAuth();
  const { t } = useLanguage();
  const [showLogin, setShowLogin] = useState(false);
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [deviceInfo, setDeviceInfo] = useState(securityMonitor.getDeviceInfo());
  const [deviceId, setDeviceId] = useState(securityMonitor.getDeviceId());
  const [filterLevel, setFilterLevel] = useState<ThreatLevel | 'all'>('all');
  const [expandedEvent, setExpandedEvent] = useState<string | null>(null);
  const [customMessage, setCustomMessage] = useState('');

  const threatLevelLabels: Record<ThreatLevel, string> = {
    low: t.low,
    medium: t.medium,
    high: t.high,
    critical: t.critical
  };

  const threatTypeLabels: Record<ThreatType, string> = {
    brute_force_login: 'Brute Force Login',
    devtools_access: 'DevTools Access',
    rapid_navigation: 'Rapid Navigation',
    suspicious_user_agent: 'Suspicious User Agent',
    unusual_resolution: 'Unusual Resolution',
    bot_behavior: 'Bot Behavior',
    console_access: 'Console Access',
    clipboard_abuse: 'Clipboard Abuse',
    iframe_injection: 'Iframe Injection',
    session_hijack: 'Session Hijack',
    rate_limit_exceeded: 'Rate Limit Exceeded',
    suspicious_pattern: 'Suspicious Pattern',
    automation_detected: 'Automation Detected',
    vpn_detected: 'VPN Detected',
    tor_detected: 'TOR Detected'
  };

  useEffect(() => {
    if (isLoggedIn) {
      setEvents(securityMonitor.getEvents());
      setDeviceInfo(securityMonitor.getDeviceInfo());
      setDeviceId(securityMonitor.getDeviceId());
    }
  }, [isLoggedIn]);

  const filteredEvents = filterLevel === 'all' 
    ? events 
    : events.filter(e => e.threatLevel === filterLevel);

  const stats = {
    total: events.length,
    low: events.filter(e => e.threatLevel === 'low').length,
    medium: events.filter(e => e.threatLevel === 'medium').length,
    high: events.filter(e => e.threatLevel === 'high').length,
    critical: events.filter(e => e.threatLevel === 'critical').length,
  };

  const handleClearEvents = () => {
    securityMonitor.clearEvents();
    setEvents([]);
  };

  const handleSendAlert = async () => {
    if (!customMessage.trim()) return;
    await securityMonitor.sendManualAlert(customMessage);
    setCustomMessage('');
    alert(t.success + '!');
  };

  const handleExportEvents = () => {
    const data = JSON.stringify(events, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `security-events-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md mx-auto px-4"
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-500/20 to-orange-500/20 flex items-center justify-center mx-auto mb-6">
            <Shield className="w-10 h-10 text-red-400" />
          </div>
          <h2 className="font-display text-3xl font-bold mb-3">
            {t.loginToViewHistory}
          </h2>
          <p className="text-white/50 mb-8">
            {t.monitorActivity}
          </p>
          <button
            onClick={() => setShowLogin(true)}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold hover:shadow-lg hover:shadow-red-500/30 hover:scale-105 transition-all"
          >
            <Shield className="w-5 h-5" />
            {t.login}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold">
              {t.securityDashboard}
            </h1>
          </div>
          <p className="text-white/50 ml-[52px]">
            {t.monitorActivity}
          </p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          {[
            { label: t.totalEvents, value: stats.total, icon: Activity, color: 'text-blue-400' },
            { label: t.low, value: stats.low, icon: AlertTriangle, color: 'text-yellow-400' },
            { label: t.medium, value: stats.medium, icon: AlertTriangle, color: 'text-orange-400' },
            { label: t.high, value: stats.high, icon: AlertTriangle, color: 'text-red-400' },
            { label: t.critical, value: stats.critical, icon: AlertTriangle, color: 'text-red-300' },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="glass-card rounded-2xl p-5"
              >
                <Icon className={`w-5 h-5 ${stat.color} mb-2`} />
                <p className="font-display text-2xl font-bold">{stat.value}</p>
                <p className="text-white/40 text-xs mt-1">{stat.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Device Info */}
        {deviceInfo && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card rounded-2xl p-6 mb-10"
          >
            <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
              <Fingerprint className="w-5 h-5 text-emerald-glow" />
              {t.currentDevice}
            </h2>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Monitor className="w-4 h-4 text-blue-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.browser}</p>
                    <p className="font-medium">{deviceInfo.browser} {deviceInfo.browserVersion}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Cpu className="w-4 h-4 text-purple-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.platform}</p>
                    <p className="font-medium">{deviceInfo.platform}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Monitor className="w-4 h-4 text-cyan-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.screenResolution}</p>
                    <p className="font-medium">{deviceInfo.screenWidth}x{deviceInfo.screenHeight}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Globe className="w-4 h-4 text-green-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.timezone}</p>
                    <p className="font-medium">{deviceInfo.timezone}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Wifi className="w-4 h-4 text-yellow-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.ipAddress}</p>
                    <p className="font-medium">{deviceInfo.ip || 'Unknown'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Globe className="w-4 h-4 text-orange-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.location}</p>
                    <p className="font-medium">{deviceInfo.city || 'Unknown'}, {deviceInfo.country || 'Unknown'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Activity className="w-4 h-4 text-pink-400 mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.isp}</p>
                    <p className="font-medium">{deviceInfo.isp || 'Unknown'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Fingerprint className="w-4 h-4 text-emerald-glow mt-0.5" />
                  <div>
                    <p className="text-white/40 text-xs">{t.deviceId}</p>
                    <p className="font-medium text-xs font-mono">{deviceId}</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Actions */}
        <div className="flex flex-wrap gap-3 mb-6">
          <button
            onClick={handleClearEvents}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-all text-sm font-medium"
          >
            <Trash2 className="w-4 h-4" />
            {t.clearAllEvents}
          </button>
          <button
            onClick={handleExportEvents}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 hover:bg-blue-500/20 transition-all text-sm font-medium"
          >
            <Download className="w-4 h-4" />
            {t.exportJson}
          </button>
        </div>

        {/* Custom Alert */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card rounded-2xl p-6 mb-10"
        >
          <h2 className="font-display text-lg font-bold mb-4 flex items-center gap-2">
            <Send className="w-5 h-5 text-emerald-glow" />
            {t.sendManualAlert}
          </h2>
          <div className="flex gap-3">
            <input
              type="text"
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder={t.writeAlertMessage}
              className="flex-1 bg-dark-600 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50 focus:ring-1 focus:ring-emerald-glow/20 transition-all"
            />
            <button
              onClick={handleSendAlert}
              disabled={!customMessage.trim()}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-sm hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-105 transition-all disabled:opacity-50 disabled:hover:scale-100"
            >
              {t.send}
            </button>
          </div>
        </motion.div>

        {/* Filter */}
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4 text-white/40" />
          <span className="text-sm text-white/40">{t.filterByLevel}:</span>
          {(['all', 'low', 'medium', 'high', 'critical'] as const).map((level) => (
            <button
              key={level}
              onClick={() => setFilterLevel(level)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filterLevel === level
                  ? 'bg-emerald-glow/20 text-emerald-glow border border-emerald-glow/30'
                  : 'bg-white/5 text-white/60 border border-white/10 hover:bg-white/10'
              }`}
            >
              {level === 'all' ? t.all : threatLevelLabels[level]}
            </button>
          ))}
        </div>

        {/* Events List */}
        <div className="space-y-3">
          {filteredEvents.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16 glass-card rounded-2xl"
            >
              <Shield className="w-12 h-12 text-white/10 mx-auto mb-4" />
              <p className="text-white/30 text-sm">{t.noSecurityEvents}</p>
            </motion.div>
          ) : (
            filteredEvents.map((event, i) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="glass-card rounded-2xl overflow-hidden hover:border-white/10 transition-all"
              >
                <div
                  className="p-5 cursor-pointer"
                  onClick={() => setExpandedEvent(expandedEvent === event.id ? null : event.id)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border ${threatLevelColors[event.threatLevel]}`}>
                          {threatLevelLabels[event.threatLevel].toUpperCase()}
                        </span>
                        <span className="text-xs text-white/40">
                          {threatTypeLabels[event.threatType]}
                        </span>
                      </div>
                      <p className="text-sm text-white/80 mb-1">{event.description}</p>
                      <div className="flex items-center gap-4 text-xs text-white/40">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(event.timestamp).toLocaleString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <Monitor className="w-3 h-3" />
                          {event.deviceInfo.browser}
                        </span>
                      </div>
                    </div>
                    {expandedEvent === event.id ? (
                      <ChevronUp className="w-5 h-5 text-white/40" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-white/40" />
                    )}
                  </div>
                </div>

                {expandedEvent === event.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-white/5 p-5 bg-dark-800/50"
                  >
                    <div className="grid md:grid-cols-2 gap-4 text-xs">
                      <div>
                        <h4 className="font-semibold text-white/60 mb-2">{t.deviceInfo}</h4>
                        <div className="space-y-1.5">
                          <p><span className="text-white/40">{t.deviceId}:</span> <span className="font-mono">{event.deviceId}</span></p>
                          <p><span className="text-white/40">{t.browser}:</span> {event.deviceInfo.browser} {event.deviceInfo.browserVersion}</p>
                          <p><span className="text-white/40">{t.platform}:</span> {event.deviceInfo.platform}</p>
                          <p><span className="text-white/40">User Agent:</span> <span className="text-[10px]">{event.deviceInfo.userAgent}</span></p>
                          <p><span className="text-white/40">{t.screenResolution}:</span> {event.deviceInfo.screenWidth}x{event.deviceInfo.screenHeight}</p>
                          <p><span className="text-white/40">{t.timezone}:</span> {event.deviceInfo.timezone}</p>
                          <p><span className="text-white/40">{t.language}:</span> {event.deviceInfo.language}</p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold text-white/60 mb-2">{t.networkInfo}</h4>
                        <div className="space-y-1.5">
                          <p><span className="text-white/40">{t.ipAddress}:</span> {event.deviceInfo.ip || 'Unknown'}</p>
                          <p><span className="text-white/40">{t.isp}:</span> {event.deviceInfo.isp || 'Unknown'}</p>
                          <p><span className="text-white/40">{t.location}:</span> {event.deviceInfo.country || 'Unknown'}</p>
                          <p><span className="text-white/40">{t.location}:</span> {event.deviceInfo.city || 'Unknown'}</p>
                          <p><span className="text-white/40">Connection:</span> {event.deviceInfo.connectionType}</p>
                          <p><span className="text-white/40">{t.page}:</span> <span className="text-[10px]">{event.pageUrl}</span></p>
                          <p><span className="text-white/40">{t.notified}:</span> {event.notified ? `✅ ${t.yes}` : `❌ ${t.no}`}</p>
                        </div>
                      </div>
                    </div>
                    {event.additionalData && (
                      <div className="mt-4">
                        <h4 className="font-semibold text-white/60 mb-2 text-xs">{t.additionalData}</h4>
                        <pre className="bg-dark-900/50 rounded-lg p-3 text-[10px] text-white/60 overflow-x-auto">
                          {JSON.stringify(event.additionalData, null, 2)}
                        </pre>
                      </div>
                    )}
                  </motion.div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
