import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, RotateCcw, Sparkles } from 'lucide-react';
import ChatMessage from '../components/ChatMessage';
import TypingIndicator from '../components/TypingIndicator';
import { generateResponse, quickActions, type ChatMessage as ChatMessageType } from '../lib/fitnessAI';
import { useLanguage } from '../lib/language';

const welcomeMessage: ChatMessageType = {
  id: 'welcome',
  role: 'assistant',
  content: `Hey there! 👋 I'm **FitBot AI**, your personal fitness companion!

I can help you with:
- 🏋️ **Workout Plans** — for any muscle group or fitness goal
- 🥗 **Nutrition Advice** — protein, meal plans, bulking, cutting
- 💊 **Supplement Guide** — science-backed recommendations
- 🧘 **Recovery & Mobility** — rest, stretching, injury prevention
- 💪 **Motivation** — when you need that extra push

**Try asking me something like:**
- "Give me a leg day workout"
- "How much protein should I eat?"
- "I want to lose weight"
- "What supplements do I need?"

What would you like to work on today? Let's crush it! 💪🔥`,
  timestamp: new Date(),
};

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessageType[]>([welcomeMessage]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const { currentLanguage } = useLanguage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText || isLoading) return;

    const userMessage: ChatMessageType = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: messageText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }

    try {
      const response = await generateResponse(messageText, currentLanguage.code);
      const botMessage: ChatMessageType = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
    } catch {
      const errorMessage: ChatMessageType = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: "Oops! Something went wrong. Please try again! 😅",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  };

  const handleReset = () => {
    setMessages([welcomeMessage]);
    setInput('');
  };

  return (
    <div className="h-screen flex flex-col pt-16">
      {/* Chat Header */}
      <div className="flex-shrink-0 glass-card border-b border-white/5 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-dark-900" />
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-glow rounded-full border-2 border-dark-900 animate-pulse-glow" />
            </div>
            <div>
              <h1 className="font-display font-bold text-sm">FitBot AI</h1>
              <p className="text-xs text-emerald-glow">Online • Ready to help</p>
            </div>
          </div>
          <button
            onClick={handleReset}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-white/50 hover:text-white hover:bg-white/5 transition-all text-sm"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden sm:inline">New Chat</span>
          </button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto chat-gradient">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
          <AnimatePresence>
            {messages.map((message, index) => (
              <ChatMessage key={message.id} message={message} index={index} />
            ))}
          </AnimatePresence>

          {isLoading && <TypingIndicator />}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick Actions */}
      {messages.length <= 1 && (
        <div className="flex-shrink-0 border-t border-white/5 bg-dark-800/50 px-4 py-3">
          <div className="max-w-4xl mx-auto">
            <p className="text-xs text-white/30 mb-2 font-medium">Quick Actions:</p>
            <div className="flex flex-wrap gap-2">
              {quickActions.map((action, i) => (
                <motion.button
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => handleSend(action.query)}
                  className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-white/70 hover:bg-emerald-glow/10 hover:border-emerald-glow/30 hover:text-emerald-glow transition-all whitespace-nowrap"
                >
                  {action.label}
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="flex-shrink-0 glass-card border-t border-white/5 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end gap-3">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Ask about workouts, nutrition, supplements..."
                rows={1}
                className="w-full bg-dark-600 border border-white/10 rounded-2xl px-4 py-3 pr-12 text-sm text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50 focus:ring-1 focus:ring-emerald-glow/20 resize-none transition-all"
                style={{ maxHeight: '120px' }}
              />
            </div>
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              className="flex-shrink-0 w-12 h-12 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow flex items-center justify-center text-dark-900 hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-105 transition-all disabled:opacity-30 disabled:hover:scale-100 disabled:hover:shadow-none"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <p className="text-[10px] text-white/20 text-center mt-2">
            FitBot AI provides general fitness guidance. Always consult a medical professional for personalized advice.
          </p>
        </div>
      </div>
    </div>
  );
}
