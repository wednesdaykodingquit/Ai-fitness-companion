import { useState } from 'react';
import { motion } from 'framer-motion';
import { History as HistoryIcon, Filter, Search, Users, TrendingUp, MessageCircle, Crown } from 'lucide-react';
import { getHistory, type HistoryEntry } from '../lib/history';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/language';
import LoginModal from '../components/LoginModal';

export default function History() {
  const { isLoggedIn } = useAuth();
  const { t } = useLanguage();
  const [showLogin, setShowLogin] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const allHistory = getHistory();

  const categoryFilters = [
    { key: 'all', label: t.allCategories },
    { key: 'workout', label: `🏋️ ${t.workout}` },
    { key: 'nutrition', label: `🥗 ${t.nutrition}` },
    { key: 'supplement', label: `💊 ${t.supplement}` },
    { key: 'recovery', label: `🧘 ${t.recovery}` },
    { key: 'chat', label: `💬 ${t.chatCategory}` },
    { key: 'premium', label: `⭐ ${t.premiumCategory}` },
  ];

  const categoryLabels: Record<string, string> = {
    workout: `🏋️ ${t.workout}`,
    nutrition: `🥗 ${t.nutrition}`,
    supplement: `💊 ${t.supplement}`,
    recovery: `🧘 ${t.recovery}`,
    chat: `💬 ${t.chatCategory}`,
    premium: `⭐ ${t.premiumCategory}`,
  };

  const categoryColors: Record<string, string> = {
    workout: 'bg-emerald-glow/10 text-emerald-glow border-emerald-glow/20',
    nutrition: 'bg-cyan-glow/10 text-cyan-glow border-cyan-glow/20',
    supplement: 'bg-purple-400/10 text-purple-400 border-purple-400/20',
    recovery: 'bg-orange-400/10 text-orange-400 border-orange-400/20',
    chat: 'bg-blue-400/10 text-blue-400 border-blue-400/20',
    premium: 'bg-yellow-400/10 text-yellow-400 border-yellow-400/20',
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffHours < 1) return t.justNow;
    if (diffHours < 24) return `${diffHours} ${t.hoursAgo}`;
    if (diffDays < 7) return `${diffDays} ${t.daysAgo}`;
    return date.toLocaleDateString();
  };

  const formatTime = (dateStr: string): string => {
    return new Date(dateStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const filteredHistory = allHistory.filter((entry: HistoryEntry) => {
    const matchesCategory = activeFilter === 'all' || entry.category === activeFilter;
    const matchesSearch = searchQuery === '' ||
      entry.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.detail.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const stats = {
    totalUsers: new Set(allHistory.map(h => h.userId)).size,
    totalActivity: allHistory.length,
    premiumUpgrades: allHistory.filter(h => h.category === 'premium').length,
    workoutRequests: allHistory.filter(h => h.category === 'workout').length,
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md mx-auto px-4"
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-glow/20 to-cyan-glow/20 flex items-center justify-center mx-auto mb-6">
            <HistoryIcon className="w-10 h-10 text-emerald-glow" />
          </div>
          <h2 className="font-display text-3xl font-bold mb-3">
            {t.loginToViewHistory}
          </h2>
          <p className="text-white/50 mb-8">
            {t.historyDescription}
          </p>
          <button
            onClick={() => setShowLogin(true)}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-105 transition-all"
          >
            <Users className="w-5 h-5" />
            {t.login}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
              <HistoryIcon className="w-5 h-5 text-dark-900" />
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold">
              {t.activityHistory}
            </h1>
          </div>
          <p className="text-white/50 ml-[52px]">
            {t.historyDescription}
          </p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: t.totalUsers, value: stats.totalUsers, icon: Users, color: 'text-emerald-glow' },
            { label: t.totalActivity, value: stats.totalActivity, icon: TrendingUp, color: 'text-cyan-glow' },
            { label: t.premiumUpgrades, value: stats.premiumUpgrades, icon: Crown, color: 'text-yellow-400' },
            { label: t.workoutRequests, value: stats.workoutRequests, icon: MessageCircle, color: 'text-purple-400' },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="glass-card rounded-2xl p-5"
              >
                <Icon className={`w-5 h-5 ${stat.color} mb-2`} />
                <p className="font-display text-2xl font-bold">{stat.value}</p>
                <p className="text-white/40 text-xs mt-1">{stat.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Filters & Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchActivity}
              className="w-full bg-dark-600 border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50 focus:ring-1 focus:ring-emerald-glow/20 transition-all"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <Filter className="w-4 h-4 text-white/30 flex-shrink-0" />
            {categoryFilters.map((filter) => (
              <button
                key={filter.key}
                onClick={() => setActiveFilter(filter.key)}
                className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                  activeFilter === filter.key
                    ? 'bg-emerald-glow/10 text-emerald-glow border border-emerald-glow/30'
                    : 'bg-white/5 text-white/50 border border-white/5 hover:bg-white/10 hover:text-white/70'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        {/* History List */}
        <div className="space-y-3">
          {filteredHistory.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <Search className="w-12 h-12 text-white/10 mx-auto mb-4" />
              <p className="text-white/30 text-sm">{t.noSecurityEvents}</p>
            </motion.div>
          ) : (
            filteredHistory.map((entry, i) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="glass-card rounded-2xl p-4 sm:p-5 hover:border-white/10 transition-all group"
              >
                <div className="flex items-start gap-4">
                  <img
                    src={entry.userAvatar}
                    alt={entry.userName}
                    className="w-10 h-10 rounded-xl flex-shrink-0 object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 mb-1">
                      <h4 className="font-semibold text-sm truncate">{entry.userName}</h4>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-medium border w-fit ${categoryColors[entry.category]}`}>
                        {categoryLabels[entry.category]}
                      </span>
                    </div>
                    <p className="text-sm text-white/70 mb-1">{entry.action}</p>
                    <p className="text-xs text-white/40 line-clamp-1">{entry.detail}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs text-white/30">{formatDate(entry.timestamp)}</p>
                    <p className="text-[10px] text-white/20 mt-0.5">{formatTime(entry.timestamp)}</p>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="mt-8 text-center">
          <p className="text-white/20 text-xs">
            {t.showingActivities} {filteredHistory.length} / {allHistory.length}
          </p>
        </div>
      </div>
    </div>
  );
}
