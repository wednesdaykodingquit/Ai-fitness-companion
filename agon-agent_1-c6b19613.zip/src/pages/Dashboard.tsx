import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Dumbbell, Droplet, Trophy, Calendar, TrendingUp, 
  Target, Award, Activity, Plus, Check, Flame
} from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/language';
import LoginModal from '../components/LoginModal';
import {
  type UserProfile,
  type WorkoutLog,
  type BodyMeasurement,
  type WaterIntake,
  type DailyChallenge,
  loadProfile,
  saveProfile,
  loadWorkouts,
  saveWorkouts,
  loadMeasurements,
  saveMeasurements,
  loadWaterIntake,
  saveWaterIntake,
  loadChallenges,
  saveChallenges,
  calculateLevel,
  calculateXPForNextLevel,
  AVAILABLE_BADGES
} from '../lib/userProfile';

export default function Dashboard() {
  const { isLoggedIn } = useAuth();
  const { t } = useLanguage();
  const [showLogin, setShowLogin] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'workout' | 'body' | 'water' | 'challenges'>('overview');
  
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [workouts, setWorkouts] = useState<WorkoutLog[]>([]);
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>([]);
  const [waterIntake, setWaterIntake] = useState<WaterIntake[]>([]);
  const [challenges, setChallenges] = useState<DailyChallenge[]>([]);

  useEffect(() => {
    if (isLoggedIn) {
      setProfile(loadProfile());
      setWorkouts(loadWorkouts());
      setMeasurements(loadMeasurements());
      setWaterIntake(loadWaterIntake());
      setChallenges(loadChallenges());
    }
  }, [isLoggedIn]);

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md mx-auto px-4"
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-glow/20 to-cyan-glow/20 flex items-center justify-center mx-auto mb-6">
            <Activity className="w-10 h-10 text-emerald-glow" />
          </div>
          <h2 className="font-display text-3xl font-bold mb-3">
            {t.loginToViewHistory}
          </h2>
          <p className="text-white/50 mb-8">
            {t.trackProgress}
          </p>
          <button
            onClick={() => setShowLogin(true)}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold hover:shadow-lg hover:shadow-emerald-glow/30 hover:scale-105 transition-all"
          >
            <Activity className="w-5 h-5" />
            {t.login}
          </button>
        </motion.div>
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];
  const todayWater = waterIntake.find(w => w.date === today);
  const todayChallenges = challenges.filter(c => c.date === today);
  const recentWorkouts = workouts.slice(0, 5);
  const recentMeasurements = measurements.slice(0, 5);

  const level = profile ? calculateLevel(profile.xp) : 1;
  const xpForNextLevel = calculateXPForNextLevel(level);
  const currentLevelXP = profile ? profile.xp - ((level - 1) * 100) : 0;
  const xpProgress = (currentLevelXP / xpForNextLevel) * 100;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold mb-2">
                {t.welcomeBack}, <span className="gradient-text">{profile?.name || 'User'}</span>!
              </h1>
              <p className="text-white/50">{t.trackProgress}</p>
            </div>
            {profile && (
              <div className="flex items-center gap-3 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-glow/10 to-cyan-glow/10 border border-emerald-glow/20">
                <Trophy className="w-5 h-5 text-emerald-glow" />
                <div>
                  <p className="text-xs text-white/60">{t.level} {level}</p>
                  <p className="text-sm font-bold">{profile.xp} XP</p>
                </div>
              </div>
            )}
          </div>

          {/* XP Progress Bar */}
          {profile && (
            <div className="glass-card rounded-2xl p-4 mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-white/60">{t.level} {level}</span>
                <span className="text-sm text-white/60">{t.level} {level + 1}</span>
              </div>
              <div className="h-3 bg-dark-600 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${xpProgress}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                  className="h-full bg-gradient-to-r from-emerald-glow to-cyan-glow rounded-full"
                />
              </div>
              <p className="text-xs text-white/40 mt-2 text-center">
                {currentLevelXP} / {xpForNextLevel} {t.xpToNextLevel}
              </p>
            </div>
          )}
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { id: 'overview', label: t.overview, icon: Activity },
            { id: 'workout', label: t.workoutTab, icon: Dumbbell },
            { id: 'body', label: t.body, icon: TrendingUp },
            { id: 'water', label: t.water, icon: Droplet },
            { id: 'challenges', label: t.challenges, icon: Target },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatsCard
                icon={Dumbbell}
                label={t.workouts}
                value={workouts.length.toString()}
                color="text-emerald-glow"
              />
              <StatsCard
                icon={Flame}
                label={t.streak}
                value={`${profile?.streak || 0} ${t.days}`}
                color="text-orange-400"
              />
              <StatsCard
                icon={Droplet}
                label={t.waterToday}
                value={`${todayWater?.amount || 0}ml`}
                color="text-cyan-glow"
              />
              <StatsCard
                icon={Award}
                label={t.badges}
                value={(profile?.badges.length || 0).toString()}
                color="text-yellow-400"
              />
            </div>

            {/* Badges */}
            {profile && profile.badges.length > 0 && (
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-400" />
                  {t.yourBadges}
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {profile.badges.map((badge) => (
                    <div
                      key={badge.id}
                      className="bg-white/5 rounded-xl p-4 text-center hover:bg-white/10 transition-all"
                    >
                      <div className="text-3xl mb-2">{badge.icon}</div>
                      <p className="text-sm font-semibold">{badge.name}</p>
                      <p className="text-xs text-white/40 mt-1">{badge.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Activity */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-bold mb-4 flex items-center gap-2">
                  <Dumbbell className="w-5 h-5 text-emerald-glow" />
                  {t.recentWorkouts}
                </h3>
                {recentWorkouts.length === 0 ? (
                  <p className="text-white/40 text-sm text-center py-8">{t.noWorkoutsYet}</p>
                ) : (
                  <div className="space-y-3">
                    {recentWorkouts.map((workout) => (
                      <div key={workout.id} className="bg-white/5 rounded-xl p-3">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-semibold text-sm">{workout.workoutType}</p>
                          <span className="text-xs text-white/40">{workout.date}</span>
                        </div>
                        <p className="text-xs text-white/60">
                          {workout.exercises.length} {t.exercises} • {workout.duration} {t.min}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-bold mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-cyan-glow" />
                  {t.todaysChallenges}
                </h3>
                {todayChallenges.length === 0 ? (
                  <p className="text-white/40 text-sm text-center py-8">{t.noChallengesToday}</p>
                ) : (
                  <div className="space-y-3">
                    {todayChallenges.map((challenge) => (
                      <div key={challenge.id} className="bg-white/5 rounded-xl p-3">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-semibold text-sm">{challenge.title}</p>
                          {challenge.completed && <Check className="w-4 h-4 text-emerald-glow" />}
                        </div>
                        <p className="text-xs text-white/60">
                          {challenge.current} / {challenge.target} {challenge.unit}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'workout' && (
          <WorkoutLogger
            workouts={workouts}
            onSave={(workout) => {
              const updated = [workout, ...workouts];
              setWorkouts(updated);
              saveWorkouts(updated);
            }}
          />
        )}

        {activeTab === 'body' && (
          <BodyTracker
            measurements={measurements}
            onSave={(measurement) => {
              const updated = [measurement, ...measurements];
              setMeasurements(updated);
              saveMeasurements(updated);
            }}
          />
        )}

        {activeTab === 'water' && (
          <WaterTracker
            waterIntake={waterIntake}
            onUpdate={(water) => {
              const updated = waterIntake.filter(w => w.date !== water.date);
              updated.push(water);
              setWaterIntake(updated);
              saveWaterIntake(updated);
            }}
          />
        )}

        {activeTab === 'challenges' && (
          <ChallengesView challenges={todayChallenges} />
        )}
      </div>
    </div>
  );
}

function StatsCard({ icon: Icon, label, value, color }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-5"
    >
      <Icon className={`w-6 h-6 ${color} mb-3`} />
      <p className="text-2xl font-bold mb-1">{value}</p>
      <p className="text-xs text-white/40">{label}</p>
    </motion.div>
  );
}

function WorkoutLogger({ workouts, onSave }: { workouts: WorkoutLog[], onSave: (workout: WorkoutLog) => void }) {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [workoutType, setWorkoutType] = useState('');
  const [duration, setDuration] = useState(30);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const workout: WorkoutLog = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      workoutType,
      exercises: [],
      duration,
      completed: true
    };
    onSave(workout);
    setShowForm(false);
    setWorkoutType('');
    setDuration(30);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-2xl font-bold">{t.workoutTab}</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-semibold text-sm hover:scale-105 transition-all"
        >
          <Plus className="w-4 h-4" />
          {t.logWorkout}
        </button>
      </div>

      {showForm && (
        <motion.form
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          onSubmit={handleSubmit}
          className="glass-card rounded-2xl p-6 space-y-4"
        >
          <div>
            <label className="block text-sm font-medium mb-2">{t.workoutType}</label>
            <input
              type="text"
              value={workoutType}
              onChange={(e) => setWorkoutType(e.target.value)}
              placeholder="e.g., Chest Day, Leg Day, Cardio"
              className="w-full bg-dark-600 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">{t.duration} ({t.min})</label>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              min="1"
              className="w-full bg-dark-600 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-glow/50"
              required
            />
          </div>
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold hover:scale-105 transition-all"
            >
              {t.saveWorkout}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-6 py-3 rounded-xl bg-white/5 text-white/60 hover:bg-white/10 transition-all"
            >
              {t.cancel}
            </button>
          </div>
        </motion.form>
      )}

      <div className="space-y-3">
        {workouts.length === 0 ? (
          <div className="glass-card rounded-2xl p-12 text-center">
            <Dumbbell className="w-12 h-12 text-white/10 mx-auto mb-4" />
            <p className="text-white/40">{t.noWorkoutsYet}</p>
          </div>
        ) : (
          workouts.map((workout) => (
            <motion.div
              key={workout.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card rounded-2xl p-5 hover:border-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-lg">{workout.workoutType}</h3>
                  <p className="text-sm text-white/40">{workout.date}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">{workout.duration} {t.min}</p>
                  {workout.caloriesBurned && (
                    <p className="text-xs text-white/40">{workout.caloriesBurned} cal</p>
                  )}
                </div>
              </div>
              {workout.exercises.length > 0 && (
                <div className="space-y-2 mt-3 pt-3 border-t border-white/5">
                  {workout.exercises.map((exercise, idx) => (
                    <div key={idx} className="text-sm text-white/60">
                      {exercise.name}: {exercise.sets} sets × {exercise.reps.join(', ')} reps
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}

function BodyTracker({ measurements, onSave }: { measurements: BodyMeasurement[], onSave: (m: BodyMeasurement) => void }) {
  const { t } = useLanguage();
  const [showForm, setShowForm] = useState(false);
  const [weight, setWeight] = useState('');
  const [bodyFat, setBodyFat] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const measurement: BodyMeasurement = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      weight: weight ? Number(weight) : undefined,
      bodyFat: bodyFat ? Number(bodyFat) : undefined
    };
    onSave(measurement);
    setShowForm(false);
    setWeight('');
    setBodyFat('');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-2xl font-bold">{t.body}</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-semibold text-sm hover:scale-105 transition-all"
        >
          <Plus className="w-4 h-4" />
          {t.addMeasurement}
        </button>
      </div>

      {showForm && (
        <motion.form
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          onSubmit={handleSubmit}
          className="glass-card rounded-2xl p-6 space-y-4"
        >
          <div>
            <label className="block text-sm font-medium mb-2">{t.weight} (kg)</label>
            <input
              type="number"
              step="0.1"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder="e.g., 70.5"
              className="w-full bg-dark-600 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">{t.bodyFat} (%)</label>
            <input
              type="number"
              step="0.1"
              value={bodyFat}
              onChange={(e) => setBodyFat(e.target.value)}
              placeholder="e.g., 15.5"
              className="w-full bg-dark-600 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-emerald-glow/50"
            />
          </div>
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold hover:scale-105 transition-all"
            >
              {t.saveMeasurement}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-6 py-3 rounded-xl bg-white/5 text-white/60 hover:bg-white/10 transition-all"
            >
              {t.cancel}
            </button>
          </div>
        </motion.form>
      )}

      <div className="space-y-3">
        {measurements.length === 0 ? (
          <div className="glass-card rounded-2xl p-12 text-center">
            <TrendingUp className="w-12 h-12 text-white/10 mx-auto mb-4" />
            <p className="text-white/40">{t.noMeasurementsYet}</p>
          </div>
        ) : (
          measurements.map((measurement) => (
            <motion.div
              key={measurement.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-2">
                <p className="font-semibold">{measurement.date}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {measurement.weight && (
                  <div>
                    <p className="text-xs text-white/40 mb-1">{t.weight}</p>
                    <p className="text-lg font-bold">{measurement.weight} kg</p>
                  </div>
                )}
                {measurement.bodyFat && (
                  <div>
                    <p className="text-xs text-white/40 mb-1">{t.bodyFat}</p>
                    <p className="text-lg font-bold">{measurement.bodyFat}%</p>
                  </div>
                )}
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}

function WaterTracker({ waterIntake, onUpdate }: { waterIntake: WaterIntake[], onUpdate: (w: WaterIntake) => void }) {
  const { t } = useLanguage();
  const today = new Date().toISOString().split('T')[0];
  const todayWater = waterIntake.find(w => w.date === today) || { date: today, amount: 0, goal: 2500 };
  const progress = (todayWater.amount / todayWater.goal) * 100;

  const addWater = (ml: number) => {
    onUpdate({
      ...todayWater,
      amount: todayWater.amount + ml
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl font-bold">{t.waterToday}</h2>

      <div className="glass-card rounded-2xl p-8">
        <div className="text-center mb-6">
          <div className="relative inline-block">
            <div className="w-48 h-48 rounded-full border-8 border-dark-600 relative overflow-hidden">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${progress}%` }}
                transition={{ duration: 0.5 }}
                className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyan-glow to-emerald-glow"
              />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <p className="text-4xl font-bold">{todayWater.amount}</p>
                <p className="text-sm text-white/60">/ {todayWater.goal} ml</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {[250, 500, 750].map((ml) => (
            <button
              key={ml}
              onClick={() => addWater(ml)}
              className="py-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-glow/30 transition-all"
            >
              <Droplet className="w-6 h-6 text-cyan-glow mx-auto mb-2" />
              <p className="font-semibold">+{ml}ml</p>
            </button>
          ))}
        </div>
      </div>

      <div className="glass-card rounded-2xl p-6">
        <h3 className="font-semibold mb-4">{t.quickAdd}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[100, 200, 330, 500].map((ml) => (
            <button
              key={ml}
              onClick={() => addWater(ml)}
              className="py-3 rounded-xl bg-gradient-to-r from-cyan-glow/10 to-emerald-glow/10 border border-cyan-glow/20 hover:border-cyan-glow/40 transition-all text-sm font-semibold"
            >
              +{ml}ml
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function ChallengesView({ challenges }: { challenges: DailyChallenge[] }) {
  const { t } = useLanguage();
  return (
    <div className="space-y-6">
      <h2 className="font-display text-2xl font-bold">{t.dailyChallenges}</h2>

      {challenges.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center">
          <Target className="w-12 h-12 text-white/10 mx-auto mb-4" />
          <p className="text-white/40 mb-2">{t.noChallengesForToday}</p>
          <p className="text-sm text-white/30">{t.checkBackTomorrow}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {challenges.map((challenge) => {
            const progress = (challenge.current / challenge.target) * 100;
            return (
              <motion.div
                key={challenge.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card rounded-2xl p-5"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-1">{challenge.title}</h3>
                    <p className="text-sm text-white/60">{challenge.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-white/40 mb-1">{t.reward}</p>
                    <p className="text-sm font-bold text-emerald-glow">+{challenge.xpReward} XP</p>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-white/60">
                      {challenge.current} / {challenge.target} {challenge.unit}
                    </span>
                    {challenge.completed && (
                      <span className="text-xs font-semibold text-emerald-glow flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        {t.completed}
                      </span>
                    )}
                  </div>
                  <div className="h-2 bg-dark-600 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      className="h-full bg-gradient-to-r from-emerald-glow to-cyan-glow rounded-full"
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
