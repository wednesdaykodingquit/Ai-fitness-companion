import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Crown, Zap, Star, Sparkles, Shield, Clock, ArrowRight, Send, MessageCircle } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/language';
import LoginModal from '../components/LoginModal';
import PaymentModal from '../components/PaymentModal';

export default function Pricing() {
  const { isLoggedIn, user, upgradePremium } = useAuth();
  const { t } = useLanguage();
  const [showLogin, setShowLogin] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedPlanData, setSelectedPlanData] = useState<{ name: string; price: string; period: string } | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const plans = [
    {
      id: 'daily',
      name: t.daily,
      price: '10.000',
      period: t.perDay,
      description: t.tryWithoutCommitment,
      icon: Zap,
      color: 'from-blue-400 to-cyan-glow',
      borderColor: 'border-blue-400/20',
      popular: false,
      features: [
        { text: t.unlimitedChat, included: true },
        { text: t.allWorkoutPlans, included: true },
        { text: t.completeNutrition, included: true },
        { text: t.chatHistory, included: true },
        { text: t.customMealPlan, included: false },
        { text: t.exclusiveVideos, included: false },
        { text: t.oneOnOneConsult, included: false },
      ],
    },
    {
      id: 'monthly',
      name: t.monthly,
      price: '100.000',
      period: t.perMonth,
      description: t.bestForResults,
      icon: Star,
      color: 'from-emerald-glow to-cyan-glow',
      borderColor: 'border-emerald-glow/30',
      popular: true,
      savings: `${t.save} 67%`,
      features: [
        { text: t.unlimitedChat, included: true },
        { text: t.allWorkoutPlans, included: true },
        { text: t.completeNutrition, included: true },
        { text: t.chatHistory, included: true },
        { text: t.customMealPlan, included: true },
        { text: t.exclusiveVideos, included: true },
        { text: t.oneOnOneConsult, included: false },
      ],
    },
    {
      id: 'yearly',
      name: t.yearly,
      price: '500.000',
      period: t.perYear,
      description: t.bestInvestment,
      icon: Crown,
      color: 'from-yellow-400 to-orange-400',
      borderColor: 'border-yellow-400/20',
      popular: false,
      savings: `${t.save} 86%`,
      features: [
        { text: t.unlimitedChat, included: true },
        { text: t.allWorkoutPlans, included: true },
        { text: t.completeNutrition, included: true },
        { text: t.chatHistory, included: true },
        { text: t.customMealPlan, included: true },
        { text: t.exclusiveVideos, included: true },
        { text: t.oneOnOneConsult, included: true },
      ],
    },
  ];

  const freeFeatures = [
    t.chatsPerDay,
    t.basicWorkouts,
    t.generalNutrition,
  ];

  const handleSubscribe = (planId: string) => {
    if (!isLoggedIn) {
      setSelectedPlan(planId);
      setShowLogin(true);
      return;
    }
    const plan = plans.find(p => p.id === planId);
    if (plan) {
      setSelectedPlanData({ name: plan.name, price: plan.price, period: plan.period });
      setSelectedPlan(planId);
      setShowPayment(true);
    }
  };

  const handlePaymentConfirm = () => {
    if (selectedPlan) {
      upgradePremium(selectedPlan);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }
    setShowPayment(false);
  };

  const handleLoginClose = () => {
    setShowLogin(false);
    if (isLoggedIn && selectedPlan) {
      const plan = plans.find(p => p.id === selectedPlan);
      if (plan) {
        setSelectedPlanData({ name: plan.name, price: plan.price, period: plan.period });
        setShowPayment(true);
      }
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <LoginModal isOpen={showLogin} onClose={handleLoginClose} />
      {selectedPlanData && (
        <PaymentModal
          isOpen={showPayment}
          onClose={() => setShowPayment(false)}
          onConfirm={handlePaymentConfirm}
          planName={selectedPlanData.name}
          planPrice={selectedPlanData.price}
          planPeriod={selectedPlanData.period}
        />
      )}

      {showSuccess && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-20 left-1/2 -translate-x-1/2 z-[80] px-6 py-3 rounded-2xl bg-emerald-glow text-dark-900 font-semibold text-sm shadow-lg shadow-emerald-glow/30 flex items-center gap-2"
        >
          <Check className="w-5 h-5" />
          {t.success}! 🎉
        </motion.div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-6">
            <Crown className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-white/70">{t.premiumPlans}</span>
          </div>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold mb-4">
            {t.choosePlan}
            <span className="gradient-text"> {t.premium}</span>
          </h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            {t.loginDescription}
          </p>

          {isLoggedIn && user?.isPremium && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-glow/20 to-cyan-glow/20 border border-emerald-glow/30"
            >
              <Shield className="w-5 h-5 text-emerald-glow" />
              <span className="text-sm font-semibold text-emerald-glow">
                {t.activeNow}
              </span>
            </motion.div>
          )}
        </motion.div>

        {/* Free Tier Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-12 glass-card rounded-2xl p-6 max-w-2xl mx-auto"
        >
          <div className="flex items-center gap-3 mb-3">
            <Sparkles className="w-5 h-5 text-white/50" />
            <h3 className="font-display font-semibold">{t.freePlan}</h3>
            <span className="px-3 py-1 rounded-full bg-white/5 text-xs text-white/50 border border-white/10">{t.activeNow}</span>
          </div>
          <div className="flex flex-wrap gap-3">
            {freeFeatures.map((f, i) => (
              <span key={i} className="flex items-center gap-2 text-sm text-white/50">
                <Check className="w-4 h-4 text-white/30" />
                {f}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, i) => {
            const Icon = plan.icon;
            const isCurrentPremium = isLoggedIn && user?.isPremium;

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                className={`relative group rounded-3xl overflow-hidden ${
                  plan.popular ? 'md:-mt-4 md:mb-4' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 text-center py-2 text-xs font-bold uppercase tracking-wider z-10">
                    🔥 {t.mostPopular}
                  </div>
                )}

                {plan.savings && !plan.popular && (
                  <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-yellow-400/10 border border-yellow-400/20 text-xs font-semibold text-yellow-400 z-10">
                    {plan.savings}
                  </div>
                )}

                <div className={`h-full glass-card border ${plan.popular ? 'border-emerald-glow/30 shadow-lg shadow-emerald-glow/5' : plan.borderColor} rounded-3xl p-8 ${plan.popular ? 'pt-14' : ''} flex flex-col`}>
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-7 h-7 text-dark-900" />
                  </div>

                  <h3 className="font-display text-xl font-bold mb-1">{plan.name}</h3>
                  <p className="text-white/40 text-sm mb-5">{plan.description}</p>

                  <div className="mb-6">
                    <div className="flex items-baseline gap-1">
                      <span className="text-white/50 text-lg">Rp</span>
                      <span className="font-display text-4xl font-bold gradient-text">{plan.price}</span>
                    </div>
                    <p className="text-white/30 text-sm mt-1">{plan.period}</p>
                  </div>

                  <div className="space-y-3 mb-8 flex-1">
                    {plan.features.map((feature, fi) => (
                      <div key={fi} className="flex items-center gap-3">
                        {feature.included ? (
                          <div className="w-5 h-5 rounded-full bg-emerald-glow/10 flex items-center justify-center flex-shrink-0">
                            <Check className="w-3 h-3 text-emerald-glow" />
                          </div>
                        ) : (
                          <div className="w-5 h-5 rounded-full bg-white/5 flex items-center justify-center flex-shrink-0">
                            <X className="w-3 h-3 text-white/20" />
                          </div>
                        )}
                        <span className={`text-sm ${feature.included ? 'text-white/70' : 'text-white/30'}`}>
                          {feature.text}
                        </span>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={isCurrentPremium}
                    className={`w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all hover:scale-[1.02] active:scale-[0.98] ${
                      plan.popular
                        ? 'bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 hover:shadow-lg hover:shadow-emerald-glow/30'
                        : 'bg-white/5 border border-white/10 text-white hover:bg-white/10 hover:border-white/20'
                    } ${isCurrentPremium ? 'opacity-50 cursor-not-allowed hover:scale-100' : ''}`}
                  >
                    {isCurrentPremium ? (
                      <>
                        <Shield className="w-4 h-4" />
                        {t.activeNow}
                      </>
                    ) : (
                      <>
                        <Clock className="w-4 h-4" />
                        {t.subscribe}
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Guarantee */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-white/5 border border-white/5">
            <Shield className="w-5 h-5 text-emerald-glow" />
            <span className="text-sm text-white/50">{t.guarantee}</span>
          </div>
        </motion.div>

        {/* Payment Methods Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          className="mt-12 max-w-2xl mx-auto"
        >
          <div className="glass-card rounded-2xl p-6 border border-white/5">
            <h3 className="font-display font-bold text-lg mb-4 text-center">
              {t.paymentMethods}
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="rounded-xl bg-blue-400/5 border border-blue-400/15 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                  </div>
                  <span className="font-semibold text-sm text-blue-400">DANA</span>
                </div>
                <p className="text-lg font-bold text-white/80 font-mono">082161387805</p>
                <p className="text-xs text-white/30 mt-1">a.n. Muhammad Geovanny Iskandar</p>
              </div>
              <div className="rounded-xl bg-emerald-glow/5 border border-emerald-glow/15 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                    <svg className="w-4 h-4 text-dark-900" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>
                  </div>
                  <span className="font-semibold text-sm text-emerald-glow">{t.premium}</span>
                </div>
                <p className="text-lg font-bold text-white/80 font-mono">5258 0101 8611 506</p>
                <p className="text-xs text-white/30 mt-1">a.n. Muhammad Geovanny Iskandar</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Send Proof WhatsApp */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.57 }}
          className="mt-6 max-w-2xl mx-auto"
        >
          <div className="rounded-2xl border border-green-500/20 bg-green-500/5 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-green-500 flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-green-400">{t.sendProof}</h3>
                <p className="text-xs text-white/40">{t.sendProofDesc}</p>
              </div>
            </div>
            <div className="bg-dark-900/50 rounded-xl p-4 mb-4">
              <p className="text-xs text-white/40 mb-1">{t.sendViaWhatsapp}:</p>
              <p className="font-display text-2xl font-bold text-green-400 tracking-wide">082161387805</p>
              <p className="text-xs text-white/30 mt-1">{t.includeProof}</p>
            </div>
            <a
              href={`https://wa.me/6282161387805?text=${encodeURIComponent('Halo admin FitBot AI, saya sudah melakukan pembayaran. Berikut bukti pembayaran saya:')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-green-500 hover:bg-green-600 text-white font-bold text-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Send className="w-4 h-4" />
              {t.sendViaWhatsapp}
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </motion.div>

        {/* FAQ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-20 max-w-3xl mx-auto"
        >
          <h2 className="font-display text-2xl font-bold text-center mb-8">
            {t.faq}
          </h2>
          <div className="space-y-4">
            {[
              {
                q: t.choosePlan + '?',
                a: t.tryWithoutCommitment
              },
              {
                q: t.paymentMethods + '?',
                a: t.sendProofDesc
              },
              {
                q: t.freePlan + '?',
                a: t.chatsPerDay
              },
              {
                q: t.subscribe + '?',
                a: t.guarantee
              },
            ].map((faq, i) => (
              <div key={i} className="glass-card rounded-2xl p-5">
                <h4 className="font-semibold text-sm mb-2">{faq.q}</h4>
                <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
