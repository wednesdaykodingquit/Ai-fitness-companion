import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  MessageCircle, Dumbbell, Apple, Brain, Heart, Zap,
  ChevronRight, Star, Users, Trophy, ArrowRight, Sparkles
} from 'lucide-react';
import { useLanguage } from '../lib/language';

export default function Landing() {
  const { t } = useLanguage();

  const features = [
    {
      icon: Dumbbell,
      title: t.customWorkouts,
      description: t.customWorkoutsDesc,
      color: 'from-emerald-glow to-green-400'
    },
    {
      icon: Apple,
      title: t.nutritionGuidance,
      description: t.nutritionGuidanceDesc,
      color: 'from-cyan-glow to-blue-400'
    },
    {
      icon: Brain,
      title: t.aiPowered,
      description: t.aiPoweredDesc,
      color: 'from-purple-400 to-pink-400'
    },
    {
      icon: Heart,
      title: t.recoveryTips,
      description: t.recoveryTipsDesc,
      color: 'from-red-400 to-orange-400'
    },
    {
      icon: Zap,
      title: t.instantAnswers,
      description: t.instantAnswersDesc,
      color: 'from-yellow-400 to-amber-400'
    },
    {
      icon: Trophy,
      title: t.allLevels,
      description: t.allLevelsDesc,
      color: 'from-emerald-glow to-cyan-glow'
    },
  ];

  const stats = [
    { value: '50+', label: t.workoutPlans, icon: Dumbbell },
    { value: '24/7', label: t.aiAvailability, icon: Zap },
    { value: '10K+', label: t.happyUsers, icon: Users },
    { value: '4.9', label: t.userRating, icon: Star },
  ];

  const testimonials = [
    {
      name: 'Alex R.',
      role: 'Beginner',
      text: 'FitBot helped me start my fitness journey with confidence. The beginner guide was exactly what I needed!',
      avatar: '🧑‍💻'
    },
    {
      name: 'Sarah M.',
      role: 'Intermediate',
      text: 'The nutrition advice is spot-on. I lost 8kg in 3 months following the meal plans and macro guidance.',
      avatar: '👩‍🦰'
    },
    {
      name: 'Mike T.',
      role: 'Advanced',
      text: 'Even as an experienced lifter, the workout variations and progressive overload tips keep my gains coming.',
      avatar: '🧔'
    },
  ];
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/hero-fitness.jpg"
            alt="Fitness"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-dark-900/80 via-dark-900/90 to-dark-900" />
          <div className="absolute inset-0 bg-gradient-to-r from-dark-900/80 to-transparent" />
        </div>

        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-glow/5 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-cyan-glow/5 rounded-full blur-[100px]" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-6">
                <Sparkles className="w-4 h-4 text-emerald-glow" />
                <span className="text-sm text-white/70">{t.aiPowered}</span>
              </div>

              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6">
                {t.welcomeTo}
                <br />
                <span className="gradient-text">{t.yourPersonal}</span>
                <br />
                {t.fitnessAI} {t.coach}
              </h1>

              <p className="text-lg text-white/60 max-w-lg mb-8 leading-relaxed">
                {t.heroDescription}
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/chat"
                  className="group inline-flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-lg hover:shadow-2xl hover:shadow-emerald-glow/30 hover:scale-105 transition-all duration-300"
                >
                  <MessageCircle className="w-5 h-5" />
                  {t.startChatting}
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <a
                  href="#features"
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-2xl border border-white/10 text-white/80 font-medium hover:bg-white/5 hover:border-white/20 transition-all"
                >
                  {t.learnMore}
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block"
            >
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-emerald-glow/20 to-cyan-glow/20 rounded-3xl blur-2xl" />
                <div className="relative glass-card rounded-3xl p-6 glow-border">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                      <Dumbbell className="w-5 h-5 text-dark-900" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">FitBot AI</p>
                      <p className="text-xs text-emerald-glow">● Online</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-end">
                      <div className="bg-gradient-to-r from-emerald-glow/20 to-cyan-glow/20 border border-emerald-glow/20 rounded-2xl rounded-tr-sm px-4 py-2.5 max-w-[80%]">
                        <p className="text-sm">Give me a chest workout 💪</p>
                      </div>
                    </div>
                    <div className="flex justify-start">
                      <div className="bg-dark-500 border border-white/5 rounded-2xl rounded-tl-sm px-4 py-2.5 max-w-[85%]">
                        <p className="text-sm text-white/80 font-semibold gradient-text mb-1">🏋️ Chest Day Power</p>
                        <p className="text-xs text-white/60">• Bench Press — 4×8-10</p>
                        <p className="text-xs text-white/60">• Incline DB Press — 3×10-12</p>
                        <p className="text-xs text-white/60">• Cable Flyes — 3×12-15</p>
                        <p className="text-xs text-white/60">• Push-ups — 3×failure</p>
                        <p className="text-xs text-white/60">• Dips — 3×10-12</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="text-center"
                >
                  <Icon className="w-6 h-6 text-emerald-glow mx-auto mb-2" />
                  <p className="font-display text-3xl sm:text-4xl font-bold gradient-text">{stat.value}</p>
                  <p className="text-sm text-white/50 mt-1">{stat.label}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl sm:text-5xl font-bold mb-4">
              {t.everythingYouNeed}
              <span className="gradient-text"> {t.getFit}</span>
            </h2>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">
              {t.everythingYouNeedDesc}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="group glass-card rounded-2xl p-6 hover:border-white/10 transition-all duration-300 hover:-translate-y-1"
                >
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6 text-dark-900" />
                  </div>
                  <h3 className="font-display font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Image Cards Section */}
      <section className="py-24 bg-dark-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl sm:text-5xl font-bold mb-4">
              {t.trainSmart}
              <span className="gradient-text"> {t.eatSmart}</span>
            </h2>
            <p className="text-white/50 text-lg max-w-2xl mx-auto">
              {t.everythingYouNeedDesc}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { img: '/images/hero-fitness.jpg', title: t.workoutPlans, desc: t.customWorkoutsDesc },
              { img: '/images/nutrition.jpg', title: t.nutritionGuidance, desc: t.nutritionGuidanceDesc },
              { img: '/images/recovery.jpg', title: t.recoveryTips, desc: t.recoveryTipsDesc },
            ].map((card, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="group relative rounded-2xl overflow-hidden cursor-pointer"
              >
                <img
                  src={card.img}
                  alt={card.title}
                  className="w-full h-72 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-display font-bold text-xl mb-1">{card.title}</h3>
                  <p className="text-white/60 text-sm">{card.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl sm:text-5xl font-bold mb-4">
              {t.lovedBy}
              <span className="gradient-text"> Fitness Enthusiasts</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card rounded-2xl p-6"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, s) => (
                    <Star key={s} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{t.avatar}</span>
                  <div>
                    <p className="font-medium text-sm">{t.name}</p>
                    <p className="text-xs text-white/40">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-glow/10 to-cyan-glow/10" />
            <div className="absolute inset-0 bg-dark-800/90" />
            <div className="relative p-12 sm:p-16 text-center">
              <h2 className="font-display text-4xl sm:text-5xl font-bold mb-4">
                {t.readyToTransform}
                <br />
                <span className="gradient-text">{t.yourPersonal}?</span>
              </h2>
              <p className="text-white/50 text-lg mb-8 max-w-lg mx-auto">
                {t.readyToTransformDesc}
              </p>
              <Link
                to="/chat"
                className="inline-flex items-center gap-3 px-10 py-5 rounded-2xl bg-gradient-to-r from-emerald-glow to-cyan-glow text-dark-900 font-bold text-lg hover:shadow-2xl hover:shadow-emerald-glow/30 hover:scale-105 transition-all duration-300"
              >
                <MessageCircle className="w-6 h-6" />
                {t.startJourney}
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5 bg-dark-800/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-glow to-cyan-glow flex items-center justify-center">
                  <Dumbbell className="w-4 h-4 text-dark-900" />
                </div>
                <span className="font-display font-bold gradient-text">FitBot AI</span>
              </div>
              <p className="text-white/40 text-sm leading-relaxed">
                {t.heroDescription}
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3 text-white/70">{t.features}</h4>
              <div className="space-y-2">
                <Link to="/chat" className="block text-sm text-white/40 hover:text-emerald-glow transition-colors">{t.chat}</Link>
                <Link to="/pricing" className="block text-sm text-white/40 hover:text-emerald-glow transition-colors">{t.premium}</Link>
                <Link to="/history" className="block text-sm text-white/40 hover:text-emerald-glow transition-colors">{t.history}</Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3 text-white/70">{t.workout}</h4>
              <div className="space-y-2">
                <p className="text-sm text-white/40">Chest & Back</p>
                <p className="text-sm text-white/40">Legs & Shoulders</p>
                <p className="text-sm text-white/40">HIIT & Cardio</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3 text-white/70">{t.pricing}</h4>
              <div className="space-y-2">
                <p className="text-sm text-white/40">{t.daily} — Rp 10.000</p>
                <p className="text-sm text-white/40">{t.monthly} — Rp 100.000</p>
                <p className="text-sm text-white/40">{t.yearly} — Rp 500.000</p>
              </div>
            </div>
          </div>
          <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-white/30 text-sm">{t.createdBy}</span>
              <span className="font-semibold text-sm gradient-text">Muhammad Geovanny Iskandar</span>
            </div>
            <p className="text-white/20 text-xs">
              © 2025 FitBot AI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
