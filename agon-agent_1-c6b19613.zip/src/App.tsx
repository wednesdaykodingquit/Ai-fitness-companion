import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { AuthProvider } from './lib/auth';
import { LanguageProvider } from './lib/language';
import { securityMonitor } from './lib/securityMonitor';
import Navbar from './components/Navbar';
import Landing from './pages/Landing';
import Chat from './pages/Chat';
import History from './pages/History';
import Pricing from './pages/Pricing';
import SecurityDashboard from './pages/SecurityDashboard';
import Dashboard from './pages/Dashboard';

function App() {
  useEffect(() => {
    // Start security monitoring on app load
    securityMonitor.start();
    
    // Monitor page navigation
    securityMonitor.recordNavigation();
    
    return () => {
      securityMonitor.stop();
    };
  }, []);

  return (
    <BrowserRouter>
      <LanguageProvider>
        <AuthProvider>
          <div className="min-h-screen bg-dark-900 text-white">
            <Navbar />
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/history" element={<History />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/security" element={<SecurityDashboard />} />
            </Routes>
          </div>
        </AuthProvider>
      </LanguageProvider>
    </BrowserRouter>
  );
}

export default App;
